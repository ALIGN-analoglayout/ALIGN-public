#!/bin/bash

argo submit route_artifacts.argo --entrypoint load-circuit --name load-circuit

