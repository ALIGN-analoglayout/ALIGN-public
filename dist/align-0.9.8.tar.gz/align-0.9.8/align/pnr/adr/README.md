# Plan to integrate ADR

- [ ] Copy existing code from Cktgen to align/pnr/adr
- [ ]  Provide same inputs required for Cktgen from existing info in align/pnr
- [ ] Run designs through with hand generated global routes (using placement info only)
- [ ] Collect results into PnR json format, enable viewing results
- [ ] Add in geneated GRs
