import math
from .canvas import DefaultCanvas
from ...cell_fabric.generators import *
from ...cell_fabric.grid import *

import logging
logger = logging.getLogger(__name__)

class MOSGenerator(DefaultCanvas):

    def __init__(self, pdk, height, fin, gate, gateDummy, shared_diff, stack):
        super().__init__(pdk)
        
        self.finsPerUnitCell = height
        assert self.finsPerUnitCell % 4 == 0
        assert (self.finsPerUnitCell*self.pdk['Fin']['Pitch'])%self.pdk['M2']['Pitch']==0
        self.m2PerUnitCell = (self.finsPerUnitCell*self.pdk['Fin']['Pitch'])//self.pdk['M2']['Pitch']
        self.unitCellHeight = self.m2PerUnitCell* self.pdk['M2']['Pitch']
        ######### Derived Parameters ############ 
        self.shared_diff = shared_diff
        #print(shared_diff)
        self.stack = stack
        self.gateDummy = gateDummy
        self.gate = (2*gate)*self.stack
        self.gatesPerUnitCell = self.gate + 2*self.gateDummy*(1-self.shared_diff)
        self.finDummy = (self.finsPerUnitCell-fin)//2
        self.lFin = 16 ## need to be added in the PDK JSON
        assert (self.lFin*self.pdk['Fin']['Pitch'])%self.pdk['M2']['Pitch']==0 
        assert self.finDummy >= 8, "number of fins in the transistor must be less than height"
        assert fin > 1, "number of fins in the transistor must be more than 2"
        #assert fin % 2 == 0, "number of fins in the transistor must be even" 
        assert gateDummy > 0 
   
        unitCellLength = self.gatesPerUnitCell* self.pdk['Poly']['Pitch']
        activeWidth =  self.pdk['Fin']['Pitch']*fin
        activeOffset = self.unitCellHeight//2 -self.pdk['Fin']['Pitch']//2
        #activeOffset = activeWidth//2 + finDummy*self.pdk['Fin']['Pitch']-self.pdk['Fin']['Pitch']//2
        activePitch = self.unitCellHeight
        RvtWidth = activeWidth + 2*self.pdk['Active']['activeRvtEnc']
        BpWidth = activeWidth + 2*self.pdk['Active']['activeBpEnc']
        NwWidth = activeWidth + 2*self.pdk['Active']['activeRvtEnc']
        auxLength = self.unitCellHeight-self.pdk['Gcut']['gcutWidth']
        plspg_offset = self.pdk['Gcut']['gcutWidth']-self.pdk['Gcut']['plgcutEnc']
        cbLength = (self.gate-1)*self.pdk['Poly']['Pitch']+self.pdk['Poly']['Width']+2*self.pdk['Cb']['cbGateExt'] 

#############################################
        ### To define a pin at center not over full tracks ###
        self.pin = self.addGen( Wire( 'pin', 'Pin', 'h',
                                     clg=UncoloredCenterLineGrid( pitch=self.pdk['M2']['Pitch'], width=self.pdk['M2']['Width']),
                                     spg=EnclosureGrid( pitch=self.pdk['M1']['Pitch'], stoppoint=self.pdk['V1']['VencA_H'] + self.pdk['M1']['Width']//2, check=False)))

        self.pin3 = self.addGen( Wire( 'pin3', 'Pin3', 'v',
                                     clg=UncoloredCenterLineGrid( pitch=self.pdk['M3']['Pitch'], width=self.pdk['M3']['Width']),
                                     spg=EnclosureGrid( pitch=self.pdk['M2']['Pitch'], stoppoint=self.pdk['V2']['VencA_H'] + self.pdk['M2']['Width']//2, check=False)))
        ### ends ###

        self.cab = self.addGen( Wire( 'cab', 'Ca', 'v',
                                     clg=UncoloredCenterLineGrid( pitch=   self.pdk['M1']['Pitch'], width= self.pdk['Ca']['m0Width'], offset= self.pdk['M1']['Offset']),
                                     spg=EnclosureGrid( pitch=self.pdk['M2']['Pitch'], offset=0, stoppoint= self.pdk['M2']['Width']//2+self.pdk['V1']['VencA_L'], check=True)))

        self.pl_dummy = self.addGen( Wire( 'pl_dummy', 'PolyDummy', 'v',
                                     clg=UncoloredCenterLineGrid( pitch= self.pdk['Poly']['Pitch'], width= self.pdk['Boundary']['DummyWidth'], offset=0),
                                     spg=SingleGrid( offset= plspg_offset, pitch=self.unitCellHeight)))

        self.pl = self.addGen( Wire( 'pl', 'Poly', 'v',
                                     clg=UncoloredCenterLineGrid( pitch= self.pdk['Poly']['Pitch'], width= self.pdk['Poly']['Width'], offset= self.pdk['Poly']['Offset']),
                                     spg=SingleGrid( offset= plspg_offset, pitch=self.unitCellHeight)))
        
        
        self.tb = self.addGen( Wire( 'tb', 'Tb', 'v',
                                     clg=UncoloredCenterLineGrid( pitch= self.pdk['Poly']['Pitch'], width= self.pdk['Tb']['tbWidth'], offset= self.pdk['Poly']['Offset']),
                                     spg=SingleGrid( offset= plspg_offset, pitch=self.unitCellHeight)))

        self.tb_dummy = self.addGen( Wire( 'tb_dummy', 'Tb', 'v',
                                     clg=UncoloredCenterLineGrid( pitch= self.pdk['Poly']['Pitch'], width= self.pdk['Boundary']['DummyTbWidth'], offset=0),
                                     spg=SingleGrid( offset= plspg_offset-30, pitch=self.unitCellHeight)))
        self.tb_dummy1 = self.addGen( Wire( 'tb_dummy1', 'Tb', 'v',
                                     clg=UncoloredCenterLineGrid( pitch= self.pdk['Poly']['Pitch'], width= self.pdk['Boundary']['DummyTbWidth'], offset=0),
                                     spg=SingleGrid( offset= 30, pitch=self.unitCellHeight)))
        
        stoppoint = self.gateDummy*self.pdk['Poly']['Pitch']+self.pdk['Poly']['Offset']-self.pdk['Cb']['cbGateExt']-self.pdk['Poly']['Width']//2
        offset = self.gateDummy*self.pdk['Poly']['Pitch']+self.pdk['Poly']['Offset'] - self.pdk['Poly']['Pitch']//2      

        self.cb = self.addGen( Wire( 'cb', 'Cb', 'h',
                                         clg=UncoloredCenterLineGrid( pitch=self.pdk['M2']['Pitch'], width=self.pdk['Cb']['cbWidth'], offset=self.pdk['M2']['Pitch']),
                                         spg=EnclosureGrid( pitch=unitCellLength, offset=offset*self.shared_diff, stoppoint=stoppoint-offset*self.shared_diff, check=True)))
        
        stoppoint = self.pdk['Gcut']['gcutWidth']//2
        self.aux = self.addGen( Wire( 'aux', 'Aux', 'v',
                                     clg=UncoloredCenterLineGrid( pitch= self.pdk['Poly']['Pitch'], width= self.pdk['Poly']['Width'], offset= self.pdk['Poly']['Offset']),
                                     spg=EnclosureGrid( offset=self.pdk['Gcut']['gcutWidth']//2, pitch=self.unitCellHeight,  stoppoint=stoppoint, check=True)))

        stoppoint = plspg_offset
        self.aux1 = self.addGen( Wire( 'aux1', 'Aux', 'v',
                                     clg=UncoloredCenterLineGrid( pitch= self.pdk['Poly']['Pitch'], width= self.pdk['Poly']['Width'], offset= self.pdk['Poly']['Offset']),
                                     spg=EnclosureGrid( offset=plspg_offset, pitch=self.unitCellHeight,  stoppoint=stoppoint, check=True)))
        
        self.fin = self.addGen( Wire( 'fin', 'Fin', 'h',
                                      clg=UncoloredCenterLineGrid( pitch= self.pdk['Fin']['Pitch'], width= self.pdk['Fin']['Width'], offset= self.pdk['Fin']['Offset']),
                                      spg=SingleGrid( offset=0, pitch=self.pdk['Poly']['Pitch'])))

        #self.fin = self.addGen( Wire( 'fin', 'Fin', 'h',
        #                              clg=UncoloredCenterLineGrid( pitch= self.pdk['Fin']['Pitch'], width= self.pdk['Fin']['Width'], offset= self.pdk['Fin']['Offset']),
        #                              spg=SingleGrid( offset=0, pitch=unitCellLength)))
        
        stoppoint = (self.gateDummy-1)* self.pdk['Poly']['Pitch'] +  self.pdk['Poly']['Offset']
        #stoppoint = (gateDummy-1)* self.pdk['Poly']['Pitch'] +  self.pdk['Poly']['Offset']
        self.active = self.addGen( Wire( 'active', 'Active', 'h',
                                         clg=UncoloredCenterLineGrid( pitch=activePitch, width=activeWidth, offset=activeOffset),
                                         spg=EnclosureGrid( pitch=unitCellLength, offset=0, stoppoint=stoppoint, check=True)))

        self.alpha = self.addGen( Wire( 'alpha', 'Alpha', 'h',
                                         clg=UncoloredCenterLineGrid( pitch=activePitch, width=activeWidth, offset=activeOffset),
                                         spg=EnclosureGrid( pitch=unitCellLength, offset=0, stoppoint=stoppoint, check=True)))

        self.tt = self.addGen( Wire( 'tt', 'Tt', 'h',
                                         clg=UncoloredCenterLineGrid( pitch=activePitch, width=activeWidth, offset=activeOffset),
                                         spg=EnclosureGrid( pitch=unitCellLength, offset=0, stoppoint=stoppoint, check=True)))

        self.RVT = self.addGen( Wire( 'RVT', 'RVT', 'h',
                                      clg=UncoloredCenterLineGrid( pitch=activePitch, width=RvtWidth, offset=activeOffset),
                                      spg=EnclosureGrid( pitch=unitCellLength, offset=0, stoppoint=stoppoint, check=True)))

        self.LVT = self.addGen( Wire( 'LVT', 'LVT', 'h',
                                      clg=UncoloredCenterLineGrid( pitch=activePitch, width=RvtWidth, offset=activeOffset),
                                      spg=EnclosureGrid( pitch=unitCellLength, offset=0, stoppoint=stoppoint, check=True)))

        self.HVT = self.addGen( Wire( 'HVT', 'HVT', 'h',
                                      clg=UncoloredCenterLineGrid( pitch=activePitch, width=RvtWidth, offset=activeOffset),
                                      spg=EnclosureGrid( pitch=unitCellLength, offset=0, stoppoint=stoppoint, check=True)))

        self.active_diff = self.addGen( Wire( 'active_diff', 'Active', 'h',
                                         clg=UncoloredCenterLineGrid( pitch=activePitch, width=activeWidth, offset=activeOffset),
                                         spg=SingleGrid( pitch=self.pdk['Poly']['Pitch'], offset=(self.gateDummy-1)*self.pdk['Poly']['Pitch']+self.pdk['Poly']['Pitch']//2)))

        self.RVT_diff = self.addGen( Wire( 'RVT_diff', 'RVT', 'h',
                                         clg=UncoloredCenterLineGrid( pitch=activePitch, width=RvtWidth, offset=activeOffset),
                                         spg=SingleGrid( pitch=self.pdk['Poly']['Pitch'], offset=(self.gateDummy-1)*self.pdk['Poly']['Pitch']+self.pdk['Poly']['Pitch']//2)))

        self.LVT_diff = self.addGen( Wire( 'LVT_diff', 'LVT', 'h',
                                         clg=UncoloredCenterLineGrid( pitch=activePitch, width=RvtWidth, offset=activeOffset),
                                         spg=SingleGrid( pitch=self.pdk['Poly']['Pitch'], offset=(self.gateDummy-1)*self.pdk['Poly']['Pitch']+self.pdk['Poly']['Pitch']//2)))

        self.HVT_diff = self.addGen( Wire( 'HVT_diff', 'HVT', 'h',
                                         clg=UncoloredCenterLineGrid( pitch=activePitch, width=RvtWidth, offset=activeOffset),
                                         spg=SingleGrid( pitch=self.pdk['Poly']['Pitch'], offset=(self.gateDummy-1)*self.pdk['Poly']['Pitch']+self.pdk['Poly']['Pitch']//2)))         

        self.alpha_diff = self.addGen( Wire( 'alpha_diff', 'Alpha', 'h',
                                         clg=UncoloredCenterLineGrid( pitch=activePitch, width=activeWidth, offset=activeOffset),
                                         spg=SingleGrid( pitch=self.pdk['Poly']['Pitch'], offset=(self.gateDummy-1)*self.pdk['Poly']['Pitch']+self.pdk['Poly']['Pitch']//2)))

        self.tt_diff = self.addGen( Wire( 'tt_diff', 'Tt', 'h',
                                         clg=UncoloredCenterLineGrid( pitch=activePitch, width=activeWidth, offset=activeOffset),
                                         spg=SingleGrid( pitch=self.pdk['Poly']['Pitch'], offset=(self.gateDummy-1)*self.pdk['Poly']['Pitch']+self.pdk['Poly']['Pitch']//2)))
        
        stoppoint = (self.gateDummy-1)* self.pdk['Poly']['Pitch'] +  self.pdk['Poly']['Offset']-self.pdk['Active']['activeBpHEnc']
        self.bp = self.addGen( Wire( 'bp', 'Bp', 'h',
                                         clg=UncoloredCenterLineGrid( pitch=activePitch, width=BpWidth, offset=activeOffset),
                                         spg=EnclosureGrid( pitch=unitCellLength, offset=0, stoppoint=stoppoint, check=True)))

        self.bp_diff = self.addGen( Wire( 'bp_diff', 'Bp', 'h',
                                         clg=UncoloredCenterLineGrid( pitch=activePitch, width=BpWidth, offset=activeOffset),
                                         spg=SingleGrid( pitch=self.pdk['Poly']['Pitch'], offset=0)))

        stoppoint = activeOffset-activeWidth//2
        self.ca = self.addGen( Wire( 'ca', 'Ca', 'v',
                                         clg=UncoloredCenterLineGrid( pitch=self.pdk['M1']['Pitch'], width=self.pdk['Ca']['m0Width'], offset=self.pdk['M1']['Offset']),
                                         spg=EnclosureGrid( pitch=self.unitCellHeight, offset=0, stoppoint=stoppoint, check=True)))
                        
        #self.gcut = self.addGen( Wire( 'gcut', 'Gcut', 'h',
        #                              clg=UncoloredCenterLineGrid( pitch= self.pdk['Fin']['Pitch'], width= self.pdk['Gcut']['gcutWidth'], offset= self.pdk['Fin']['Offset']+self.pdk['Gcut']['gcutWidth']//2),
        #                              spg=SingleGrid( offset=0, pitch=unitCellLength)))

        #self.gcut1 = self.addGen( Wire( 'gcut1', 'Gcut', 'h',
        #                              clg=UncoloredCenterLineGrid( pitch= self.pdk['Fin']['Pitch'], width= self.pdk['Gcut']['gcutWidth'], offset= self.pdk['Gcut']['gcutWidth']//2+plspg_offset-self.pdk['Gcut']['plgcutEnc']),
        #                              spg=SingleGrid( offset=0, pitch=unitCellLength)))

        self.gcut_diff = self.addGen( Wire( 'gcut_diff', 'Gcut', 'h',
                                      clg=UncoloredCenterLineGrid( pitch= self.pdk['Fin']['Pitch'], width= self.pdk['Gcut']['gcutWidth'], offset= self.pdk['Fin']['Offset']+self.pdk['Gcut']['gcutWidth']//2),
                                      spg=SingleGrid( offset=0, pitch=self.pdk['Poly']['Pitch'])))
        self.gcut1_diff = self.addGen( Wire( 'gcut1_diff', 'Gcut', 'h',
                                      clg=UncoloredCenterLineGrid( pitch= self.pdk['Fin']['Pitch'], width= self.pdk['Gcut']['gcutWidth'], offset= self.pdk['Gcut']['gcutWidth']//2+plspg_offset-self.pdk['Gcut']['plgcutEnc']),
                                      spg=SingleGrid( offset=0, pitch=self.pdk['Poly']['Pitch'])))

        self.Boundary = self.addGen( Region( 'Boundary', 'Boundary',
                                            v_grid=CenteredGrid( offset= self.pdk['Poly']['Pitch']//2, pitch= self.pdk['Poly']['Pitch']),
                                            h_grid=self.fin.clg))

        self.nwell = self.addGen( Region( 'nwell', 'Nwell',
                                            v_grid=self.pin3.clg,
                                            h_grid=self.fin.clg))

        stoppoint = unitCellLength//2-self.pdk['Tt']['ttbWidth_H']//2
        offset_active_body = (self.lFin//2)*self.pdk['Fin']['Pitch']-self.pdk['Fin']['Pitch']
        self.ttb = self.addGen( Wire( 'ttb', 'Tt', 'h',
                                         clg=UncoloredCenterLineGrid( pitch=activePitch, width=self.pdk['Ttb']['WidthY'], offset= offset_active_body),
                                         spg=EnclosureGrid( pitch=unitCellLength, offset=0, stoppoint=stoppoint, check=True)))

        stoppoint = unitCellLength//2-self.pdk['Active']['activebWidth_H']//2 
        self.activeb = self.addGen( Wire( 'activeb', 'Active', 'h',
                                         clg=UncoloredCenterLineGrid( pitch=activePitch, width=self.pdk['Ttb']['WidthY'], offset=offset_active_body),
                                         spg=EnclosureGrid( pitch=unitCellLength, offset=0, stoppoint=stoppoint, check=True)))
       
        #self.activeb = self.addGen( Wire( 'activeb', 'Active', 'h',
        #                                 clg=UncoloredCenterLineGrid( pitch=activePitch, width=self.pdk['Ttb']['WidthY'], offset= 7*self.pdk['Fin']['Pitch']+self.unitCellHeight-self.pdk['Fin']['Pitch']//2),
        #                                 spg=EnclosureGrid( pitch=unitCellLength, offset=0, stoppoint=stoppoint, check=True)))

        stoppoint = unitCellLength//2-self.pdk['Bp']['bpbWidth_H']//2
        self.bpb = self.addGen( Wire( 'bpb', 'Bp', 'h',
                                         clg=UncoloredCenterLineGrid( pitch=activePitch, width=self.pdk['Bp']['bpbWidth'], offset= offset_active_body),
                                         spg=EnclosureGrid( pitch=unitCellLength, offset=0, stoppoint=stoppoint, check=True)))


        #self.activeb_diff = self.addGen( Wire( 'activeb_diff', 'Active', 'h',
        #                                 clg=UncoloredCenterLineGrid( pitch=activePitch, width=self.pdk['Ttb']['WidthY'], offset= offset_active_body),
        #                                 spg=SingleGrid( pitch=self.pdk['Poly']['Pitch'], offset=(self.gateDummy-1)*self.pdk['Poly']['Pitch']+self.pdk['Poly']['Pitch']//2)))

        self.ttb_diff = self.addGen( Region( 'ttb_diff', 'Tt',
                                            v_grid=CenteredGrid( offset= 1, pitch=2),
                                             h_grid=CenteredGrid( offset= 0, pitch=self.pdk['Fin']['Pitch'])))

        self.bpb_diff = self.addGen( Region( 'bpb_diff', 'Bp',
                                            v_grid=CenteredGrid( offset= 1, pitch=2),
                                             h_grid=CenteredGrid( offset= self.pdk['Fin']['Pitch']//2, pitch=self.pdk['Fin']['Pitch'])))

        self.activeb_diff = self.addGen( Region( 'activeb_diff', 'Active',
                                            v_grid=CenteredGrid( offset= 1, pitch=2),
                                             h_grid=CenteredGrid( offset= 0, pitch=self.pdk['Fin']['Pitch'])))          

        self.va = self.addGen( Via( 'va', 'V0',
                                    h_clg=self.m2.clg,
                                    v_clg=self.m1.clg,
                                    WidthX=self.pdk['V0']['WidthX'],
                                    WidthY=self.pdk['V0']['WidthY']))

        self.v0 = self.addGen( Via( 'v0', 'V0',
                                    h_clg=CenterLineGrid(),
                                    v_clg=self.m1.clg,
                                    WidthX=self.pdk['V0']['WidthX'],
                                    WidthY=self.pdk['V0']['WidthY']))
        
        self.v0.h_clg.addCenterLine( 0,                 self.pdk['V0']['WidthY'], False) 
        v0pitch = 3*self.pdk['Fin']['Pitch']   
        v0Offset = ((self.finDummy+1)//2)*self.pdk['M2']['Pitch']
        v0Number = math.ceil(activeWidth / v0pitch)
        for i in range(v0Number):
            self.v0.h_clg.addCenterLine(i*v0pitch+v0Offset,    self.pdk['V0']['WidthY'], True)
        self.v0.h_clg.addCenterLine( self.unitCellHeight,    self.pdk['V0']['WidthY'], False)

        info = self.pdk['V0']
        #def single_centered_via(rect):
        #    xpos = ( rect[0] + rect[2] ) // 2
        #    ypos = ( rect[1] + rect[3] ) // 2
        #    return [xpos - info['WidthX'] // 2, ypos - info['WidthY'] // 2, xpos + info['WidthX'] // 2, ypos + info['WidthY'] // 2]

        #self.postprocessor.register('V0', single_centered_via)


    def _addMOS( self, x, y, x_cells, vt_type, name='M1', reflect=False, **parameters):

        fullname = f'{name}_X{x}_Y{y}'
        self.subinsts[fullname].parameters.update(parameters)

        def _connect_diffusion(i, pin):
            self.addWire( self.m1, None, None, i, (grid_y0, -1), (grid_y1, 1))
            self.addWire( self.ca, None, None, i, (y, 1), (y+1, -1))
            for j in range(1,self.v0.h_clg.n):
                '''if self.shared_diff==1 and pin=='D' and x%3==0 and j in [3*xx+1 for xx in range(100)]:
                    continue
                if self.shared_diff==1 and pin == 'D' and x%3 == 1 and j in [3*xx+2 for xx in range(100)]:
                    continue
                if self.shared_diff==1 and pin == 'D' and x%3 == 2 and j in [3*xx+3 for xx in range(100)]:
                    continue'''
                self.addVia( self.v0, f'{fullname}:{pin}', None, i, (y, j))
            self._xpins[name][pin].append(i)

        # Draw FEOL Layers
        
        if self.shared_diff == 0:
            self.addWire( self.active, None, None, y, (x,1), (x+1,-1)) 
            self.addWire( self.tt, None, None, y, (x,1), (x+1,-1)) 
            self.addWire( self.alpha, None, None, y, (x,1), (x+1,-1))
        else:
            pass
         
        for i in range(self.gatesPerUnitCell):
            self.addWire( self.pl, None, None, self.gatesPerUnitCell*x+self.gateDummy*self.shared_diff+i,   (y,1), (y+1,-1))
            self.addWire( self.tb, None, None, self.gatesPerUnitCell*x+self.gateDummy*self.shared_diff+i,   (y,1), (y+1,-1))
            if self.shared_diff == 0 and (i == self.gateDummy-1 or i == self.gatesPerUnitCell-self.gateDummy):
                aux_layer = self.aux1 if y==0 else self.aux
                self.addWire( aux_layer, None, None, self.gatesPerUnitCell*x+i,   (y,1), (y+1, -1))
        
        if self.shared_diff == 1 and x == 0:
            for kkx in [0,1]:
                dummy_gates = self.gatesPerUnitCell*x_cells+self.gateDummy if kkx == 1 else 0
                dummy_aux = self.gatesPerUnitCell*x_cells+self.gateDummy if kkx == 1 else self.gateDummy-1
                aux_layer = self.aux1 if y==0 else self.aux
                self.addWire( aux_layer, None, None, dummy_aux,   (y,1), (y+1, -1))
                for i in range(self.gateDummy):
                    self.addWire( self.pl, None, None, dummy_gates+i,   (y,1), (y+1,-1))
                    self.addWire( self.tb, None, None, dummy_gates+i,   (y,1), (y+1,-1))           
        if x == 0:
            #self.addWire( self.pl_dummy, None, None, -5,   (y,1), (y+1,-1))
            for kkx in [0,1]:
                dummy_gates = self.gatesPerUnitCell*x_cells+2*self.gateDummy*self.shared_diff+self.pdk['Boundary']['Dummies'] if kkx == 1 else 0
                dummy_pc = self.gatesPerUnitCell*x_cells+2*self.gateDummy*self.shared_diff+self.pdk['Boundary']['Dummies']+2 if kkx == 1 else -self.pdk['Boundary']['Dummies']-2
                self.addWire( self.pl_dummy, None, None, dummy_pc,   (y,1), (y+1,-1))
                for i in range(-self.pdk['Boundary']['Dummies'], 0):
                    self.addWire( self.pl, None, None, dummy_gates+i,   (y,1), (y+1,-1))
                    self.addWire( self.tb, None, None, dummy_gates+i,   (y,1), (y+1,-1))              

        # Source, Drain, Gate Connections
        grid_y0 = y*self.m2PerUnitCell + 3
        grid_y1 = (y+1)*self.m2PerUnitCell-4 ### 5 needs to be made parameterized 
        gate_x = self.gateDummy*self.shared_diff + x * self.gatesPerUnitCell + self.gatesPerUnitCell // 2
        # Connect Gate (gate_x)        
        self.addWire( self.m1, None, None, gate_x , (grid_y1+2, -1), (grid_y1+5, 1))
        self.addWire( self.cb, None, None, grid_y1+1, (x,1), (x+1,-1))
        self.addVia( self.va, f'{fullname}:G', None, gate_x, grid_y1+2)
        self._xpins[name]['G'].append(gate_x)

        # Connect Source & Drain
        (center_terminal, side_terminal) = ('S', 'D') if self.gate%4 == 0 else ('D', 'S')
        center_terminal = 'D' if self.stack > 1 else center_terminal # for stacked devices
        _connect_diffusion(gate_x, center_terminal)
        for x_terminal in range(1,1+self.gate//2):
            terminal = center_terminal if x_terminal%2 == 0 else side_terminal #for fingers
            if self.stack > 1 and x_terminal != self.gate//2: continue
            terminal = 'S' if self.stack > 1 else terminal 
            if reflect:
                _connect_diffusion(gate_x - x_terminal, terminal)
                _connect_diffusion(gate_x + x_terminal, terminal)
            else:
                _connect_diffusion(gate_x - x_terminal, terminal)
                _connect_diffusion(gate_x + x_terminal, terminal)

    def _connectDevicePins(self, y, connections, x_cells):
        center_track = y * self.m2PerUnitCell + self.m2PerUnitCell // 2 # used for M1-exten
        grid_y1 = (y+1)*self.m2PerUnitCell-4
        gate_track = 0
        diff_track = 3
        gate_count = 0
        for count in connections:
            gate_count = gate_count+1 if count.startswith('G') else gate_count
        for (net, conn) in connections.items():
            contactsx = {(track, pin) for inst, pins in self._xpins.items()
                              for pin, m1tracks in pins.items()
                              for track in m1tracks if (inst, pin) in conn}
            
            pins = {x[1] for x in contactsx}
            for pin in pins:
                contacts = {x[0] for x in contactsx if x[1]==pin}
                ### number of parallel connections ###
                [minvias_drain, minvias_gate, minvias_source] = [2, 2, 3]               
                if pin == 'D':
                    minvias = minvias_drain
                elif pin == 'G':
                    minvias = minvias_gate
                elif pin == 'S':
                    minvias = minvias_source
                else:
                    print(pin + 'does not exist')

                for j in range(minvias):
                    if pin == 'G' and minvias ==0:
                        break
                    elif pin == 'G':
                        current_track = grid_y1 + 2 + gate_track + 2*j
                        #gate_track = gate_track+1 if gate_count == 2 else gate_track+2
                        minvias = minvias-1
                    else:
                        current_track = y * self.m2PerUnitCell + (len(connections)-gate_count) * j + diff_track   
                        #current_track = y * self.m2PerUnitCell + diff_track
                        #diff_track = diff_track + 1 if pin != 'G' else diff_track
                    self.addWireAndViaSet(net, None, self.m2, self.v1, current_track, contacts)
                    #self.addWire( self.m2, None, None, current_track, (0, 1), (x_cells*self.gatesPerUnitCell, -1))
                    self._nets[net][current_track] = contacts
                diff_track = diff_track + 1 if pin != 'G' else diff_track
                gate_track = gate_track+1 if pin == 'G' else gate_track
                #direction = 1 if current_track > center_track else -1
                #for i in contacts:
                #    self.addWire( self.m1, net, None, i, (center_track, -1 * direction), (current_track, direction))

    def _connectNets(self, x_cells, y_cells): 

        def _get_wire_terminators(intersecting_tracks):
            minx, maxx = min(intersecting_tracks), max(intersecting_tracks)
            # BEGIN: Quick & dirty MinL DRC error fix.
            minL = 2 # TODO: Make this MinL dependent
            L = maxx - minx
            if center_track - minL // 2 <= minx and maxx <= center_track + minL // 2:
                minx, maxx = (center_track - minL // 2, center_track + minL // 2)
            elif L < minL:
                minx, maxx = (minx - (minL - L), maxx) if minx >= center_track else (minx, maxx + (minL - L))
            # END: Quick & dirty MinL DRC error fix.
            return (minx, maxx)

        center_track = (x_cells * self.gatesPerUnitCell) // 2
        #m3start = self.shared_diff+(x_cells * self.gatesPerUnitCell - len(self._nets) * self.minvias) // 2
        m3start = (x_cells * self.gatesPerUnitCell - len(self._nets) * self.minvias) // 2
        trackp = 1
        trackn = 1
        for track, (net, conn) in enumerate(self._nets.items(), start=1):
            kpin = 1
            minvias = 1 if net.startswith('S') else 1 ### should be an even number         
            for j in range(minvias):
                #current_track = m3start + len(self._nets) * j + track+2
                contacts = conn.keys()
                minx, maxx = _get_wire_terminators(conn[min(contacts)])
                trackp = -trackp if trackp%2 == 0 else trackp
                current_track = (minx + maxx)//2 + (trackp//2)
                trackn = trackn+3
                trackp = trackn
                if len(contacts) == 1: # Create m2 terminal
                    i = next(iter(contacts))
                    minx, maxx = _get_wire_terminators(conn[i])
                    self.addWire(self.m2, net, net, i, (minx, -1), (maxx, 1))
                    kpin_loc = (minx+maxx)//2
                    #self.addWire( self.pin, net, net, i, (kpin_loc, -1), (kpin_loc+1, 1))
                else: # create m3 terminal(s)
                    self.addWireAndViaSet(net, net, self.m3, self.v2, current_track, contacts)
                    if kpin == 1:
                        kpin_loc = (max(contacts) + min(contacts))//2
                        #self.addWire( self.pin3, net, net, current_track, (kpin_loc, -1), (kpin_loc+1, 1))
                        kpin = kpin-1
                    else:
                        pass
                    #print(net)
                    # Extend m2 if needed. TODO: What to do if we go beyond cell boundary?
                    for i, locs in conn.items():
                        minx, maxx = _get_wire_terminators([*locs, current_track])
                        self.addWire(self.m2, net, None, i, (minx, -1), (maxx, 1))

        B_pin = x_cells*self.gatesPerUnitCell+2*self.gateDummy*self.shared_diff
        self.addWire( self.m2, 'B', 'B', (y_cells)* self.m2PerUnitCell + self.lFin//4, (0, 1), (100, -1))
        #self.addWire( self.pin, 'B', 'B', (y_cells)* self.m2PerUnitCell + self.lFin//4, (B_pin//2, -1), (B_pin//2+1, 1))
    def _addBodyContact(self, x, y, x_cells, yloc=None, name='M1'):
        fullname = f'{name}_X{x}_Y{y}'
        if yloc is not None:
            y = yloc
        h = self.m2PerUnitCell
        gu = self.gatesPerUnitCell
        gate_x = self.gateDummy*self.shared_diff + x*gu + gu // 2
        gate_x_activeb = self.gateDummy*self.shared_diff + gu // 2
        body_loc = self.pdk['M1']['Pitch']//2        
        if self.shared_diff == 0:
            self.addWire( self.activeb, None, None, y+1, (x,1), (x+1,-1))
            self.addWire( self.ttb, None, None, y+1, (x,1), (x+1,-1)) 
        else:
            pass
        if self.shared_diff == 1 and x == x_cells-1:
            self.addRegion( self.activeb_diff, None, None, (body_loc*gate_x_activeb-45, -1), (2*(y+1)*h+self.lFin//4+1, 1),  (body_loc*gate_x+45, -1), (2*(y+1)*h + self.lFin//4 + self.pdk['Ttb']['WidthY']// self.pdk['Fin']['Pitch'], 1))

        if self.shared_diff == 0 or x % 3 == 0:
            self.addWire( self.m1, None, None, gate_x, ((y+1)*h+3, -1), ((y+1)*h+self.lFin//2-2, 1))
            self.addWire( self.cab, None, None, gate_x, ((y+1)*h+3, -1), ((y+1)*h+self.lFin//2-2, 1))
            self.addVia( self.va, f'{fullname}:B', None, gate_x, (y+1)*h + self.lFin//4)
            self.addVia( self.v1, 'B', None, gate_x, (y+1)*h + self.lFin//4)
            if self.shared_diff == 1:
                self.addRegion( self.ttb_diff, None, None, (body_loc*gate_x-30, -1), (2*(y+1)*h+self.lFin//4+1, 1),  (body_loc*gate_x+30, -1), (2*(y+1)*h + self.lFin//4+self.pdk['Ttb']['WidthY']// self.pdk['Fin']['Pitch'], 1)) 
            else:
                pass
            self._xpins[name]['B'].append(gate_x)
        else:
            pass
   
    def _addPMOS( self, x_cells, y_cells):
        for y in range(y_cells):
            for x in range(x_cells):
                if self.shared_diff == 0:
                    self.addWire( self.bp, None, None, y, (x,1), (x+1,-1))
            if self.shared_diff == 1:
                self.addWire( self.bp_diff,  None, None, y, self.gateDummy-2, self.gate*x_cells+self.gateDummy+2)

    def _addNMOS( self, x_cells, y_cells):
        h = self.m2PerUnitCell
        gu = self.gatesPerUnitCell 
        gate_x_bp = self.gateDummy*self.shared_diff + gu // 2 
        body_loc = self.pdk['M1']['Pitch']//2 
        for x in range(x_cells):
            gate_x = self.gateDummy*self.shared_diff + x*gu + gu // 2
            if self.shared_diff == 0:
                self.addWire( self.bpb, None, None, y_cells, (x,1), (x+1,-1))
            elif self.shared_diff == 1 and x == x_cells-1:
                self.addRegion( self.bpb_diff, None, None, (body_loc*gate_x_bp-75, -1), (2*y_cells*h+self.lFin//4, 1),  (body_loc*gate_x+75, -1), (2*y_cells*h + self.lFin//4 + self.pdk['Bpb']['WidthY']// self.pdk['Fin']['Pitch'], 1))
            else:
                pass     
            
    def _addMOSArray( self, x_cells, y_cells, pattern, vt_type, connections, minvias = 1, **parameters): 
        if minvias * len(connections) > self.m2PerUnitCell - 1:
            self.minvias = (self.m2PerUnitCell - 1) // len(connections)
            logger.warning( f"Using minvias = {self.minvias}. Cannot route {len(connections)} signals using minvias = {minvias} (max m2 / unit cell = {self.m2PerUnitCell})" )
        else:
            self.minvias = minvias
        names = ['M1'] if pattern == 0 else ['M1', 'M2']
        self._nets = collections.defaultdict(lambda: collections.defaultdict(list)) # net:m2track:m1contacts (Updated by self._connectDevicePins)
        self.addWire( self.gcut_diff, None, None,  self.finsPerUnitCell*y_cells, -self.pdk['Boundary']['TrackX'], x_cells*self.gatesPerUnitCell+2*self.shared_diff*self.gateDummy+self.pdk['Boundary']['TrackX'])
        for y in range(y_cells):
            self._xpins = collections.defaultdict(lambda: collections.defaultdict(list)) # inst:pin:m1tracks (Updated by self._addMOS)
            gcut_layer_diff = self.gcut1_diff if y ==0 else self.gcut_diff
            self.addWire( gcut_layer_diff, None, None,  self.finsPerUnitCell*y, -self.pdk['Boundary']['TrackX'], x_cells*self.gatesPerUnitCell+2*self.shared_diff*self.gateDummy+self.pdk['Boundary']['TrackX'])
            if self.shared_diff == 1: 
                self.addWire( self.active_diff, None, None, y, 0, self.gate*x_cells+1)
                self.addWire( self.tt_diff, None, None, y, 0, self.gate*x_cells+1) 
                self.addWire( self.alpha_diff, None, None, y, 0, self.gate*x_cells+1) 
            else:
                pass
            for x in range(x_cells):
                if pattern == 0: # None (single transistor)
                    # TODO: Not sure this works without dummies. Currently:
                    # A A A A A A
                    self._addMOS(x, y, x_cells, vt_type, names[0], False, **parameters)
                    self._addBodyContact(x, y, x_cells, y_cells - 1, names[0])
                elif pattern == 1: # CC
                    # TODO: Think this can be improved. Currently:
                    # A B B A A' B' B' A'
                    # B A A B B' A' A' B'
                    # A B B A A' B' B' A'
                    self._addMOS(x, y, x_cells, vt_type, names[((x // 2) % 2 + x % 2 + (y % 2)) % 2], x >= x_cells // 2, **parameters)
                    self._addBodyContact(x, y, x_cells, y_cells - 1, names[((x // 2) % 2 + x % 2 + (y % 2)) % 2])
                elif pattern == 2: # interdigitated
                    # TODO: Evaluate if this is truly interdigitated. Currently:
                    # A B A B A B
                    # B A B A B A
                    # A B A B A B
                    self._addMOS(x, y, x_cells, vt_type, names[((x % 2) + (y % 2)) % 2], False, **parameters)
                    self._addBodyContact(x, y, x_cells, y_cells - 1, names[((x % 2) + (y % 2)) % 2])
                elif pattern == 3: # CurrentMirror
                    # TODO: Evaluate if this needs to change. Currently:
                    # B B B A A B B B
                    # B B B A A B B B
                    self._addMOS(x, y, x_cells, vt_type, names[0 if 0 <= ((x_cells // 2) - x) <= 1 else 1], False, **parameters)
                    self._addBodyContact(x, y, x_cells, y_cells - 1, names[0 if 0 <= ((x_cells // 2) - x) <= 1 else 1])
                
                elif pattern == 4: # Non-CC
                    # TODO: Think this can be improved. Currently:
                    # A A A A B  B  B  B
                    # A A A A B  B  B  B
                    # A A A A B  B  B  B
                    self._addMOS(x, y, x_cells, vt_type, names[0 if x < (x_cells//2) else 1], x >= x_cells // 2, **parameters)
                    self._addBodyContact(x, y, x_cells, y_cells - 1, names[((x // 2) % 2 + x % 2 + (y % 2)) % 2])

                elif pattern == 5: # non-CC-CurrentMirror
                    # TODO: Evaluate if this needs to change. Currently:
                    # B B B A A B B B
                    # B B B A A B B B
                    self._addMOS(x, y, x_cells, vt_type, names[0 if 0 <= ((x_cells // 2) - x) <= 1 else 1], False, **parameters)
                    self._addBodyContact(x, y, x_cells, y_cells - 1, names[0 if 0 <= ((x_cells // 2) - x) <= 1 else 1])

                elif pattern == 6: # non-CC-CurrentMirror
                    # TODO: Evaluate if this needs to change. Currently:
                    # B B B A A B B B
                    # B B B A A B B B
                    self._addMOS(x, y, x_cells, vt_type, names[0 if 0 <= ((x_cells // 2) - x) <= 1 else 1], False, **parameters)
                    self._addBodyContact(x, y, x_cells, y_cells - 1, names[0 if 0 <= ((x_cells // 2) - x) <= 1 else 1])

                else:
                    assert False, "Unknown pattern"
            self._connectDevicePins(y, connections,x_cells)
        self._connectNets(x_cells, y_cells) 

    def addNMOSArray( self, x_cells, y_cells, pattern, vt_type, connections, **parameters):

        self._addMOSArray(x_cells, y_cells, pattern, vt_type, connections, **parameters)
        self._addNMOS(x_cells, y_cells)

        #####   Nselect Placement   #####
        self.addRegion( self.Boundary, None, None, (-self.pdk['Boundary']['TrackX']-5, -1), -self.pdk['Boundary']['TrackY'], (x_cells*self.gatesPerUnitCell+2*self.gateDummy*self.shared_diff+self.pdk['Boundary']['TrackX']+5, -1), y_cells*self.finsPerUnitCell+self.lFin+self.pdk['Boundary']['TrackY']) 
          
    def addPMOSArray( self, x_cells, y_cells, pattern, vt_type, connections, **parameters):

        self._addMOSArray(x_cells, y_cells, pattern, vt_type, connections, **parameters)
        self._addPMOS(x_cells, y_cells)

        #####   Pselect and Nwell Placement   #####
        #self.addRegion( self.Boundary, None, None, (-self.pdk['Boundary']['TrackX']-5, -1), -self.pdk['Boundary']['TrackY'], (x_cells*self.gatesPerUnitCell+2*self.gateDummy*self.shared_diff+self.pdk['Boundary']['TrackX']+5, -1), y_cells*self.finsPerUnitCell+self.lFin+self.pdk['Boundary']['TrackY'])
        self.addRegion( self.nwell, None, None, (-self.pdk['Boundary']['Dummies']-20), 0, (x_cells*self.gatesPerUnitCell+2*self.gateDummy*self.shared_diff+self.pdk['Boundary']['Dummies']+90), y_cells*self.finsPerUnitCell+self.lFin)
         
