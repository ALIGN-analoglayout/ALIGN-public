from .main import generate_primitives, generate_primitive
