import json
from collections import OrderedDict

def dummy_drc(input_json):
  with open( input_json, "rt") as fp0:
    p = json.load( fp0)

  with open( input_json, "rt") as fp:
    j = json.load( fp) 
    for obj in j['terminals']:
      if obj['layer'] == 'PolyDummy':
        obj['layer'] = 'Tb'
        #obj['rect'] = obj['rect'] + [-30, -30, 30, 30] ## this line does not work?
        obj['rect'][0] = obj['rect'][0]-30
        obj['rect'][1] = obj['rect'][1]-30
        obj['rect'][2] = obj['rect'][2]+30
        obj['rect'][3] = obj['rect'][3]+30
        p['terminals'].append(obj)
  with open( input_json, "wt") as fp0:
    fp0.write( json.dumps( p, indent=2) + '\n')
      
