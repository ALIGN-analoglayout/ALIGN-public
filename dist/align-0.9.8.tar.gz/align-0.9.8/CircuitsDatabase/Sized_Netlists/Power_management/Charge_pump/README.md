## Charge pump

This is a charge pump circuit used in power management systems.
