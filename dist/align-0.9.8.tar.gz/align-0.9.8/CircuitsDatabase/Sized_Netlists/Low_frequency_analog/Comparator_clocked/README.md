## Comparator - clocked
This circuit is a comparator circuit that compares the two inputs at each clock period.

<p align="center">
  <img width=60%" src="image.PNG">
</p>

