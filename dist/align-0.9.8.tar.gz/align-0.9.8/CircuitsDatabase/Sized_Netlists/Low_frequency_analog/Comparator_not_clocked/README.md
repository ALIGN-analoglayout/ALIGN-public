## Comparator - continuous time (not clocked)
This circuit is a comparator circuit that compares the two inputs continuously in time.

<p align="center">
  <img width=60%" src="image.PNG">
</p>