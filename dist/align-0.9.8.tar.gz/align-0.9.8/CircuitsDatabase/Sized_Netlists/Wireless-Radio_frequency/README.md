**Wireless/Radio Frequency**

Circuit | Technology | Netlist | Schematic | Layout | Testbench | Constraints | ALIGN |
:------ | :--------- | :---- | :------ | :-------- | :----- | :-------- | :---------- |
LNA | 65 nm | :heavy_check_mark: | :heavy_check_mark: | :heavy_check_mark: | :heavy_check_mark: |  |  |
Mixer | 65 nm | :heavy_check_mark: | :heavy_check_mark: | :heavy_check_mark: | :heavy_check_mark: |  |  |
Bandpass Filter | 65 nm | :heavy_check_mark: | :heavy_check_mark: | :heavy_check_mark: | :heavy_check_mark: |  |  |
Oscillator | 65 nm | :heavy_check_mark: | :heavy_check_mark: | :heavy_check_mark: | :heavy_check_mark: |  |  |
