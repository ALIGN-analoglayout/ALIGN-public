# To run permuation.py tests

First install:
```
cd tally
pip install -e .
cd -
```

Then run the tests:
```
pytest -s -- permutation.py
```
