#!/bin/bash
argo delete route
argo submit --watch route_artifacts.argo --name route -p show-metal-templates=""
