#!/bin/bash

./flow-json.sh -n wcap $*
