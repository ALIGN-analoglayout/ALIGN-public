#!/bin/bash

./flow-json.sh -n mirrors $*
