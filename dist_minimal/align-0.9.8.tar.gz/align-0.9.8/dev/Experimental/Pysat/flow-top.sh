#!/bin/bash

./flow-json.sh -n top --small $*
