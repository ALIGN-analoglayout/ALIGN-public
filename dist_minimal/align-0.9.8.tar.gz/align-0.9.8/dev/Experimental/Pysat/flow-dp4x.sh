#!/bin/bash

./flow-json.sh -n dp4x $*
