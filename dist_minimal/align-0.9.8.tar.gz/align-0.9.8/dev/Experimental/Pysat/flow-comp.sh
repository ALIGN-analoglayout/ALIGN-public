#!/bin/bash
./flow-json.sh -n comp $*
