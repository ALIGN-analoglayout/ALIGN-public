#!/bin/bash

./flow-json.sh -n ctle $*
