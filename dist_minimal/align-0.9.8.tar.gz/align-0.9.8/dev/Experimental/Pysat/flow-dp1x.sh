#!/bin/bash

./flow-json.sh -n dp1x $*
