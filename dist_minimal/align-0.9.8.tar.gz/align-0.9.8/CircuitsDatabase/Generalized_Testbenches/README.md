## Testbench

Generic testbenches that can be used to extensively test common circuits (for eg. single-ended OTA) irrespective of the small variations in their topology (for eg. single-ended folded cascode OTA, single-ended telescopic OTA, etc.)

