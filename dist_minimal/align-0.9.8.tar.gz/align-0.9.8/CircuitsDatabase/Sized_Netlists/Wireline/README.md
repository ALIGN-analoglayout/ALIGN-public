## **Wireline**

Circuit | Technology | Netlist | Schematic | Layout | Testbench | Constraints | ALIGN |
:------ | :--------- | :---- | :------ | :-------- | :----- | :-------- | :---------- |
Single to differential converter | 12 nm | :heavy_check_mark: | :heavy_check_mark: | :heavy_check_mark: | :heavy_check_mark: |  | :heavy_check_mark: |
Adder | 12 nm | :heavy_check_mark: | :heavy_check_mark: | :heavy_check_mark: | :heavy_check_mark: |  | :heavy_check_mark: |
Double tail sense amplifier | 12 nm | :heavy_check_mark: | :heavy_check_mark: | :heavy_check_mark: |  |  | :heavy_check_mark: |
Linear Equalizer 2 switches | 12 nm | :heavy_check_mark: | :heavy_check_mark: | :heavy_check_mark: | :heavy_check_mark: |  | :heavy_check_mark: |
Linear Equalizer 4 switches | 12 nm | :heavy_check_mark: | :heavy_check_mark: | :heavy_check_mark: | :heavy_check_mark: |  | :heavy_check_mark: |
Transimpedance amplifier | 12 nm | :heavy_check_mark: | :heavy_check_mark: | :heavy_check_mark: | :heavy_check_mark: |  | :heavy_check_mark: |
Variable gain amplifier | 12 nm | :heavy_check_mark: | :heavy_check_mark: | :heavy_check_mark: | :heavy_check_mark: |  | :heavy_check_mark: |
Variable gain amplifier 4 level | 12 nm | :heavy_check_mark: | :heavy_check_mark: | :heavy_check_mark: | :heavy_check_mark: |  | :heavy_check_mark: |
