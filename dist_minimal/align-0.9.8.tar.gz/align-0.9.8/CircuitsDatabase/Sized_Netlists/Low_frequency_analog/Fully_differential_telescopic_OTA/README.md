## Telescopic OTA - fully differential

This is a fully differential telescopic OTA circuit.
