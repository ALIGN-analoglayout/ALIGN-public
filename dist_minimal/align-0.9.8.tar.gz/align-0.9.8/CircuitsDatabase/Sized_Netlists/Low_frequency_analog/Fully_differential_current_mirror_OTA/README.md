## Current mirror OTA - fully differential

This is a fully differential current mirror OTA circuit.
