# **Power Management**

Circuit | Technology | Netlist | Schematic | Manual Layout | Testbench | Constraints | ALIGN |
:------ | :--------- | :---- | :------ | :-------- | :----- | :-------- | :---------- |
Charge pump | 65 nm | :heavy_check_mark: | :heavy_check_mark: | :heavy_check_mark: |  |  |  |
Gate driver in DLDO | 65 nm | :heavy_check_mark: | :heavy_check_mark: | :heavy_check_mark: |  |  |  |
1:1 SC DC DC converter | 12 nm | :heavy_check_mark: | :heavy_check_mark: |  | :heavy_check_mark: | :heavy_check_mark: | :heavy_check_mark: |
3:1 SC DC DC converter | 12 nm | :heavy_check_mark: | :heavy_check_mark: |  | :heavy_check_mark: | :heavy_check_mark: | :heavy_check_mark: |