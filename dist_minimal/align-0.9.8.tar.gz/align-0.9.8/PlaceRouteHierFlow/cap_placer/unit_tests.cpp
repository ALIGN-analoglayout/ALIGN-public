
#include <gtest/gtest.h>

TEST(CapPlacerTest, True) {
    EXPECT_TRUE( 1);
};

