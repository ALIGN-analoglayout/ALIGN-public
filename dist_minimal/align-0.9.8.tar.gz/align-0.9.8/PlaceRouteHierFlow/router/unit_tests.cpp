
#include <gtest/gtest.h>

TEST(RouterTest, True) {
    EXPECT_TRUE( 1);
};

