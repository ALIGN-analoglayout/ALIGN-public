#include "ILP_solver.h"
#include "spdlog/spdlog.h"
#include <iostream>
#include <algorithm>
#include <signal.h>
#include "ILPSolverIf.h"

#define FALSE 0
#define TRUE 1

ExtremeBlocksOfNet::ExtremeBlocksOfNet(const SeqPair& sp, const int N)
{
  for (unsigned i = 0; i < sp.posPair.size(); ++i) {
    _posPosition[sp.posPair[i]] = i;
    _negPosition[sp.negPair[i]] = i;
  }
  _ltExtreme.resize(N); _rtExtreme.resize(N);
  _topExtreme.resize(N); _botExtreme.resize(N);
}

void ExtremeBlocksOfNet::FindExtremes(const placerDB::net& n, const int neti)
{
  _ltExtreme[neti].clear(); _rtExtreme[neti].clear();
  _botExtreme[neti].clear(); _topExtreme[neti].clear();
  std::set<int> blocks;
  for (const auto& con : n.connected) {
    if (con.type == placerDB::Block) {
      blocks.insert(con.iter2);
    }
  }
  std::vector<int> blks(blocks.begin(), blocks.end());
  std::vector<int> abOf(blks.size(), 1), beOf(blks.size(), 1);
  std::vector<int> ltOf(blks.size(), 1), rtOf(blks.size(), 1);
  for (unsigned i = 0; i < blks.size(); ++i) {
    const auto& blki = blks[i];
    for (unsigned j = i+1; j < blks.size(); ++j) {
      const auto& blkj = blks[j];
      if (_posPosition[blki] < _posPosition[blkj]) {
        if (_negPosition[blki] < _negPosition[blkj]) {
          rtOf[i] = 0;
          ltOf[j] = 0;
        } else {
          beOf[i] = 0;
          abOf[j] = 0;
        }
      } else {
        if (_negPosition[blki] > _negPosition[blkj]) {
          rtOf[j] = 0;
          ltOf[i] = 0;
        } else {
          abOf[i] = 0;
          beOf[j] = 0;
        }
      }
    }
  }
  for (unsigned i = 0; i < blks.size(); ++i) {
    if (abOf[i]) _topExtreme[neti].insert(blks[i]);
    if (beOf[i]) _botExtreme[neti].insert(blks[i]);
    if (rtOf[i]) _rtExtreme[neti].insert(blks[i]);
    if (ltOf[i]) _ltExtreme[neti].insert(blks[i]);
  }
}

ILP_solver::ILP_solver() {}

ILP_solver::ILP_solver(design& mydesign, PnRDB::hierNode& node) {
  auto logger = spdlog::default_logger()->clone("placer.ILP_solver.ILP_solver");
  LL.x = INT_MAX;
  LL.y = INT_MAX;
  UR.x = INT_MIN;
  UR.x = INT_MIN;
  Blocks.resize(mydesign.Blocks.size());
  Aspect_Ratio_weight = mydesign.Aspect_Ratio_weight;
  // first correct global placement result
  for (const auto& symmetry : mydesign.SPBlocks) {
    if (symmetry.axis_dir == placerDB::V) {
      set<int> center_y_set;
      set<int> distance_set;
      int center_x = 0;
      for (const auto& i_selfsym : symmetry.selfsym) {
        center_x += node.Blocks[i_selfsym.first].instance[0].placedCenter.x;
      }
      for (const auto& i_sympair : symmetry.sympair) {
        center_x += node.Blocks[i_sympair.first].instance[0].placedCenter.x;
        center_x += node.Blocks[i_sympair.second].instance[0].placedCenter.x;
      }
      center_x /= (symmetry.selfsym.size() + symmetry.sympair.size() * 2);
      for (const auto& i_selfsym : symmetry.selfsym) {
        while (center_y_set.find(node.Blocks[i_selfsym.first].instance[0].placedCenter.y) != center_y_set.end())
          node.Blocks[i_selfsym.first].instance[0].placedCenter.y++;
        center_y_set.insert(node.Blocks[i_selfsym.first].instance[0].placedCenter.y);
        node.Blocks[i_selfsym.first].instance[0].placedCenter.x = center_x;
      }
      for (const auto& i_sympair : symmetry.sympair) {
        int diff = center_x - (node.Blocks[i_sympair.first].instance[0].placedCenter.x + node.Blocks[i_sympair.second].instance[0].placedCenter.x) / 2;
        node.Blocks[i_sympair.first].instance[0].placedCenter.x += diff-1;
        node.Blocks[i_sympair.second].instance[0].placedCenter.x += diff+1;
        while(distance_set.find(abs(node.Blocks[i_sympair.first].instance[0].placedCenter.x-node.Blocks[i_sympair.second].instance[0].placedCenter.x))!=distance_set.end()){
          node.Blocks[i_sympair.first].instance[0].placedCenter.x--;
          node.Blocks[i_sympair.second].instance[0].placedCenter.x++;
        }
        distance_set.insert(abs(node.Blocks[i_sympair.first].instance[0].placedCenter.x - node.Blocks[i_sympair.second].instance[0].placedCenter.x));
        int center_y = (node.Blocks[i_sympair.first].instance[0].placedCenter.y + node.Blocks[i_sympair.second].instance[0].placedCenter.y) / 2;
        while (center_y_set.find(center_y) != center_y_set.end()) center_y++;
        center_y_set.insert(center_y);
        node.Blocks[i_sympair.first].instance[0].placedCenter.y = center_y;
        node.Blocks[i_sympair.second].instance[0].placedCenter.y = center_y;
      }
    } else {
      set<int> center_x_set;
      set<int> distance_set;
      int center_y = 0;
      for (const auto& i_selfsym : symmetry.selfsym) {
        center_y += node.Blocks[i_selfsym.first].instance[0].placedCenter.y;
      }
      for (const auto& i_sympair : symmetry.sympair) {
        center_y += node.Blocks[i_sympair.first].instance[0].placedCenter.y;
        center_y += node.Blocks[i_sympair.second].instance[0].placedCenter.y;
      }
      center_y /= (symmetry.selfsym.size() + symmetry.sympair.size() * 2);
      for (const auto& i_selfsym : symmetry.selfsym) {
        while (center_x_set.find(node.Blocks[i_selfsym.first].instance[0].placedCenter.x) != center_x_set.end())
          node.Blocks[i_selfsym.first].instance[0].placedCenter.x++;
        center_x_set.insert(node.Blocks[i_selfsym.first].instance[0].placedCenter.x);
        node.Blocks[i_selfsym.first].instance[0].placedCenter.y = center_y;
      }
      for (const auto& i_sympair : symmetry.sympair) {
        int diff = center_y - (node.Blocks[i_sympair.first].instance[0].placedCenter.y + node.Blocks[i_sympair.second].instance[0].placedCenter.y) / 2;
        node.Blocks[i_sympair.first].instance[0].placedCenter.y += diff;
        node.Blocks[i_sympair.second].instance[0].placedCenter.y += diff;
        while(distance_set.find(abs(node.Blocks[i_sympair.first].instance[0].placedCenter.y-node.Blocks[i_sympair.second].instance[0].placedCenter.y))!=distance_set.end()){
          node.Blocks[i_sympair.first].instance[0].placedCenter.y--;
          node.Blocks[i_sympair.second].instance[0].placedCenter.y++;
        }
        distance_set.insert(abs(node.Blocks[i_sympair.first].instance[0].placedCenter.y - node.Blocks[i_sympair.second].instance[0].placedCenter.y));
        int center_x = (node.Blocks[i_sympair.first].instance[0].placedCenter.x + node.Blocks[i_sympair.second].instance[0].placedCenter.x) / 2;
        while (center_x_set.find(center_x) != center_x_set.end()) center_x++;
        center_x_set.insert(center_x);
        node.Blocks[i_sympair.first].instance[0].placedCenter.x = center_x;
        node.Blocks[i_sympair.second].instance[0].placedCenter.x = center_x;
      }
    }
  }
  // correct alignblocks position
  for (const auto& align : mydesign.Align_blocks) {
    if (align.horizon) {
      int LLy = 0;
      set<int> center_x_set;
      for (unsigned int i = 0; i < align.blocks.size(); i++) {
        LLy += node.Blocks[align.blocks[i]].instance[0].placedCenter.y - node.Blocks[align.blocks[i]].instance[0].height / 2;
      }
      LLy /= align.blocks.size();
      for (unsigned int i = 0; i < align.blocks.size(); i++) {
        while(center_x_set.find(node.Blocks[align.blocks[i]].instance[0].placedCenter.x)!=center_x_set.end())
          node.Blocks[align.blocks[i]].instance[0].placedCenter.x++;
        center_x_set.insert(node.Blocks[align.blocks[i]].instance[0].placedCenter.x);
        node.Blocks[align.blocks[i]].instance[0].placedCenter.y = LLy + node.Blocks[align.blocks[i]].instance[0].height / 2;
      }
    } else {
      int LLx = 0;
      set<int> center_y_set;
      for (unsigned int i = 0; i < align.blocks.size(); i++) {
        LLx += node.Blocks[align.blocks[i]].instance[0].placedCenter.x - node.Blocks[align.blocks[i]].instance[0].width / 2;
      }
      LLx /= align.blocks.size();
      for (unsigned int i = 0; i < align.blocks.size(); i++) {
        while(center_y_set.find(node.Blocks[align.blocks[i]].instance[0].placedCenter.y)!=center_y_set.end())
          node.Blocks[align.blocks[i]].instance[0].placedCenter.y++;
        center_y_set.insert(node.Blocks[align.blocks[i]].instance[0].placedCenter.y);
        node.Blocks[align.blocks[i]].instance[0].placedCenter.x = LLx + node.Blocks[align.blocks[i]].instance[0].width / 2;
      }
    }
  }
  block_order = vector<vector<int>>(mydesign.Blocks.size(), vector<int>(mydesign.Blocks.size(), 0));
  // from LSB to MSB: at the left, align to left, the same x center, align to right, at the right, reserved, reserved, reserved
  // below, align to the bottom, the same y center, align to the top, above, reserved, reserved, reserved
  // block[i][j]&0x0010==0x0010 means i is to the right of j

  /**
  vector<pair<vector<vector<int>>, PnRDB::Smark>> ordering_alignblock;
  for (auto order : node.Ordering_Constraints) {
    pair<vector<vector<int>>, PnRDB::Smark> temp;
    temp.second = order.second;
    for (auto i : order.first) {
      vector<int> temp_seq = {i};
      for (auto align : node.Align_blocks) {
        if (order.second == PnRDB::H && align.horizon == 0 || order.second == PnRDB::V && align.horizon == 1) {
          if (find(align.blocks.begin(), align.blocks.end(), i) != align.blocks.end())
            for (auto b : align.blocks)
              if (b != i) temp_seq.push_back(b);
        }
      }
      temp.first.push_back(temp_seq);
      // group alignblock into the same order group
    }
    ordering_alignblock.push_back(temp);
  }
  **/
  for (const auto& order : node.Ordering_Constraints) {
    if (order.second == PnRDB::H) {
      for (unsigned int i = 0; i < order.first.size() - 1; i++) {
        for (unsigned int j = i + 1; j < order.first.size(); j++) {
          int blocki = order.first[i];
          int blockj = order.first[j];
          if (blocki < blockj)
            // i is at the left of j
            block_order[blocki][blockj] |= 0x0001;
          else
            // j is at the right of i
            block_order[blockj][blocki] |= 0x0010;
        }
      }
    }else{
      for (unsigned int i = 0; i < order.first.size() - 1; i++) {
        for (unsigned int j = i + 1; j < order.first.size(); j++) {
          int blocki = order.first[i];
          int blockj = order.first[j];
          if (blocki < blockj)
            // i is above j
            block_order[blocki][blockj] |= 0x1000;
          else
            // j is below i
            block_order[blockj][blocki] |= 0x0100;
        }
      }
    }
  }
  /**
  for (auto order : ordering_alignblock) {
    if (order.second == PnRDB::H) {
      for (unsigned int i = 0; i < order.first.size() - 1; i++) {
        for (unsigned int j = i + 1; j < order.first.size(); j++) {
          for (auto blocki : order.first[i]) {
            for (auto blockj : order.first[j]) {
              if (blocki < blockj)
                // i is at the left of j
                block_order[blocki][blockj] |= 0x0001;
              else
                // j is at the right of i
                block_order[blockj][blocki] |= 0x0010;
            }
          }
        }
      }
    } else {
      for (unsigned int i = 0; i < order.first.size() - 1; i++) {
        for (unsigned int j = i + 1; j < order.first.size(); j++) {
          for (auto blocki : order.first[i]) {
            for (auto blockj : order.first[j]) {
              if (blocki < blockj)
                // i is above j
                block_order[blocki][blockj] |= 0x1000;
              else
                // j is below i
                block_order[blockj][blocki] |= 0x0100;
            }
          }
        }
      }
    }
  }
  **/
  for (const auto& align : mydesign.Align_blocks) {
    if (align.horizon) {
      vector<int> blocks(align.blocks);
      sort(blocks.begin(), blocks.end());
      for (unsigned int i = 0; i < blocks.size(); i++) {
        for (unsigned int j = i + 1; j < blocks.size(); j++){
          if (block_order[blocks[i]][blocks[j]] & 0xff00)
            logger->error("wrong constraint between block {0} and {1}", mydesign.Blocks[blocks[i]][0].name, mydesign.Blocks[blocks[j]][0].name);
          else
            block_order[blocks[i]][blocks[j]] |= 0x0200;  // i and j align to the bottom
        }
      }
    } else {
      vector<int> blocks(align.blocks);
      sort(blocks.begin(), blocks.end());
      for (unsigned int i = 0; i < blocks.size(); i++) {
        for (unsigned int j = i + 1; j < blocks.size(); j++){
          if (block_order[blocks[i]][blocks[j]] & 0x00ff)
            logger->error("wrong constraint between block {0} and {1}", mydesign.Blocks[blocks[i]][0].name, mydesign.Blocks[blocks[j]][0].name);
          else
            block_order[blocks[i]][blocks[j]] |= 0x0002;  // i and j align to the left
        }
      }
    }
  }
  for (const auto& symmetry : mydesign.SPBlocks) {
    if (symmetry.axis_dir == placerDB::V) {
      for (const auto& pair : symmetry.sympair) {
        int first = pair.first, second = pair.second;
        if (first > second) std::swap(first, second);
        if (block_order[first][second] & 0x1100)
          logger->error("wrong constraint between block {0} and {1}", mydesign.Blocks[first][0].name, mydesign.Blocks[second][0].name);
        else if (block_order[first][second] & 0x0a00 && mydesign.Blocks[first][0].height != mydesign.Blocks[second][0].height)
          logger->error("wrong constraint between block {0} and {1}", mydesign.Blocks[first][0].name, mydesign.Blocks[second][0].name);
        else {
          block_order[first][second] &= 0x00ff;
          block_order[first][second] |= 0x0400;  // i and j have the same y center
        }
      }
      for (unsigned int i = 0; i < symmetry.selfsym.size();i++){
        for (unsigned int j = i + 1; j < symmetry.selfsym.size(); j++) {
          int first = symmetry.selfsym[i].first, second = symmetry.selfsym[j].first;
          if (first > second) std::swap(first, second);
          block_order[first][second] |= 0x0004;
          if (block_order[first][second] & 0x1100) continue;
          if (node.Blocks[first].instance[0].placedCenter.y < node.Blocks[second].instance[0].placedCenter.y)
            block_order[first][second] |= 0x0100;
          else
            block_order[first][second] |= 0x1000;
        }
      }
    } else {
      for (const auto& pair : symmetry.sympair) {
        int first = pair.first, second = pair.second;
        if (first > second) std::swap(first, second);
        if (block_order[first][second] & 0x0011)
          logger->error("wrong constraint between block {0} and {1}", mydesign.Blocks[first][0].name, mydesign.Blocks[second][0].name);
        else if (block_order[first][second] & 0x000a && mydesign.Blocks[first][0].width != mydesign.Blocks[second][0].width)
          logger->error("wrong constraint between block {0} and {1}", mydesign.Blocks[first][0].name, mydesign.Blocks[second][0].name);
        else {
          block_order[first][second] &= 0xff00;
          block_order[first][second] |= 0x0004;  // i and j have the same x center
        }
      }
      for (unsigned int i = 0; i < symmetry.selfsym.size();i++){
        for (unsigned int j = i + 1; j < symmetry.selfsym.size(); j++) {
          int first = symmetry.selfsym[i].first, second = symmetry.selfsym[j].first;
          if (first > second) std::swap(first, second);
          if (block_order[first][second] & 0x0011) continue;
          block_order[first][second] |= 0x0400;
          if (node.Blocks[first].instance[0].placedCenter.x < node.Blocks[second].instance[0].placedCenter.x)
            block_order[first][second] |= 0x0001;
          else
            block_order[first][second] |= 0x0010;
        }
      }
    }
  }
  int count = 0;
  for (unsigned int i = 0; i < node.Blocks.size() - 1; i++) {
    for (unsigned int j = i + 1; j < node.Blocks.size(); j++) {
      if ((block_order[i][j] & 0x000e) && (block_order[i][j] & 0x0e00))
        logger->error("wrong constranit between block {0} and {1}", mydesign.Blocks[i][0].name, mydesign.Blocks[j][0].name);
      if(node.Blocks[i].instance[0].width==0){
        block_order[i][j] |= 0x0001;
      }
      if ((block_order[i][j] & 0x1111) == 0) {  // neither left right below above
        if (block_order[i][j] & 0x00ff) {
          // align to left, x center, or right
          block_order[i][j] &= 0x00ff;
          if (node.Blocks[i].instance[0].placedCenter.y < node.Blocks[j].instance[0].placedCenter.y){
            block_order[i][j] |= 0x0100;
            int i_counterpart = mydesign.SPBlocks[mydesign.Blocks[i][0].SBidx].axis_dir == placerDB::V ? mydesign.Blocks[i][0].counterpart : -1;
            int j_counterpart = mydesign.SPBlocks[mydesign.Blocks[j][0].SBidx].axis_dir == placerDB::V ? mydesign.Blocks[j][0].counterpart : -1;
            if (i_counterpart != -1) {
              if (i_counterpart < j && ((block_order[i_counterpart][j] & 0x1111) == 0)) block_order[i_counterpart][j] |= 0x0100;
              if (i_counterpart > j && ((block_order[j][i_counterpart] & 0x1111) == 0)) block_order[j][i_counterpart] |= 0x1000;
            }
            if(j_counterpart!=-1){
              if (i < j_counterpart && ((block_order[i][j_counterpart] & 0x1111) == 0)) block_order[i][j_counterpart] |= 0x0100;
              if (i > j_counterpart && ((block_order[j_counterpart][i] & 0x1111) == 0)) block_order[j_counterpart][i] |= 0x1000;
            }
            if(i_counterpart!=-1 && j_counterpart!=-1){
              if (i_counterpart < j_counterpart && ((block_order[i_counterpart][j_counterpart] & 0x1111) == 0))
                block_order[i_counterpart][j_counterpart] |= 0x0100;
              if (i_counterpart > j_counterpart && ((block_order[j_counterpart][i_counterpart] & 0x1111) == 0))
                block_order[j_counterpart][i_counterpart] |= 0x1000;
            }
          } else {
            block_order[i][j] |= 0x1000;
            int i_counterpart = mydesign.SPBlocks[mydesign.Blocks[i][0].SBidx].axis_dir == placerDB::V ? mydesign.Blocks[i][0].counterpart : -1;
            int j_counterpart = mydesign.SPBlocks[mydesign.Blocks[j][0].SBidx].axis_dir == placerDB::V ? mydesign.Blocks[j][0].counterpart : -1;
            if (i_counterpart != -1) {
              if (i_counterpart < j && ((block_order[i_counterpart][j] & 0x1111) == 0)) block_order[i_counterpart][j] |= 0x1000;
              if (i_counterpart > j && ((block_order[j][i_counterpart] & 0x1111) == 0)) block_order[j][i_counterpart] |= 0x0100;
            }
            if(j_counterpart!=-1){
              if (i < j_counterpart && ((block_order[i][j_counterpart] & 0x1111) == 0)) block_order[i][j_counterpart] |= 0x1000;
              if (i > j_counterpart && ((block_order[j_counterpart][i] & 0x1111) == 0)) block_order[j_counterpart][i] |= 0x0100;
            }
            if(i_counterpart!=-1 && j_counterpart!=-1){
              if (i_counterpart < j_counterpart && ((block_order[i_counterpart][j_counterpart] & 0x1111) == 0))
                block_order[i_counterpart][j_counterpart] |= 0x1000;
              if (i_counterpart > j_counterpart && ((block_order[j_counterpart][i_counterpart] & 0x1111) == 0))
                block_order[j_counterpart][i_counterpart] |= 0x0100;
            }
          }
        } else if (block_order[i][j] & 0xff00) {
          block_order[i][j] &= 0xff00;
          if (node.Blocks[i].instance[0].placedCenter.x < node.Blocks[j].instance[0].placedCenter.x)
            block_order[i][j] |= 0x0001;
          else
            block_order[i][j] |= 0x0010;
        } else {
          //if((!node.isFirstILP && ( node.placement_id & (1<<(count%30))))
          //|| (node.isFirstILP && abs(node.Blocks[i].instance[0].placedCenter.x - node.Blocks[j].instance[0].placedCenter.x) <
            //abs(node.Blocks[i].instance[0].placedCenter.y - node.Blocks[j].instance[0].placedCenter.y))){
          if(abs(node.Blocks[i].instance[0].placedCenter.x - node.Blocks[j].instance[0].placedCenter.x) <
            abs(node.Blocks[i].instance[0].placedCenter.y - node.Blocks[j].instance[0].placedCenter.y)){
            block_order[i][j] &= 0x00ff;
            if (node.Blocks[i].instance[0].placedCenter.y < node.Blocks[j].instance[0].placedCenter.y)
              block_order[i][j] |= 0x0100;
            else
              block_order[i][j] |= 0x1000;
          }
          else {
            block_order[i][j] &= 0xff00;
            if (node.Blocks[i].instance[0].placedCenter.x < node.Blocks[j].instance[0].placedCenter.x)
              block_order[i][j] |= 0x0001;
            else
              block_order[i][j] |= 0x0010;
          }
          count++;
        }
      }
    }
  }
  int a = 1;
}

ILP_solver::ILP_solver(design& mydesign, int ilps) {
  auto logger = spdlog::default_logger()->clone("placer.ILP_solver.ILP_solver");
  use_ilp_solver = ilps;
  LL.x = INT_MAX;
  LL.y = INT_MAX;
  UR.x = INT_MIN;
  UR.y = INT_MIN;
  Blocks.resize(mydesign.Blocks.size());
  Aspect_Ratio_weight = mydesign.Aspect_Ratio_weight;
  memcpy(Aspect_Ratio, mydesign.Aspect_Ratio, sizeof(mydesign.Aspect_Ratio));
  memcpy(placement_box, mydesign.placement_box, sizeof(mydesign.placement_box));
}

ILP_solver::ILP_solver(const ILP_solver& solver) {
  Blocks = solver.Blocks;
  LL = solver.LL;
  UR = solver.UR;
  area = solver.area;
  HPWL = solver.HPWL;
  HPWL_extend = solver.HPWL_extend;
  HPWL_extend_terminal = solver.HPWL_extend_terminal;
  cost = solver.cost;
  constraint_penalty = solver.constraint_penalty;
  area_norm = solver.area_norm;
  HPWL_norm = solver.HPWL_norm;
  ratio = solver.ratio;
  linear_const = solver.linear_const;
  multi_linear_const = solver.multi_linear_const;
  Aspect_Ratio_weight = solver.Aspect_Ratio_weight;
  use_ilp_solver = solver.use_ilp_solver;
  memcpy(Aspect_Ratio, solver.Aspect_Ratio, sizeof(solver.Aspect_Ratio));
  memcpy(placement_box, solver.placement_box, sizeof(solver.placement_box));
}

ILP_solver& ILP_solver::operator=(const ILP_solver& solver) {
  Blocks = solver.Blocks;
  LL = solver.LL;
  UR = solver.UR;
  area = solver.area;
  cost = solver.cost;
  constraint_penalty = solver.constraint_penalty;
  HPWL = solver.HPWL;
  HPWL_extend = solver.HPWL_extend;
  HPWL_extend_terminal = solver.HPWL_extend_terminal;
  area_norm = solver.area_norm;
  HPWL_norm = solver.HPWL_norm;
  ratio = solver.ratio;
  multi_linear_const = solver.multi_linear_const;
  Aspect_Ratio_weight = solver.Aspect_Ratio_weight;
  memcpy(Aspect_Ratio, solver.Aspect_Ratio, sizeof(solver.Aspect_Ratio));
  memcpy(placement_box, solver.placement_box, sizeof(solver.placement_box));
  return *this;
}

bool ILP_solver::FrameSolveILPCore(const design& mydesign, const SeqPair& curr_sp, const PnRDB::Drc_info& drcInfo, bool flushbl, const SOLVERTOUSE solvertouse, const bool snapGridILP, const vector<placerDB::point>* prev) {
  TimeMeasure tm(const_cast<design&>(mydesign).ilp_runtime);
  ++const_cast<design&>(mydesign)._numILPCalls;
  auto logger = spdlog::default_logger()->clone("placer.ILP_solver.FrameSolveILPCore");

  auto sighandler = signal(SIGINT, nullptr);
  int v_metal_index = -1;
  int h_metal_index = -1;
  for (unsigned int i = 0; i < drcInfo.Metal_info.size(); ++i) {
    if (drcInfo.Metal_info[i].direct == 0) {
      v_metal_index = i;
      break;
    }
  }
  for (unsigned int i = 0; i < drcInfo.Metal_info.size(); ++i) {
    if (drcInfo.Metal_info[i].direct == 1) {
      h_metal_index = i;
      break;
    }
  }
  x_pitch = drcInfo.Metal_info[v_metal_index].grid_unit_x;
  y_pitch = drcInfo.Metal_info[h_metal_index].grid_unit_y;

  // each block has 4 vars, x, y, H_flip, V_flip;
  unsigned int N_var = mydesign.Blocks.size() * 4 + mydesign.Nets.size() * 4;
  // i*4:x
  // i*4+1:y
  // i*4+2:H_flip
  // i*4+3:V_flip
  // x = pitch * n_p + offset_i * is_ith_offset
  // sum(is_ith_offset) = 1
  // one var for each offset and each pitch
  int place_on_grid_var_start = N_var;
  int place_on_grid_var_count = 0;
  for(unsigned int i=0;i<mydesign.Blocks.size();i++){
    if (mydesign.Blocks[i][curr_sp.selected[i]].xoffset.size()) place_on_grid_var_count += int(mydesign.Blocks[i][curr_sp.selected[i]].xoffset.size()) + 1;
    if (mydesign.Blocks[i][curr_sp.selected[i]].yoffset.size()) place_on_grid_var_count += int(mydesign.Blocks[i][curr_sp.selected[i]].yoffset.size()) + 1;
  }
  N_var += place_on_grid_var_count;
  const auto gridSnapVarStart{N_var};
  if (place_on_grid_var_count == 0 && snapGridILP) {
    N_var += (2 * mydesign.Blocks.size());
  }
  N_var += 2; //Area x and y variables
  const unsigned N_area_x = N_var - 2;
  const unsigned N_area_y = N_var - 1;

  ILPSolverIf solverif(SOLVER_ENUM::Cbc);
  const double infty{solverif.getInfinity()};
  // set integer constraint, H_flip and V_flip can only be 0 or 1
  std::vector<int> rowindofcol[N_var];
  std::vector<double> constrvalues[N_var];
  std::vector<double> rhs;
  std::vector<std::string> rownames;
  std::vector<char> intvars(mydesign.Blocks.size() * 4, TRUE);
  intvars.resize(N_var, FALSE);
  std::vector<char> sens;
  std::vector<double> collb(N_var, 0), colub(N_var, infty);
  for (int i = 0; i < mydesign.Blocks.size(); i++) {
    colub[i * 4 + 2] = 1;
    colub[i * 4 + 3] = 1;
  }
  // offset is ORed, only one is chosen, the select vars are 0 or 1, with sum 1
  int temp_pointer = place_on_grid_var_start;
  for (unsigned int i = 0; i < mydesign.Blocks.size(); i++) {
    if (mydesign.Blocks[i][curr_sp.selected[i]].xoffset.size()){
      for (unsigned int j = 0;j<mydesign.Blocks[i][curr_sp.selected[i]].xoffset.size();j++){
        colub[temp_pointer + j] = 1;
        intvars[temp_pointer + j] = 1;
      }
      intvars[temp_pointer + int(mydesign.Blocks[i][curr_sp.selected[i]].xoffset.size())] = 1;
      temp_pointer += int(mydesign.Blocks[i][curr_sp.selected[i]].xoffset.size()) + 1;
    }
    if (mydesign.Blocks[i][curr_sp.selected[i]].yoffset.size()){
      for (unsigned int j = 0;j<mydesign.Blocks[i][curr_sp.selected[i]].yoffset.size();j++){
        colub[temp_pointer + j] = 1;
        intvars[temp_pointer + j] = 1;
      }
      intvars[temp_pointer + int(mydesign.Blocks[i][curr_sp.selected[i]].yoffset.size())] = 1;
      temp_pointer += int(mydesign.Blocks[i][curr_sp.selected[i]].yoffset.size()) + 1;
    }
  }

  if (flushbl) {
    for (const auto& id : curr_sp.negPair) {
      if (id < int(mydesign.Blocks.size())) {
        collb[id * 4] = mydesign.halo_horizontal;
        colub[id * 4] = mydesign.placement_box[0] - mydesign.halo_horizontal - mydesign.Blocks[id][curr_sp.selected[id]].width;
        collb[id * 4 + 1] = mydesign.halo_vertical;
        colub[id * 4 + 1] = mydesign.placement_box[1] - mydesign.halo_vertical - mydesign.Blocks[id][curr_sp.selected[id]].height;
        if (prev) {
          collb[id * 4] = (*prev)[id].x;
          collb[id * 4 + 1] = (*prev)[id].y;
        }
      }
    }
  } else {
    // x>=0, y>=0
    int minx{0}, miny{0};
    for (const auto& id : curr_sp.negPair) {
      if (id < int(mydesign.Blocks.size())) {
        minx += mydesign.Blocks[id][curr_sp.selected[id]].width;
        miny += mydesign.Blocks[id][curr_sp.selected[id]].height;
      }
    }
    for (const auto& id : curr_sp.negPair) {
      if (id < int(mydesign.Blocks.size())) {
        collb[id * 4] = -10*minx; colub[id * 4] = -mydesign.Blocks[id][curr_sp.selected[id]].width;
        collb[id * 4 + 1] = -10*miny, colub[id * 4 + 1] = -mydesign.Blocks[id][curr_sp.selected[id]].height;
      }
    }
    for (unsigned i = 0; i < mydesign.Nets.size(); ++i) {
      const auto& ind = (mydesign.Blocks.size() + i) * 4;
      for (int j = 0; j < 4; ++j) {
        collb[ind + j] = -infty; colub[ind + j] = 0;
      }
    }
    collb[N_area_y] = -infty;
    collb[N_area_x] = -infty;
    colub[N_area_y] = 0;
    colub[N_area_x] = 0;
  }

  Pdatatype hyper;
  std::vector<double> objective(N_var, 0);
  // add area in cost
  int URblock_pos_id = 0, URblock_neg_id = 0;
  int estimated_width = 0, estimated_height = 0;
  for (unsigned int i = curr_sp.negPair.size() - 1; i >= 0; i--) {
    if (curr_sp.negPair[i] < int(mydesign.Blocks.size())) {
      URblock_neg_id = i;
      break;
    }
  }
  URblock_pos_id = find(curr_sp.posPair.begin(), curr_sp.posPair.end(), curr_sp.negPair[URblock_neg_id]) - curr_sp.posPair.begin();
  // estimate width
  for (int i = URblock_pos_id; i >= 0; i--) {
    if (curr_sp.posPair[i] < int(mydesign.Blocks.size())) {
      estimated_width += mydesign.Blocks[curr_sp.posPair[i]][curr_sp.selected[curr_sp.posPair[i]]].width;
    }
  }
  //// add estimated area
  //for (unsigned int i = 0; i < mydesign.Blocks.size(); i++) {
  //  if (curr_sp.negPair[i] >= mydesign.Blocks.size()) continue;
  //  objective.at(curr_sp.negPair[i] * 4 + 1) += ((flushbl ? estimated_width : -estimated_width) / 2);
    //}
  // estimate height
  for (unsigned int i = URblock_pos_id; i < curr_sp.posPair.size(); i++) {
    if (curr_sp.posPair[i] < int(mydesign.Blocks.size())) {
      estimated_height += mydesign.Blocks[curr_sp.posPair[i]][curr_sp.selected[curr_sp.posPair[i]]].height;
    }
  }
  //// add estimated area
  //for (unsigned int i = 0; i < mydesign.Blocks.size(); i++) {
  //  if (curr_sp.negPair[i] >= mydesign.Blocks.size()) continue;
  //  objective.at(curr_sp.negPair[i] * 4) += ((flushbl ? estimated_height : -estimated_height) / 2);
    //}
  if (flushbl) {
    objective[N_area_y] = estimated_width;
    objective[N_area_x] = estimated_height;
  } else {
    objective[N_area_y] = -estimated_width;
    objective[N_area_x] = -estimated_height;
  }
  for (unsigned int i = 0; i < mydesign.Nets.size(); i++) {
    //if (mydesign.Nets[i].connected.size() < 2) continue;
    int ind = int(mydesign.Blocks.size() * 4 + i * 4);
    objective.at(ind)     = mydesign.Nets[i].floating_pin ? 0. : -hyper.LAMBDA * std::max(1.*mydesign.Nets[i].weight, 1e-3);
    objective.at(ind + 1) = mydesign.Nets[i].floating_pin ? 0. : -hyper.LAMBDA * std::max(1.*mydesign.Nets[i].weight, 1e-3);
    objective.at(ind + 2) = mydesign.Nets[i].floating_pin ? 0. :  hyper.LAMBDA * std::max(1.*mydesign.Nets[i].weight, 1e-3);
    objective.at(ind + 3) = mydesign.Nets[i].floating_pin ? 0. :  hyper.LAMBDA * std::max(1.*mydesign.Nets[i].weight, 1e-3);
  }

  int bias_Hgraph = mydesign.bias_Hgraph, bias_Vgraph = mydesign.bias_Vgraph;
  roundup(bias_Hgraph, x_pitch);
  roundup(bias_Vgraph, y_pitch);
  sens.reserve(curr_sp.posPair.size() * curr_sp.posPair.size() * 2);
  rhs.reserve(curr_sp.posPair.size() * curr_sp.posPair.size() * 2);
  rownames.reserve(curr_sp.posPair.size() * curr_sp.posPair.size() * 2);

  //place on grid flipping constraint
  for (unsigned int i = 0; i < mydesign.Blocks.size(); i++) {
    if (mydesign.Blocks[i][curr_sp.selected[i]].xflip == 1) {
      rowindofcol[i * 4 + 2].push_back(rhs.size());
      constrvalues[i * 4 + 2].push_back(1);
      sens.push_back('E');
      rhs.push_back(0);
      rownames.push_back("F");
    } else if (mydesign.Blocks[i][curr_sp.selected[i]].xflip == -1) {
      rowindofcol[i * 4 + 2].push_back(rhs.size());
      constrvalues[i * 4 + 2].push_back(1);
      sens.push_back('E');
      rhs.push_back(1);
      rownames.push_back("F");
    }
    if (mydesign.Blocks[i][curr_sp.selected[i]].yflip == 1) {
      rowindofcol[i * 4 + 3].push_back(rhs.size());
      constrvalues[i * 4 + 3].push_back(1);
      sens.push_back('E');
      rhs.push_back(0);
      rownames.push_back("F");
    } else if (mydesign.Blocks[i][curr_sp.selected[i]].yflip == -1) {
      rowindofcol[i * 4 + 3].push_back(rhs.size());
      constrvalues[i * 4 + 3].push_back(1);
      sens.push_back('E');
      rhs.push_back(1);
      rownames.push_back("F");
    }
  }

  // grid snapping constraints
  if (snapGridILP && place_on_grid_var_count == 0) {
    for (unsigned i = 0; i < mydesign.Blocks.size(); ++i) {
      intvars[gridSnapVarStart + i * 2] = 1;
      intvars[gridSnapVarStart + i * 2 + 1] = 1;
      rowindofcol[i * 4].push_back(rhs.size());
      rowindofcol[gridSnapVarStart + i * 2].push_back(rhs.size());
      constrvalues[i * 4].push_back(1);
      constrvalues[gridSnapVarStart + i * 2].push_back(x_pitch * -1.);
      sens.push_back('E');
      rhs.push_back(0);
      rownames.push_back("GSX");
      rowindofcol[i * 4 + 1].push_back(rhs.size());
      rowindofcol[gridSnapVarStart + i * 2 + 1].push_back(rhs.size());
      constrvalues[i * 4 + 1].push_back(1);
      constrvalues[gridSnapVarStart + i * 2 + 1].push_back(y_pitch * -1.);
      sens.push_back('E');
      rhs.push_back(0);
      rownames.push_back("GSY");
      collb[i * 4] = std::max(Blocks[i].x - x_pitch * 2, 0);
      colub[i * 4] = (Blocks[i].x + x_pitch * 2);
      collb[i * 4 + 1] = std::max(Blocks[i].y - y_pitch * 2, 0);
      colub[i * 4 + 1] = (Blocks[i].y + y_pitch * 2);
      collb[gridSnapVarStart + i * 2] = std::max(Blocks[i].x / x_pitch - 2, 0);
      colub[gridSnapVarStart + i * 2] = (Blocks[i].x / x_pitch + 2);
      collb[gridSnapVarStart + i * 2 + 1] = std::max(Blocks[i].y / y_pitch - 2, 0);
      colub[gridSnapVarStart + i * 2 + 1] = (Blocks[i].y / y_pitch + 2);
    }
  }

  //place on grid constraint
  temp_pointer = place_on_grid_var_start;
  for (unsigned int i = 0; i < mydesign.Blocks.size(); i++) {
    if (mydesign.Blocks[i][curr_sp.selected[i]].xoffset.size()) {
      // x + is_filp *width - pitch * n_p - offset_i * is_ith_offset = 0
      rowindofcol[i * 4].push_back(rhs.size());
      rowindofcol[i * 4 + 2].push_back(rhs.size());
      rowindofcol[temp_pointer + mydesign.Blocks[i][curr_sp.selected[i]].xoffset.size()].push_back(rhs.size());
      for(unsigned int j=0;j<mydesign.Blocks[i][curr_sp.selected[i]].xoffset.size();j++){
        rowindofcol[temp_pointer + j].push_back(rhs.size());
      }
      constrvalues[i * 4].push_back(1);
      constrvalues[i * 4 + 2].push_back(mydesign.Blocks[i][curr_sp.selected[i]].width);
      constrvalues[temp_pointer + mydesign.Blocks[i][curr_sp.selected[i]].xoffset.size()].push_back(-mydesign.Blocks[i][curr_sp.selected[i]].xpitch);
      for (unsigned int j = 0; j < mydesign.Blocks[i][curr_sp.selected[i]].xoffset.size(); j++) {
        constrvalues[temp_pointer + j].push_back(-mydesign.Blocks[i][curr_sp.selected[i]].xoffset[j]);
      }
      sens.push_back('E');
      rhs.push_back(0);
      rownames.push_back("G");
      // sum(is_ith_offset) = 1
      for(unsigned int j=0;j<mydesign.Blocks[i][curr_sp.selected[i]].xoffset.size();j++){
        rowindofcol[temp_pointer + j].push_back(rhs.size());
        constrvalues[temp_pointer + j].push_back(1);
      }
      sens.push_back('E');
      rhs.push_back(1);
      rownames.push_back("G");
      temp_pointer += int(mydesign.Blocks[i][curr_sp.selected[i]].xoffset.size()) + 1;
    }
    if (mydesign.Blocks[i][curr_sp.selected[i]].yoffset.size()) {
      // y + is_flip * height - pitch * n_p - offset_i * is_ith_offset = 0
      rowindofcol[i * 4 + 1].push_back(rhs.size());
      rowindofcol[i * 4 + 3].push_back(rhs.size());
      rowindofcol[temp_pointer + mydesign.Blocks[i][curr_sp.selected[i]].yoffset.size()].push_back(rhs.size());
      for (unsigned int j = 0; j < mydesign.Blocks[i][curr_sp.selected[i]].yoffset.size(); j++) {
        rowindofcol[temp_pointer + j].push_back(rhs.size());
      }
      constrvalues[i * 4 + 1].push_back(1);
      constrvalues[i * 4 + 3].push_back(mydesign.Blocks[i][curr_sp.selected[i]].height);
      constrvalues[temp_pointer + mydesign.Blocks[i][curr_sp.selected[i]].yoffset.size()].push_back(-mydesign.Blocks[i][curr_sp.selected[i]].ypitch);
      for (unsigned int j = 0; j < mydesign.Blocks[i][curr_sp.selected[i]].yoffset.size(); j++) {
        constrvalues[temp_pointer + j].push_back(-mydesign.Blocks[i][curr_sp.selected[i]].yoffset[j]);
      }
      sens.push_back('E');
      rhs.push_back(0);
      rownames.push_back("G");
      // sum(is_ith_offset) = 1
      for (unsigned int j = 0; j < mydesign.Blocks[i][curr_sp.selected[i]].yoffset.size(); j++) {
        rowindofcol[temp_pointer + j].push_back(rhs.size());
        constrvalues[temp_pointer + j].push_back(1);
      }
      sens.push_back('E');
      rhs.push_back(1);
      rownames.push_back("G");
      temp_pointer += int(mydesign.Blocks[i][curr_sp.selected[i]].yoffset.size()) + 1;
    }
  }

  // matchblock
  for(auto pair:mydesign.Match_blocks){
    int i_pos_index = find(curr_sp.posPair.begin(), curr_sp.posPair.end(), pair.blockid1) - curr_sp.posPair.begin();
    int i_neg_index = find(curr_sp.negPair.begin(), curr_sp.negPair.end(), pair.blockid1) - curr_sp.negPair.begin();
    int j_pos_index = find(curr_sp.posPair.begin(), curr_sp.posPair.end(), pair.blockid2) - curr_sp.posPair.begin();
    int j_neg_index = find(curr_sp.negPair.begin(), curr_sp.negPair.end(), pair.blockid2) - curr_sp.negPair.begin();
    if (i_pos_index < j_pos_index) {
      if (i_neg_index < j_neg_index) {
        // i is left of j
        objective.at(pair.blockid1 * 4) += -1;
        objective.at(pair.blockid2 * 4) += 1;
      } else {
        // i is above j
        objective.at(pair.blockid1 * 4 + 1) += 1;
        objective.at(pair.blockid2 * 4 + 1) += -1;
      }
    } else {
      if (i_neg_index < j_neg_index) {
        // i is below j
        objective.at(pair.blockid1 * 4 + 1) += -1;
        objective.at(pair.blockid2 * 4 + 1) += 1;
      } else {
        // i is right of j
        objective.at(pair.blockid1 * 4) += 1;
        objective.at(pair.blockid2 * 4) += -1;
      }
    }
  }
  
  // overlap constraint
  for (unsigned int i = 0; i < mydesign.Blocks.size(); i++) {
    int i_pos_index = find(curr_sp.posPair.begin(), curr_sp.posPair.end(), i) - curr_sp.posPair.begin();
    int i_neg_index = find(curr_sp.negPair.begin(), curr_sp.negPair.end(), i) - curr_sp.negPair.begin();
    for (unsigned int j = i + 1; j < mydesign.Blocks.size(); j++) {
      int j_pos_index = find(curr_sp.posPair.begin(), curr_sp.posPair.end(), j) - curr_sp.posPair.begin();
      int j_neg_index = find(curr_sp.negPair.begin(), curr_sp.negPair.end(), j) - curr_sp.negPair.begin();
      if (i_pos_index < j_pos_index) {
        if (i_neg_index < j_neg_index) {
          // i is left of j
          rowindofcol[i * 4].push_back(rhs.size());
          rowindofcol[j * 4].push_back(rhs.size());
          constrvalues[i * 4].push_back(1);
          constrvalues[j * 4].push_back(-1);
          if (find(mydesign.Abut_Constraints.begin(), mydesign.Abut_Constraints.end(), make_pair(make_pair(int(i), int(j)), placerDB::H)) !=
              mydesign.Abut_Constraints.end()) {
            sens.push_back('E');
            rhs.push_back(-mydesign.Blocks[i][curr_sp.selected[i]].width);
            rownames.push_back("O");
          } else {
            sens.push_back('L');
            rhs.push_back(-mydesign.Blocks[i][curr_sp.selected[i]].width - std::max(bias_Hgraph, mydesign.getSpread(i, j, true)));
            rownames.push_back("O");
          }
        } else {
          // i is above j
          rowindofcol[i * 4 + 1].push_back(rhs.size());
          rowindofcol[j * 4 + 1].push_back(rhs.size());
          constrvalues[i * 4 + 1].push_back(1);
          constrvalues[j * 4 + 1].push_back(-1);
          if (find(mydesign.Abut_Constraints.begin(), mydesign.Abut_Constraints.end(), make_pair(make_pair(int(i), int(j)), placerDB::V)) !=
              mydesign.Abut_Constraints.end()) {
            sens.push_back('E');
            rhs.push_back(mydesign.Blocks[j][curr_sp.selected[j]].height);
            rownames.push_back("O");
          } else {
            sens.push_back('G');
            rhs.push_back(mydesign.Blocks[j][curr_sp.selected[j]].height + std::max(bias_Vgraph, mydesign.getSpread(i, j, false)));
            rownames.push_back("O");
          }
        }
      } else {
        if (i_neg_index < j_neg_index) {
          // i is below j
          rowindofcol[i * 4 + 1].push_back(rhs.size());
          rowindofcol[j * 4 + 1].push_back(rhs.size());
          constrvalues[i * 4 + 1].push_back(1);
          constrvalues[j * 4 + 1].push_back(-1);
          if (find(mydesign.Abut_Constraints.begin(), mydesign.Abut_Constraints.end(), make_pair(make_pair(int(j), int(i)), placerDB::V)) !=
              mydesign.Abut_Constraints.end()) {
            sens.push_back('E');
            rhs.push_back(-mydesign.Blocks[i][curr_sp.selected[i]].height);
            rownames.push_back("O");
          } else {
            sens.push_back('L');
            rhs.push_back(-mydesign.Blocks[i][curr_sp.selected[i]].height - std::max(bias_Vgraph, mydesign.getSpread(i, j, false)));
            rownames.push_back("O");
          }
        } else {
          // i is right of j
          rowindofcol[i * 4].push_back(rhs.size());
          rowindofcol[j * 4].push_back(rhs.size());
          constrvalues[i * 4].push_back(1);
          constrvalues[j * 4].push_back(-1);
          if (find(mydesign.Abut_Constraints.begin(), mydesign.Abut_Constraints.end(), make_pair(make_pair(int(j), int(i)), placerDB::H)) !=
              mydesign.Abut_Constraints.end()) {
            sens.push_back('E');
            rhs.push_back(mydesign.Blocks[j][curr_sp.selected[j]].width);
            rownames.push_back("O");
          } else {
            sens.push_back('G');
            rhs.push_back(mydesign.Blocks[j][curr_sp.selected[j]].width + std::max(bias_Hgraph, mydesign.getSpread(i, j, true)));
            rownames.push_back("O");
          }
        }
      }
    }
  }


  // symmetry block constraint
  for (const auto& SPBlock : mydesign.SPBlocks) {
    if (SPBlock.axis_dir == placerDB::H) {
      // constraint inside one pair
      for (int i = 0; i < SPBlock.sympair.size(); i++) {
        int first_id = SPBlock.sympair[i].first, second_id = SPBlock.sympair[i].second;
        // each pair has opposite V flip
        {
          rowindofcol[first_id * 4 + 3].push_back(rhs.size());
          rowindofcol[second_id * 4 + 3].push_back(rhs.size());
          constrvalues[first_id * 4 + 3].push_back(1);
          constrvalues[second_id * 4 + 3].push_back(1);
          sens.push_back('E');
          rhs.push_back(1);
          rownames.push_back("S");
        }
        // each pair has the same H flip
        {
          rowindofcol[first_id * 4 + 2].push_back(rhs.size());
          rowindofcol[second_id * 4 + 2].push_back(rhs.size());
          constrvalues[first_id * 4 + 2].push_back(1);
          constrvalues[second_id * 4 + 2].push_back(-1);
          sens.push_back('E');
          rhs.push_back(0);
          rownames.push_back("S");
        }
        // x center of blocks in each pair are the same
        {
          int first_x_center = mydesign.Blocks[first_id][curr_sp.selected[first_id]].width / 2;
          int second_x_center = mydesign.Blocks[second_id][curr_sp.selected[second_id]].width / 2;
          rowindofcol[first_id * 4].push_back(rhs.size());
          rowindofcol[second_id * 4].push_back(rhs.size());
          constrvalues[first_id * 4].push_back(1);
          constrvalues[second_id * 4].push_back(-1);
          sens.push_back('E');
          rhs.push_back(-first_x_center + second_x_center);
          rownames.push_back("S");
        }
      }

      // constraint between two pairs
      for (int i = 0; i < SPBlock.sympair.size(); i++) {
        int i_first_id = SPBlock.sympair[i].first, i_second_id = SPBlock.sympair[i].second;
        int i_first_y_center = mydesign.Blocks[i_first_id][curr_sp.selected[i_first_id]].height / 4;
        int i_second_y_center = mydesign.Blocks[i_second_id][curr_sp.selected[i_second_id]].height / 4;
        for (unsigned int j = i + 1; j < SPBlock.sympair.size(); j++) {
          // the y center of the two pairs are the same
          int j_first_id = SPBlock.sympair[j].first, j_second_id = SPBlock.sympair[j].second;
          int j_first_y_center = mydesign.Blocks[j_first_id][curr_sp.selected[j_first_id]].height / 4;
          int j_second_y_center = mydesign.Blocks[j_second_id][curr_sp.selected[j_second_id]].height / 4;
          int bias = -i_first_y_center - i_second_y_center + j_first_y_center + j_second_y_center;
          rowindofcol[i_first_id  * 4 + 1].push_back(rhs.size());
          rowindofcol[i_second_id * 4 + 1].push_back(rhs.size());
          rowindofcol[j_first_id  * 4 + 1].push_back(rhs.size());
          rowindofcol[j_second_id * 4 + 1].push_back(rhs.size());
          constrvalues[i_first_id  * 4 + 1].push_back(0.5);
          constrvalues[i_second_id * 4 + 1].push_back(0.5);
          constrvalues[j_first_id  * 4 + 1].push_back(-0.5);
          constrvalues[j_second_id * 4 + 1].push_back(-0.5);
          sens.push_back('E');
          rhs.push_back(bias);
          rownames.push_back("S");
        }
      }

      // constraint between a pair and a selfsym
      for (int i = 0; i < SPBlock.sympair.size(); i++) {
        int i_first_id = SPBlock.sympair[i].first, i_second_id = SPBlock.sympair[i].second;
        int i_first_y_center = mydesign.Blocks[i_first_id][curr_sp.selected[i_first_id]].height / 4;
        int i_second_y_center = mydesign.Blocks[i_second_id][curr_sp.selected[i_second_id]].height / 4;
        for (unsigned int j = 0; j < SPBlock.selfsym.size(); j++) {
          // the y center of the pair and the selfsym are the same
          int j_id = SPBlock.selfsym[j].first;
          int j_y_center = mydesign.Blocks[j_id][curr_sp.selected[j_id]].height / 2;
          int bias = -i_first_y_center - i_second_y_center + j_y_center;
          rowindofcol[i_first_id  * 4 + 1].push_back(rhs.size());
          rowindofcol[i_second_id * 4 + 1].push_back(rhs.size());
          rowindofcol[j_id * 4 + 1].push_back(rhs.size());
          constrvalues[i_first_id  * 4 + 1].push_back(0.5);
          constrvalues[i_second_id * 4 + 1].push_back(0.5);
          constrvalues[j_id * 4 + 1].push_back(-1);
          sens.push_back('E');
          rhs.push_back(bias);
          rownames.push_back("S");
        }
      }

      // constraint between two selfsyms
      for (int i = 0; i < SPBlock.selfsym.size(); i++) {
        int i_id = SPBlock.selfsym[i].first;
        int i_y_center = mydesign.Blocks[i_id][curr_sp.selected[i_id]].height / 2;
        for (unsigned int j = i + 1; j < SPBlock.selfsym.size(); j++) {
          // the y center of the two selfsyms are the same
          int j_id = SPBlock.selfsym[j].first;
          int j_y_center = mydesign.Blocks[j_id][curr_sp.selected[j_id]].height / 2;
          int bias = -i_y_center + j_y_center;
          rowindofcol[i_id * 4 + 1].push_back(rhs.size());
          rowindofcol[j_id * 4 + 1].push_back(rhs.size());
          constrvalues[i_id * 4 + 1].push_back(1);
          constrvalues[j_id * 4 + 1].push_back(-1);
          sens.push_back('E');
          rhs.push_back(bias);
          rownames.push_back("S");
        }
      }
    } else {
      // axis_dir==V
      // constraint inside one pair
      for (int i = 0; i < SPBlock.sympair.size(); i++) {
        int first_id = SPBlock.sympair[i].first, second_id = SPBlock.sympair[i].second;
        // each pair has opposite H flip
        {
          rowindofcol[first_id * 4 + 2].push_back(rhs.size());
          rowindofcol[second_id * 4 + 2].push_back(rhs.size());
          constrvalues[first_id * 4 + 2].push_back(1);
          constrvalues[second_id * 4 + 2].push_back(1);
          sens.push_back('E');
          rhs.push_back(1);
          rownames.push_back("S");
        }
        // each pair has the same V flip
        {
          rowindofcol[first_id * 4 + 3].push_back(rhs.size());
          rowindofcol[second_id * 4 + 3].push_back(rhs.size());
          constrvalues[first_id * 4 + 3].push_back(1);
          constrvalues[second_id * 4 + 3].push_back(-1);
          sens.push_back('E');
          rhs.push_back(0);
          rownames.push_back("S");
        }
        // y center of blocks in each pair are the same
        {
          int first_y_center = mydesign.Blocks[first_id][curr_sp.selected[first_id]].height / 2;
          int second_y_center = mydesign.Blocks[second_id][curr_sp.selected[second_id]].height / 2;
          rowindofcol[first_id   * 4 + 1].push_back(rhs.size());
          rowindofcol[second_id  * 4 + 1].push_back(rhs.size());
          constrvalues[first_id  * 4 + 1].push_back(1);
          constrvalues[second_id * 4 + 1].push_back(-1);
          sens.push_back('E');
          rhs.push_back(-first_y_center + second_y_center);
          rownames.push_back("S");
        }
      }

      // constraint between two pairs
      for (int i = 0; i < SPBlock.sympair.size(); i++) {
        int i_first_id = SPBlock.sympair[i].first, i_second_id = SPBlock.sympair[i].second;
        int i_first_x_center = mydesign.Blocks[i_first_id][curr_sp.selected[i_first_id]].width / 4;
        int i_second_x_center = mydesign.Blocks[i_second_id][curr_sp.selected[i_second_id]].width / 4;
        for (unsigned int j = i + 1; j < SPBlock.sympair.size(); j++) {
          // the x center of the two pairs are the same
          int j_first_id = SPBlock.sympair[j].first, j_second_id = SPBlock.sympair[j].second;
          int j_first_x_center = mydesign.Blocks[j_first_id][curr_sp.selected[j_first_id]].width / 4;
          int j_second_x_center = mydesign.Blocks[j_second_id][curr_sp.selected[j_second_id]].width / 4;
          int bias = -i_first_x_center - i_second_x_center + j_first_x_center + j_second_x_center;
          rowindofcol[i_first_id  * 4].push_back(rhs.size());
          rowindofcol[i_second_id * 4].push_back(rhs.size());
          rowindofcol[j_first_id  * 4].push_back(rhs.size());
          rowindofcol[j_second_id * 4].push_back(rhs.size());
          constrvalues[i_first_id  * 4].push_back(0.5);
          constrvalues[i_second_id * 4].push_back(0.5);
          constrvalues[j_first_id  * 4].push_back(-0.5);
          constrvalues[j_second_id * 4].push_back(-0.5);
          sens.push_back('E');
          rhs.push_back(bias);
          rownames.push_back("S");
        }
      }

      // constraint between a pair and a selfsym
      for (int i = 0; i < SPBlock.sympair.size(); i++) {
        int i_first_id = SPBlock.sympair[i].first, i_second_id = SPBlock.sympair[i].second;
        int i_first_x_center = mydesign.Blocks[i_first_id][curr_sp.selected[i_first_id]].width / 4;
        int i_second_x_center = mydesign.Blocks[i_second_id][curr_sp.selected[i_second_id]].width / 4;
        for (unsigned int j = 0; j < SPBlock.selfsym.size(); j++) {
          // the x center of the pair and the selfsym are the same
          int j_id = SPBlock.selfsym[j].first;
          int j_x_center = mydesign.Blocks[j_id][curr_sp.selected[j_id]].width / 2;
          int bias = -i_first_x_center - i_second_x_center + j_x_center;
          rowindofcol[i_first_id  * 4].push_back(rhs.size());
          rowindofcol[i_second_id * 4].push_back(rhs.size());
          rowindofcol[j_id * 4].push_back(rhs.size());
          constrvalues[i_first_id  * 4].push_back(0.5);
          constrvalues[i_second_id * 4].push_back(0.5);
          constrvalues[j_id * 4].push_back(-1);
          sens.push_back('E');
          rhs.push_back(bias);
          rownames.push_back("S");
        }
      }

      // constraint between two selfsyms
      for (int i = 0; i < SPBlock.selfsym.size(); i++) {
        int i_id = SPBlock.selfsym[i].first;
        int i_x_center = mydesign.Blocks[i_id][curr_sp.selected[i_id]].width / 2;
        for (unsigned int j = i + 1; j < SPBlock.selfsym.size(); j++) {
          // the x center of the two selfsyms are the same
          int j_id = SPBlock.selfsym[j].first;
          int j_x_center = mydesign.Blocks[j_id][curr_sp.selected[j_id]].width / 2;
          int bias = -i_x_center + j_x_center;
          rowindofcol[i_id * 4].push_back(rhs.size());
          rowindofcol[j_id * 4].push_back(rhs.size());
          constrvalues[i_id * 4].push_back(1);
          constrvalues[j_id * 4].push_back(-1);
          sens.push_back('E');
          rhs.push_back(bias);
          rownames.push_back("S");
        }
      }
    }
  }

  // align block constraint
  for (const auto& alignment_unit : mydesign.Align_blocks) {
    for (unsigned int j = 0; j < alignment_unit.blocks.size() - 1; j++) {
      int first_id = alignment_unit.blocks[j], second_id = alignment_unit.blocks[j + 1];
      if (alignment_unit.horizon == 1) {
        rowindofcol[first_id  * 4 + 1].push_back(rhs.size());
        rowindofcol[second_id * 4 + 1].push_back(rhs.size());
        constrvalues[first_id  * 4 + 1].push_back(1);
        constrvalues[second_id * 4 + 1].push_back(-1);
        int bias{0};
        if (alignment_unit.line == 1) {
          // align center y
          bias = -mydesign.Blocks[first_id][curr_sp.selected[first_id]].height / 2 + mydesign.Blocks[second_id][curr_sp.selected[second_id]].height / 2;
        } else if (alignment_unit.line == 2) {
          // align to top
          bias = -mydesign.Blocks[first_id][curr_sp.selected[first_id]].height + mydesign.Blocks[second_id][curr_sp.selected[second_id]].height;
        }
        sens.push_back('E');
        rhs.push_back(bias);
        rownames.push_back("A");
      } else {
        rowindofcol[first_id  * 4].push_back(rhs.size());
        rowindofcol[second_id * 4].push_back(rhs.size());
        constrvalues[first_id  * 4].push_back(1);
        constrvalues[second_id * 4].push_back(-1);
        int bias{0};
        if (alignment_unit.line == 1) {
          // align center x
          bias = -mydesign.Blocks[first_id][curr_sp.selected[first_id]].width / 2 + mydesign.Blocks[second_id][curr_sp.selected[second_id]].width / 2;
        } else if (alignment_unit.line == 2) {
          // align to right
          bias = -mydesign.Blocks[first_id][curr_sp.selected[first_id]].width + mydesign.Blocks[second_id][curr_sp.selected[second_id]].width;
        }
        sens.push_back('E');
        rhs.push_back(bias);
        rownames.push_back("A");
      }
    }
  }

  for (const auto& order : mydesign.Ordering_Constraints) {
    if (order.second == placerDB::H) {
      const auto& i = order.first.first;
      const auto& j = order.first.second;
      rowindofcol[i * 4].push_back(rhs.size());
      rowindofcol[j * 4].push_back(rhs.size());
      constrvalues[i * 4].push_back(1);
      constrvalues[j * 4].push_back(-1);
      if (find(mydesign.Abut_Constraints.begin(), mydesign.Abut_Constraints.end(), make_pair(make_pair(int(i), int(j)), placerDB::H)) !=
          mydesign.Abut_Constraints.end()) {
        sens.push_back('E');
        rhs.push_back(-mydesign.Blocks[i][curr_sp.selected[i]].width);
        rownames.push_back("OR");
      } else {
        sens.push_back('L');
        rhs.push_back(-mydesign.Blocks[i][curr_sp.selected[i]].width - std::max(bias_Hgraph, mydesign.getSpread(i, j, true)));
        rownames.push_back("OR");
      }
    }
    else if (order.second == placerDB::V) {
      const auto& i = order.first.second;
      const auto& j = order.first.first;
      rowindofcol[i * 4 + 1].push_back(rhs.size());
      rowindofcol[j * 4 + 1].push_back(rhs.size());
      constrvalues[i * 4 + 1].push_back(1);
      constrvalues[j * 4 + 1].push_back(-1);
      if (find(mydesign.Abut_Constraints.begin(), mydesign.Abut_Constraints.end(), make_pair(make_pair(int(i), int(j)), placerDB::V)) !=
          mydesign.Abut_Constraints.end()) {
        sens.push_back('E');
        rhs.push_back(-mydesign.Blocks[i][curr_sp.selected[i]].height);
        rownames.push_back("OR");
      } else {
        sens.push_back('L');
        rhs.push_back(-mydesign.Blocks[i][curr_sp.selected[i]].height - std::max(bias_Hgraph, mydesign.getSpread(i, j, false)));
        rownames.push_back("OR");
      }
    }
  }
  //ExtremeBlocksOfNet netExtremes(curr_sp, mydesign.Nets.size());
  //for (int i = 0; i < mydesign.Nets.size(); ++i) {
  //  netExtremes.FindExtremes(mydesign.Nets[i], i);
  //}

  // set_add_rowmode(lp, FALSE);
  {
    // add HPWL in cost
    for (unsigned int i = 0; i < mydesign.Nets.size(); i++) {
      //if (mydesign.Nets[i].connected.size() < 2) continue;
      if (mydesign.Nets[i].floating_pin) continue;
      int ind = int(mydesign.Blocks.size() * 4 + i * 4);

      for (unsigned int j = 0; j < mydesign.Nets[i].connected.size(); j++) {
        if (mydesign.Nets[i].connected[j].type == placerDB::Block) {
          const int block_id = mydesign.Nets[i].connected[j].iter2;
          const int pin_id = mydesign.Nets[i].connected[j].iter;
          const auto& blk = mydesign.Blocks[block_id][curr_sp.selected[block_id]];
          int pin_llx = blk.width / 2,  pin_urx = blk.width / 2;
          int pin_lly = blk.height / 2, pin_ury = blk.height / 2;
          if (blk.blockPins.size()
              && blk.blockPins[pin_id].bbox.LL.x <= blk.blockPins[pin_id].bbox.UR.x
              && blk.blockPins[pin_id].bbox.LL.y <= blk.blockPins[pin_id].bbox.UR.y) {
            pin_llx = blk.blockPins[pin_id].bbox.LL.x;
            pin_lly = blk.blockPins[pin_id].bbox.LL.y;
            pin_urx = blk.blockPins[pin_id].bbox.UR.x;
            pin_ury = blk.blockPins[pin_id].bbox.UR.y;
          } else {
            continue;
          }
          double deltax = (blk.width  - pin_llx - pin_urx);
          double deltay = (blk.height - pin_lly - pin_ury);
          rowindofcol[block_id * 4].push_back(rhs.size());
          rowindofcol[block_id * 4 + 2].push_back(rhs.size());
          rowindofcol[ind].push_back(rhs.size());
          constrvalues[block_id * 4].push_back(1);
          constrvalues[block_id * 4 + 2].push_back(deltax);
          constrvalues[ind].push_back(-1);
          sens.push_back('G');
          rhs.push_back(-pin_llx);
          rownames.push_back("H");

          rowindofcol[block_id * 4 + 1].push_back(rhs.size());
          rowindofcol[block_id * 4 + 3].push_back(rhs.size());
          rowindofcol[ind + 1].push_back(rhs.size());
          constrvalues[block_id * 4 + 1].push_back(1);
          constrvalues[block_id * 4 + 3].push_back(deltay);
          constrvalues[ind + 1].push_back(-1);
          sens.push_back('G');
          rhs.push_back(-pin_lly);
          rownames.push_back("H");

          rowindofcol[block_id * 4].push_back(rhs.size());
          rowindofcol[block_id * 4 + 2].push_back(rhs.size());
          rowindofcol[ind + 2].push_back(rhs.size());
          constrvalues[block_id * 4].push_back(1);
          constrvalues[block_id * 4 + 2].push_back(deltax);
          constrvalues[ind + 2].push_back(-1);
          sens.push_back('L');
          rhs.push_back(-pin_urx);
          rownames.push_back("H");

          rowindofcol[block_id * 4 + 1].push_back(rhs.size());
          rowindofcol[block_id * 4 + 3].push_back(rhs.size());
          rowindofcol[ind + 3].push_back(rhs.size());
          constrvalues[block_id * 4 + 1].push_back(1);
          constrvalues[block_id * 4 + 3].push_back(deltay);
          constrvalues[ind + 3].push_back(-1);
          sens.push_back('L');
          rhs.push_back(-pin_ury);
          rownames.push_back("H");
        }
      }
    }
  }

  // add area constraints
  {
    for (unsigned i = 0; i < mydesign.Blocks.size(); ++i) {
      const auto& blk = mydesign.Blocks[i][curr_sp.selected[i]];
      if (flushbl) {
        rowindofcol[i * 4].push_back(rhs.size());
        rowindofcol[N_area_x].push_back(rhs.size());
        constrvalues[i * 4].push_back(-1);
        constrvalues[N_area_x].push_back(1);
        sens.push_back('G');
        rhs.push_back(blk.width);
        rownames.push_back("A");

        rowindofcol[i * 4 + 1].push_back(rhs.size());
        rowindofcol[N_area_y].push_back(rhs.size());
        constrvalues[i * 4 + 1].push_back(-1);
        constrvalues[N_area_y].push_back(1);
        sens.push_back('G');
        rhs.push_back(blk.height);
        rownames.push_back("A");
      } else {
        rowindofcol[i * 4].push_back(rhs.size());
        rowindofcol[N_area_x].push_back(rhs.size());
        constrvalues[i * 4].push_back(-1);
        constrvalues[N_area_x].push_back(1);
        sens.push_back('L');
        rhs.push_back(0);
        rownames.push_back("A");

        rowindofcol[i * 4 + 1].push_back(rhs.size());
        rowindofcol[N_area_y].push_back(rhs.size());
        constrvalues[i * 4 + 1].push_back(-1);
        constrvalues[N_area_y].push_back(1);
        sens.push_back('L');
        rhs.push_back(0);
        rownames.push_back("A");
      }
    }
  }
  area_ilp = 0.;
  HPWL_ILP = 0.;
  {
    std::vector<int> starts, indices;
    std::vector<double> values;
    starts.push_back(0);
    for (int i = 0; i < N_var; ++i) {
      starts.push_back(starts.back() + rowindofcol[i].size());
      //logger->info("starts {0} rowind size {1} conctr val {2}", starts.back(), rowindofcol[i].size(), constrvalues[i].size());
      indices.insert(indices.end(), rowindofcol[i].begin(), rowindofcol[i].end());
      values.insert(values.end(), constrvalues[i].begin(), constrvalues[i].end());
    }
    PlacerHyperparameters hyper;
    solverif.setTimeLimit(std::max(hyper.ILP_runtime_limit, static_cast<int>(Blocks.size())));
    if (solvertouse == CBC || solvertouse == SYMPHONY) {
      double rhslb[rhs.size()], rhsub[rhs.size()];
      for (unsigned i = 0;i < sens.size(); ++i) {
        switch (sens[i]) {
          case 'E':
          default:
            rhslb[i] = rhs[i];
            rhsub[i] = rhs[i];
            break;
          case 'G':
            rhslb[i] = rhs[i];
            rhsub[i] = infty;
            break;
          case 'L':
            rhslb[i] = -infty;
            rhsub[i] = rhs[i];
            break;
        }
      }
      vector<int> intvarsi(intvars.size());
      for (unsigned i = 0; i < intvars.size(); ++i) intvarsi[i] = intvars[i];
      solverif.loadProblem(N_var, (int)rhs.size(), starts.data(), indices.data(),
          values.data(), collb.data(), colub.data(),
          objective.data(), rhslb, rhsub, intvarsi.data());
    }

    if (getenv("ALIGN_DEBUG_SA_ILP") != nullptr && std::atoi(getenv("ALIGN_DEBUG_SA_ILP"))) {
      //solve the integer program
      static int write_cnt{0};
      static std::string block_name;
      if (block_name != mydesign.name) {
        write_cnt = 0;
        block_name = mydesign.name;
      }
      if (write_cnt < 10) {
        char* names[N_var];
        std::vector<std::string> namesvec(N_var);
        namesvec[N_area_x]     = "area_x\0";
        names[N_area_x] = &(namesvec[N_area_x][0]);
        namesvec[N_area_y]     = "area_y\0";
        names[N_area_y] = &(namesvec[N_area_y][0]);
        for (int i = 0; i < mydesign.Blocks.size(); i++) {
          int ind = i * 4;
          namesvec[ind]     = (mydesign.Blocks[i][0].name + "_x\0");
          names[ind] = &(namesvec[ind][0]);
          namesvec[ind + 1] = (mydesign.Blocks[i][0].name + "_y\0");
          names[ind + 1] = &(namesvec[ind + 1][0]);
          namesvec[ind + 2] = (mydesign.Blocks[i][0].name + "_flx\0");
          names[ind + 2] = &(namesvec[ind + 2][0]);
          namesvec[ind + 3] = (mydesign.Blocks[i][0].name + "_fly\0");
          names[ind + 3] = &(namesvec[ind + 3][0]);
        }

        for (int i = 0; i < mydesign.Nets.size(); ++i) {
          int ind = i * 4 + mydesign.Blocks.size() * 4;
          namesvec[ind]     = (mydesign.Nets[i].name + "_ll_x\0");
          names[ind] = &(namesvec[ind][0]);
          namesvec[ind + 1] = (mydesign.Nets[i].name + "_ll_y\0");
          names[ind + 1] = &(namesvec[ind + 1][0]);
          namesvec[ind + 2] = (mydesign.Nets[i].name + "_ur_x\0");
          names[ind + 2] = &(namesvec[ind + 2][0]);
          namesvec[ind + 3] = (mydesign.Nets[i].name + "_ur_y\0");
          names[ind + 3] = &(namesvec[ind + 3][0]);
        }
        if (rownames.size() < rhs.size()) rownames.resize(rhs.size());
        char* rownamesarr[rhs.size()];
        for (unsigned i = 0; i < rhs.size(); ++i) {
          if (rownames[i].empty()) {
            rownames[i] = "c" + std::to_string(i) + "\0";
          } else {
            rownames[i] += (std::to_string(i) + "\0");
          }
          rownamesarr[i] = &(rownames[i][0]);
        }
        for (unsigned i = 0; i < N_var; ++i) {
          if (namesvec[i].empty()) {
            namesvec[i] = ("var" + std::to_string(i));
            names[i] = &(namesvec[i])[0];
          } else if (namesvec[i].find("<") != std::string::npos || namesvec[i].find(">") != std::string::npos) {
            std::replace(namesvec[i].begin(), namesvec[i].end(), '<', '(');
            std::replace(namesvec[i].begin(), namesvec[i].end(), '>', ')');
          }
        }
        solverif.writelp(const_cast<char*>((mydesign.name + "_ilp_" + std::to_string(write_cnt) + "__" + std::to_string(snapGridILP) + ".lp").c_str()), names, rownamesarr);
        logger->debug("writing ilp file {0}", (mydesign.name + "_ilp_" + std::to_string(write_cnt) + "__" + std::to_string(snapGridILP) + ".lp"));
        ++write_cnt;
      }
    }

    int status{0};
    {
      TimeMeasure tm(const_cast<design&>(mydesign).ilp_solve_runtime);
      status = solverif.solve();
    }
    const double* var = solverif.solution();
    if (status != 0 || var == nullptr) {
      ++const_cast<design&>(mydesign)._infeasILPFail;
      sighandler = signal(SIGINT, sighandler);
      return false;
    }
    sighandler = signal(SIGINT, sighandler);
    //for (unsigned i = 0; i < (mydesign.Blocks.size() * 4); ++i) {
    //  area_ilp += (objective[i] * var[i]);
    //}
    area_ilp = var[N_var - 1] * var[N_var - 2];
    for (int i = 0; i < mydesign.Blocks.size(); i++) {
      Blocks[i].x = roundupint(var[i * 4]);
      Blocks[i].y = roundupint(var[i * 4 + 1]);
      Blocks[i].H_flip = roundupint(var[i * 4 + 2]);
      Blocks[i].V_flip = roundupint(var[i * 4 + 3]);
    }
    // calculate HPWL from ILP solution
    for (int i = 0; i < mydesign.Nets.size(); ++i) {
      int ind = (int(mydesign.Blocks.size()) * 4 + i * 4);
      if (mydesign.Nets[i].floating_pin) continue;
      HPWL_ILP += (var[ind + 3] + var[ind + 2] - var[ind + 1] - var[ind]);
    }
  }
  /** may fail place on grid constraint
    for (int i = 0; i < mydesign.Blocks.size(); i++) {
    Blocks[i].x -= minx;
    Blocks[i].y -= miny;
    }
   **/

  return true;
}

bool ILP_solver::MoveBlocksUsingSlack(const std::vector<Block>& blockslocal, const design& mydesign, const SeqPair& curr_sp, const PnRDB::Drc_info& drcInfo, const int num_threads, const bool genvalid) {
  std::vector<placerDB::point> slackxy(Blocks.size());
  for (unsigned i = 0; i < Blocks.size(); ++i) {
    slackxy[i].x = Blocks[i].x - blockslocal[i].x;
    slackxy[i].y = Blocks[i].y - blockslocal[i].y;
    if (slackxy[i].x < 0 || slackxy[i].y < 0) return false;
  }
  for (const auto& SPBlock : mydesign.SPBlocks) {
    int minslack(INT_MAX);
    if (SPBlock.axis_dir == placerDB::H) {
      for (const auto& sp : SPBlock.sympair) {
        minslack = std::min(slackxy[sp.first].x,  minslack);
        minslack = std::min(slackxy[sp.second].x, minslack);
      }
      for (const auto& ss : SPBlock.selfsym) {
        minslack = std::min(slackxy[ss.first].x,  minslack);
      }
      if (minslack != INT_MAX) {
        for (const auto& sp : SPBlock.sympair) {
          slackxy[sp.first].x  = minslack;
          slackxy[sp.second].x = minslack;
        }
        for (const auto& ss : SPBlock.selfsym) {
          slackxy[ss.first].x = minslack;
        }
      }
    } else {
      for (const auto& sp : SPBlock.sympair) {
        minslack = std::min(slackxy[sp.first].y,  minslack);
        minslack = std::min(slackxy[sp.second].y, minslack);
      }
      for (const auto& ss : SPBlock.selfsym) {
        minslack = std::min(slackxy[ss.first].y,  minslack);
      }
      if (minslack != INT_MAX) {
        for (const auto& sp : SPBlock.sympair) {
          slackxy[sp.first].y  = minslack;
          slackxy[sp.second].y = minslack;
        }
        for (const auto& ss : SPBlock.selfsym) {
          slackxy[ss.first].y = minslack;
        }
      }
    }
  }
  for (const auto& align : mydesign.Align_blocks) {
    int minslack(INT_MAX);
    if (align.horizon) {
      for (const auto& blk : align.blocks) {
        minslack = std::min(slackxy[blk].y,  minslack);
      }
      if (minslack != INT_MAX) {
        for (const auto& blk : align.blocks) {
          slackxy[blk].y = minslack;
        }
      }
    } else {
      for (const auto& blk : align.blocks) {
        minslack = std::min(slackxy[blk].x,  minslack);
      }
      if (minslack != INT_MAX) {
        for (const auto& blk : align.blocks) {
          slackxy[blk].x = minslack;
        }
      }
    }
  }
  std::vector<placerDB::point> blockpts(Blocks.size());
  for (unsigned i = 0; i < Blocks.size(); ++i) {
    blockpts[i].x = (Blocks[i].x - slackxy[i].x/2);
    blockpts[i].y = (Blocks[i].y - slackxy[i].y/2);
  }
  if (!FrameSolveILP(mydesign, curr_sp, drcInfo, num_threads, true, &blockpts)) return false;
  return true;
}

bool ILP_solver::GenerateValidSolutionCore(const design& mydesign, const SeqPair& curr_sp, const PnRDB::Drc_info& drcInfo, const int num_threads, const bool snapGridILP) {
  if (mydesign.Blocks.empty()) return false;
  auto logger = spdlog::default_logger()->clone("placer.ILP_solver.GenerateValidSolutionCore");
  ++const_cast<design&>(mydesign)._totalNumCostCalc;
  if (snapGridILP) ++const_cast<design&>(mydesign)._numSnapGridFail;
  if (mydesign.Blocks.size() == 1 && mydesign.Blocks[0][0].xoffset.empty() && mydesign.Blocks[0][0].yoffset.empty()) {
    Blocks[0].x = mydesign.halo_horizontal; Blocks[0].y = mydesign.halo_vertical;
    Blocks[0].H_flip = 0; Blocks[0].V_flip = 0;
    area_ilp = ((double)mydesign.Blocks[0][curr_sp.selected[0]].width) * ((double)mydesign.Blocks[0][curr_sp.selected[0]].height);
  } else {
    if (mydesign.leftAlign()) {
      // frame and solve ILP to flush bottom/left
      if (!FrameSolveILP(mydesign, curr_sp, drcInfo, num_threads, true, snapGridILP))  return false;
    } else if (mydesign.rightAlign()) {
      if (!FrameSolveILP(mydesign, curr_sp, drcInfo, num_threads, false, snapGridILP)) return false;
    } else {
      if (!FrameSolveILP(mydesign, curr_sp, drcInfo, num_threads, true, snapGridILP))  return false;
      std::vector<Block> blockslocal{Blocks};
      // frame and solve ILP to flush top/right
      if (!FrameSolveILP(mydesign, curr_sp, drcInfo, num_threads, false, snapGridILP) 
          || !MoveBlocksUsingSlack(blockslocal, mydesign, curr_sp, drcInfo)) {
        // if unable to solve flush top/right or if the solution changed significantly,
        // use the bottom/left flush solution
        Blocks = blockslocal;
      }
    }
    // snap up coordinates to grid
    for(unsigned int i=0;i<mydesign.SPBlocks.size();i++) {
      if (mydesign.SPBlocks[i].sympair.size() == 0) continue;
      //if sympair center is not on grid
      {
        int first_id = mydesign.SPBlocks[i].sympair[0].first;
        int second_id = mydesign.SPBlocks[i].sympair[0].second;
        int first_selected = curr_sp.selected[first_id];
        int second_selected = curr_sp.selected[second_id];
        int center_line = ((Blocks[first_id].x + mydesign.Blocks[first_id][first_selected].width / 2) +
                           (Blocks[second_id].x + mydesign.Blocks[second_id][second_selected].width / 2)) /
                          2;
        if (center_line % x_pitch == 0) continue;
      }
      for (unsigned int j = 0; j < mydesign.SPBlocks[i].sympair.size(); j++) {
        int first_id = mydesign.SPBlocks[i].sympair[j].first;
        int second_id = mydesign.SPBlocks[i].sympair[j].second;
        if (Blocks[first_id].x>Blocks[second_id].x) {
          roundup(Blocks[first_id].x, x_pitch);
          rounddown(Blocks[second_id].x, x_pitch);
        } else {
          rounddown(Blocks[first_id].x, x_pitch);
          roundup(Blocks[second_id].x, x_pitch);
        }
      }
    }
  }
  return true;
}

double ILP_solver::GenerateValidSolution(const design& mydesign, const SeqPair& curr_sp, const PnRDB::Drc_info& drcInfo, const int num_threads) {

  if (!GenerateValidSolutionCore(mydesign, curr_sp, drcInfo, num_threads, false)) return -1;
  auto logger = spdlog::default_logger()->clone("placer.ILP_solver.GenerateValidSolution");
  ++const_cast<design&>(mydesign)._totalNumCostCalc;
  bool snapGridILP{false}, offsetpresent{false};
  for(unsigned int i = 0; i < mydesign.Blocks.size(); ++i){
    if (!mydesign.Blocks[i][curr_sp.selected[i]].xoffset.empty() ||
        !mydesign.Blocks[i][curr_sp.selected[i]].yoffset.empty()) {
      offsetpresent = true;
      break;
    }
  }
  if (!offsetpresent && mydesign.Blocks.size() > 1) {
    for (unsigned i = 0; i < mydesign.Blocks.size(); i++) {
      if ((Blocks[i].x % x_pitch) || (Blocks[i].y % y_pitch)) {
        snapGridILP = true;
        break;
      }
    }
  }

  if (snapGridILP && !GenerateValidSolutionCore(mydesign, curr_sp, drcInfo, num_threads, true)) return -1;

  TimeMeasure tm(const_cast<design&>(mydesign).gen_valid_runtime);
  // calculate LL and UR
  LL.x = INT_MAX, LL.y = INT_MAX;
  UR.x = INT_MIN, UR.y = INT_MIN;
  for (int i = 0; i < mydesign.Blocks.size(); i++) {
    LL.x = std::min(LL.x, Blocks[i].x);
    LL.y = std::min(LL.y, Blocks[i].y);
    UR.x = std::max(UR.x, Blocks[i].x + mydesign.Blocks[i][curr_sp.selected[i]].width);
    UR.y = std::max(UR.y, Blocks[i].y + mydesign.Blocks[i][curr_sp.selected[i]].height);
  }
  // calculate area
  area = double(UR.x - LL.x) * double(UR.y - LL.y);
  // calculate norm area
  area_norm = area * 0.1 / mydesign.GetMaxBlockAreaSum();
  // calculate ratio
  // ratio = std::max(double(UR.x - LL.x) / double(UR.y - LL.y), double(UR.y - LL.y) / double(UR.x - LL.x));
  ratio = double(UR.x) / double(UR.y);
  if (ratio < Aspect_Ratio[0] || ratio > Aspect_Ratio[1]) {
    ++const_cast<design&>(mydesign)._infeasAspRatio;
    return -1;
  }
  if ((placement_box[0] > 0 && UR.x > placement_box[0]) || (placement_box[1] > 0 && UR.y > placement_box[1])) {
    ++const_cast<design&>(mydesign)._infeasPlBound;
    return -1;
  }
  // calculate HPWL
  HPWL = 0;
  HPWL_extend = 0;
  HPWL_extend_terminal = 0;

  for (const auto& neti : mydesign.Nets) {
    if (neti.floating_pin) continue;
    int HPWL_min_x = UR.x, HPWL_min_y = UR.y, HPWL_max_x = 0, HPWL_max_y = 0;
    int HPWL_extend_min_x = UR.x, HPWL_extend_min_y = UR.y, HPWL_extend_max_x = 0, HPWL_extend_max_y = 0;
    for (const auto& connectedj : neti.connected) {
      if (connectedj.type == placerDB::Block) {
        int iter2 = connectedj.iter2, iter = connectedj.iter;
        for (const auto& centerk : mydesign.Blocks[iter2][curr_sp.selected[iter2]].blockPins[iter].center) {
          // calculate contact center
          int pin_x = centerk.x;
          int pin_y = centerk.y;
          if (Blocks[iter2].H_flip) pin_x = mydesign.Blocks[iter2][curr_sp.selected[iter2]].width - pin_x;
          if (Blocks[iter2].V_flip) pin_y = mydesign.Blocks[iter2][curr_sp.selected[iter2]].height - pin_y;
          pin_x += Blocks[iter2].x;
          pin_y += Blocks[iter2].y;
          HPWL_min_x = std::min(HPWL_min_x, pin_x);
          HPWL_max_x = std::max(HPWL_max_x, pin_x);
          HPWL_min_y = std::min(HPWL_min_y, pin_y);
          HPWL_max_y = std::max(HPWL_max_y, pin_y);
        }
        /*int pin_llx = mydesign.Blocks[iter2][curr_sp.selected[iter2]].blockPins[iter].bbox.LL.x;
          int pin_lly = mydesign.Blocks[iter2][curr_sp.selected[iter2]].blockPins[iter].bbox.LL.y;
          int pin_urx = mydesign.Blocks[iter2][curr_sp.selected[iter2]].blockPins[iter].bbox.UR.x;
          int pin_ury = mydesign.Blocks[iter2][curr_sp.selected[iter2]].blockPins[iter].bbox.UR.y;
          if (Blocks[iter2].H_flip) {
          pin_llx = mydesign.Blocks[iter2][curr_sp.selected[iter2]].width -
          mydesign.Blocks[iter2][curr_sp.selected[iter2]].blockPins[iter].bbox.UR.x;
          pin_urx = mydesign.Blocks[iter2][curr_sp.selected[iter2]].width -
          mydesign.Blocks[iter2][curr_sp.selected[iter2]].blockPins[iter].bbox.LL.x;
          }
          if (Blocks[iter2].V_flip) {
          pin_lly = mydesign.Blocks[iter2][curr_sp.selected[iter2]].height -
          mydesign.Blocks[iter2][curr_sp.selected[iter2]].blockPins[iter].bbox.UR.y;
          pin_ury = mydesign.Blocks[iter2][curr_sp.selected[iter2]].height -
          mydesign.Blocks[iter2][curr_sp.selected[iter2]].blockPins[iter].bbox.LL.y;
          }
          pin_llx += Blocks[iter2].x;
          pin_urx += Blocks[iter2].x;
          pin_lly += Blocks[iter2].y;
          pin_ury += Blocks[iter2].y;
          HPWL_extend_min_x = std::min(HPWL_extend_min_x, pin_llx);
          HPWL_extend_max_x = std::max(HPWL_extend_max_x, pin_urx);
          HPWL_extend_min_y = std::min(HPWL_extend_min_y, pin_lly);
          HPWL_extend_max_y = std::max(HPWL_extend_max_y, pin_ury);*/
        for (const auto& boundaryk : mydesign.Blocks[iter2][curr_sp.selected[iter2]].blockPins[iter].boundary) {
          int pin_llx = boundaryk.polygon[0].x, pin_urx = boundaryk.polygon[2].x;
          int pin_lly = boundaryk.polygon[0].y, pin_ury = boundaryk.polygon[2].y;
          if (Blocks[iter2].H_flip) {
            pin_llx = mydesign.Blocks[iter2][curr_sp.selected[iter2]].width - boundaryk.polygon[2].x;
            pin_urx = mydesign.Blocks[iter2][curr_sp.selected[iter2]].width - boundaryk.polygon[0].x;
          }
          if (Blocks[iter2].V_flip) {
            pin_lly = mydesign.Blocks[iter2][curr_sp.selected[iter2]].height - boundaryk.polygon[2].y;
            pin_ury = mydesign.Blocks[iter2][curr_sp.selected[iter2]].height - boundaryk.polygon[0].y;
          }
          pin_llx += Blocks[iter2].x;
          pin_urx += Blocks[iter2].x;
          pin_lly += Blocks[iter2].y;
          pin_ury += Blocks[iter2].y;
          HPWL_extend_min_x = std::min(HPWL_extend_min_x, pin_llx);
          HPWL_extend_max_x = std::max(HPWL_extend_max_x, pin_urx);
          HPWL_extend_min_y = std::min(HPWL_extend_min_y, pin_lly);
          HPWL_extend_max_y = std::max(HPWL_extend_max_y, pin_ury);
        }
      }
    }
    HPWL += (HPWL_max_y - HPWL_min_y) + (HPWL_max_x - HPWL_min_x);
    HPWL_extend += (HPWL_extend_max_y - HPWL_extend_min_y) + (HPWL_extend_max_x - HPWL_extend_min_x);
    HPWL_extend_net_priority += ((HPWL_extend_max_y - HPWL_extend_min_y) + (HPWL_extend_max_x - HPWL_extend_min_x)) * neti.weight;
    bool is_terminal_net = false;
    for (const auto& c : neti.connected) {
      if (c.type == placerDB::Terminal) {
        is_terminal_net = true;
        break;
      }
    }
    if (is_terminal_net) HPWL_extend_terminal += (HPWL_extend_max_y - HPWL_extend_min_y) + (HPWL_extend_max_x - HPWL_extend_min_x);
  }
  
  if (mydesign.Blocks.size() == 1 && mydesign.Blocks[0][0].xoffset.empty() && mydesign.Blocks[0][0].yoffset.empty()){
    HPWL_ILP = HPWL_extend;
  }

  // HPWL norm
  if (!mydesign.Nets.empty()) HPWL_norm = HPWL_extend / mydesign.GetMaxBlockHPWLSum() / double(mydesign.Nets.size());
  // calculate linear constraint
  linear_const = 0;
  std::vector<std::vector<double>> feature_value;
  for (const auto& neti : mydesign.Nets) {
    std::vector<std::vector<placerDB::point>> center_points;
    for (const auto& connectedj : neti.connected) {
      if (connectedj.type == placerDB::Block) {
        std::vector<placerDB::point> pos;
        for (const auto& ci : mydesign.Blocks[connectedj.iter2][curr_sp.selected[connectedj.iter2]].blockPins[connectedj.iter].center) {
          placerDB::point newp;
          newp.x = ci.x;
          newp.y = ci.y;
          if (Blocks[connectedj.iter2].H_flip) newp.x = mydesign.Blocks[connectedj.iter2][curr_sp.selected[connectedj.iter2]].width - newp.x;
          if (Blocks[connectedj.iter2].V_flip) newp.y = mydesign.Blocks[connectedj.iter2][curr_sp.selected[connectedj.iter2]].height - newp.y;
          newp.x += Blocks[connectedj.iter2].x;
          newp.y += Blocks[connectedj.iter2].y;
          pos.push_back(newp);
        }
        if (!pos.empty()) center_points.push_back(pos);
      } else if (connectedj.type == placerDB::Terminal) {
        center_points.push_back({mydesign.Terminals[connectedj.iter].center});
      }
    }
    std::vector<double> temp_feature = Calculate_Center_Point_feature(center_points);
    feature_value.push_back(temp_feature);
    double temp_sum = 0;
    for (int j = 0; j < neti.connected.size(); j++) if (temp_feature.size() > j) temp_sum += neti.connected[j].alpha * temp_feature[j];
    temp_sum = std::max(temp_sum - neti.upperBound, double(0));
    if(!neti.floating_pin) linear_const += temp_sum;
  }

  if (!mydesign.Nets.empty()) linear_const /= (mydesign.GetMaxBlockHPWLSum() * double(mydesign.Nets.size()));

  // calculate multi linear constraint
  multi_linear_const = 0;
  for (const auto& constrainti : mydesign.ML_Constraints) {
    double temp_sum = 0;
    for (const auto& constraintj : constrainti.Multi_linearConst) {
      for (int k = 0; k < constraintj.pins.size(); k++) {
        int index_i = 0;
        int index_j = 0;
        for (int m = 0; m < mydesign.Nets.size(); m++) {
          for (int n = 0; n < mydesign.Nets[m].connected.size(); n++) {
            if (mydesign.Nets[m].connected[n].iter2 == constraintj.pins[k].first && mydesign.Nets[m].connected[n].iter == constraintj.pins[k].second) {
              index_i = m;
              index_j = n;
              break;
            }
          }
        }
        temp_sum += constraintj.alpha[k] * feature_value[index_i][index_j];
      }
    }
    temp_sum = std::min(temp_sum, constrainti.upperBound);
    multi_linear_const += temp_sum;
  }

  double calculated_cost = CalculateCost(mydesign, curr_sp);
  cost = calculated_cost;
  if (cost >= 0.) {
    logger->debug("ILP__HPWL_compare : HPWL_extend={0} HPWL_ILP={1}", HPWL_extend, HPWL_ILP);
    logger->debug("ILP__Area_compare : area={0} area_ilp={1}", area, area_ilp);
    assert(round(HPWL_extend) == round(HPWL_ILP));
  }
  return calculated_cost;
}


double ILP_solver::CalculateCFCost(const design& mydesign, const SeqPair& curr_sp) {
	double cost(0.);
  for (const auto& it : mydesign.CFValues) {
    std::map<std::pair<int, int>, PnRDB::bbox> pinCoords;
    for (auto& pp : it.second) {
      for (unsigned i : {0, 1}) {
        auto iter2 = (i == 0) ? std::get<0>(pp.first) : std::get<2>(pp.first);
        auto iter  = (i == 0) ? std::get<1>(pp.first) : std::get<3>(pp.first);
        int x1(INT_MAX), y1(INT_MAX), x2(INT_MIN), y2(INT_MIN);
        for (const auto& boundaryk : mydesign.Blocks[iter2][curr_sp.selected[iter2]].blockPins[iter].boundary) {
          int pin_llx = boundaryk.polygon[0].x, pin_urx = boundaryk.polygon[2].x;
          int pin_lly = boundaryk.polygon[0].y, pin_ury = boundaryk.polygon[2].y;
          if (Blocks[iter2].H_flip) {
            pin_llx = mydesign.Blocks[iter2][curr_sp.selected[iter2]].width - boundaryk.polygon[2].x;
            pin_urx = mydesign.Blocks[iter2][curr_sp.selected[iter2]].width - boundaryk.polygon[0].x;
          }
          if (Blocks[iter2].V_flip) {
            pin_lly = mydesign.Blocks[iter2][curr_sp.selected[iter2]].height - boundaryk.polygon[2].y;
            pin_ury = mydesign.Blocks[iter2][curr_sp.selected[iter2]].height - boundaryk.polygon[0].y;
          }
          pin_llx += Blocks[iter2].x;
          pin_urx += Blocks[iter2].x;
          pin_lly += Blocks[iter2].y;
          pin_ury += Blocks[iter2].y;
          x1 = std::min(pin_llx, x1);
          y1 = std::min(pin_lly, y1);
          x2 = std::max(pin_urx, x2);
          y2 = std::max(pin_ury, y2);
        }
        if (x1 != INT_MAX) pinCoords[make_pair(iter2, iter)] = PnRDB::bbox(x1, y1, x2, y2);
      }
    }
    for (auto& pp : it.second) {
      double dist(0.);
      auto pin1iter2 = std::get<0>(pp.first);
      auto pin1iter  = std::get<1>(pp.first);
      auto pin2iter2 = std::get<2>(pp.first);
      auto pin2iter  = std::get<3>(pp.first);
      auto it1 = pinCoords.find(std::make_pair(pin1iter2, pin1iter));
      auto it2 = pinCoords.find(std::make_pair(pin2iter2, pin2iter));
      if (it1 != pinCoords.end() && it2 != pinCoords.end()) {
        const auto& b1 = it1->second;
        const auto& b2 = it2->second;
        if (mydesign.CFdist_type == 0) {
          auto center1 = it1->second.center();
          auto center2 = it2->second.center();
          double dx = center1.x - center2.x;
          double dy = center1.y - center2.y;
          dist = sqrt(dx*dx + dy*dy);
        } else {
          double xprl = std::min(it1->second.UR.x, it2->second.UR.x) - std::max(it1->second.LL.x, it2->second.LL.x);
          double yprl = std::min(it1->second.UR.y, it2->second.UR.y) - std::max(it1->second.LL.y, it2->second.LL.y);
          dist = (xprl < 0 ? abs(xprl) : 0) + (yprl < 0 ? abs(yprl) : 0);
        }
      }
      cost += dist * pp.second;
    }
  }
  return cost;
}

double ILP_solver::CalculateCost(const design& mydesign) const {
  Pdatatype hyper;
  double cost = 0;
  cost += area;
  cost += HPWL * hyper.LAMBDA;
  double match_cost = 0;
  for (const auto& mbi : mydesign.Match_blocks) {
    match_cost +=
        abs(Blocks[mbi.blockid1].x + mydesign.Blocks[mbi.blockid1][0].width / 2 - Blocks[mbi.blockid2].x - mydesign.Blocks[mbi.blockid2][0].width / 2) +
        abs(Blocks[mbi.blockid1].y + mydesign.Blocks[mbi.blockid1][0].height / 2 - Blocks[mbi.blockid2].y - mydesign.Blocks[mbi.blockid2][0].height / 2);
  }
  cost += match_cost * hyper.BETA;
  cost += ratio * Aspect_Ratio_weight;
  cost += 0.0 / area * hyper.PHI; //dead_area
  cost += linear_const * hyper.PI;
  cost += multi_linear_const * hyper.PII;
  assert(!isnan(cost));
  return cost;
}

double ILP_solver::CalculateCost(const design& mydesign, const SeqPair& curr_sp) {
  auto logger = spdlog::default_logger()->clone("placer.ILP_solver.CalculateCost");

  Pdatatype hyper;
  double cost = 0;

  if (false) {
    cost += area_norm;
    cost += HPWL_norm * hyper.LAMBDA;
  } else {
    cost += log(area);
    if (HPWL_extend_net_priority > 0) {
      cost += log(HPWL_extend_net_priority) * hyper.LAMBDA;
    }
    cfcost = CalculateCFCost(mydesign, curr_sp);
    if (cfcost > 0) {
      cost += log(cfcost) * hyper.LAMBDA;
    }
  }

  double match_cost = 0;
  double max_dim = std::max(UR.x - LL.x, UR.y - LL.y);
  for (const auto& mbi : mydesign.Match_blocks) {
    match_cost += (abs(Blocks[mbi.blockid1].x + mydesign.Blocks[mbi.blockid1][curr_sp.selected[mbi.blockid1]].width / 2 - Blocks[mbi.blockid2].x -
                       mydesign.Blocks[mbi.blockid2][curr_sp.selected[mbi.blockid2]].width / 2) +
                   abs(Blocks[mbi.blockid1].y + mydesign.Blocks[mbi.blockid1][curr_sp.selected[mbi.blockid1]].height / 2 - Blocks[mbi.blockid2].y -
                       mydesign.Blocks[mbi.blockid2][curr_sp.selected[mbi.blockid2]].height / 2)) /
                  max_dim;
  }
  if (!mydesign.Match_blocks.empty()) match_cost /= (mydesign.Match_blocks.size());
  if (!isnan(linear_const) && !isnan(multi_linear_const) && !isnan(match_cost)) {
    constraint_penalty = match_cost * hyper.BETA + linear_const * hyper.PI + multi_linear_const * hyper.PII;
    cost += constraint_penalty;
  }
  if (cost > 0 && HPWL_extend_net_priority > 0 && cfcost > 0) {
    logger->debug("ILP calculate cost hpwl : {0} cfcost : {1} logcosts : {2} {3} {4} {5}", HPWL_extend_net_priority, cfcost, log(HPWL_extend_net_priority) * hyper.LAMBDA,
        log(cfcost) * hyper.LAMBDA, log(area), cost);
  }
  return cost;
}

void ILP_solver::WritePlacement(design& mydesign, SeqPair& curr_sp, string outfile) {
  ofstream fout;
  fout.open(outfile.c_str());
  // cout << "Placer-Info: write placement" << endl;
  fout << "# TAMU blocks 1.0" << endl << endl;
  fout << "DIE {" << LL.x << ", " << LL.y << "} {" << UR.x << "," << UR.y << "}" << endl << endl;
  for (unsigned int i = 0; i < mydesign.Blocks.size(); ++i) {
    string ort;
    if (!Blocks[i].H_flip && !Blocks[i].V_flip) {
      ort = "N";
    } else if (Blocks[i].H_flip && !Blocks[i].V_flip) {
      ort = "FN";
    } else if (!Blocks[i].H_flip && Blocks[i].V_flip) {
      ort = "FS";
    } else {
      ort = "S";
    }
    fout << mydesign.Blocks.at(i).back().name << "\t" << Blocks[i].x << "\t" << Blocks[i].y << "\t" << ort << endl;
  }
  fout << endl;
  for (const auto& ni : mydesign.Nets) {
    // for each pin
    for (const auto& ci : ni.connected) {
      if (ci.type == placerDB::Terminal) {
        int tno = ci.iter;
        fout << mydesign.Terminals.at(tno).name << "\t" << mydesign.Terminals.at(tno).center.x << "\t" << mydesign.Terminals.at(tno).center.y << endl;
        break;
      }
    }
  }
  fout.close();
}

/**
void ILP_solver::PlotPlacementAnalytical(design& mydesign, string outfile, bool plot_pin, bool plot_terminal, bool plot_net) {
  // cout << "Placer-Info: create gnuplot file" << endl;
  placerDB::point p, bp;
  if(!mydesign.is_first_ILP){
    ofstream f("Results/" + mydesign.name + "_gds/" + mydesign.name + ".csv", std::ios::app);
    if(f.is_open()){
      f << mydesign.placement_id << " " << area << " " << HPWL << endl;
    }
    f.close();
  }

  ofstream fout;
  vector<placerDB::point> p_pin;
  fout.open(outfile.c_str());
  fout << "#Use this file as a script for gnuplot\n#(See http://www.gnuplot.info/ for details)" << endl;
  fout << "\nset title \" "<< mydesign.name << " #Blocks= " << mydesign.Blocks.size() << ", #Terminals= " << mydesign.Terminals.size() << ", #Nets= " << mydesign.Nets.size()
       << ",Area=" << area << ", HPWL= " << HPWL << " \"" << endl;
  fout << "\nset nokey" << endl;
  fout << "#   Uncomment these two lines starting with \"set\"" << endl;
  fout << "#   to save an EPS file for inclusion into a latex document" << endl;
  fout << "# set terminal postscript eps color solid 20" << endl;
  fout << "# set output \"result.eps\"" << endl << endl;
  fout << "#   Uncomment these two lines starting with \"set\"" << endl;
  fout << "#   to save a PS file for printing" << endl;
  fout << "# set terminal postscript portrait color solid 20" << endl;
  fout << "# set output \"result.ps\"" << endl << endl;

  int bias = 100;
  int range = std::max(UR.x, UR.y) + bias;
  fout << "\nset xrange [" << LL.x - bias << ":" << UR.x + bias << "]" << endl;
  fout << "\nset yrange [" << LL.y - bias << ":" << UR.y + bias << "]" << endl;
  // set labels for blocks
  for (unsigned int i = 0; i < mydesign.Blocks.size(); ++i) {
    placerDB::point tp;
    tp.x = Blocks[i].x + mydesign.Blocks[i][0].width / 2;
    tp.y = Blocks[i].y + mydesign.Blocks[i][0].height / 2;
    if(mydesign.Blocks[i][0].width>0 && mydesign.Blocks[i][0].height>0)
      fout << "\nset label \"" << mydesign.Blocks[i][0].name << "\" at " << tp.x << " , " << tp.y << " center " << endl;
    if (plot_pin) {
      for (unsigned int j = 0; j < mydesign.Blocks[i][0].blockPins.size(); j++) {
        for (unsigned int k = 0; k < mydesign.Blocks[i][0].blockPins[j].center.size(); k++) {
          placerDB::point newp;
          newp.x = mydesign.Blocks[i][0].blockPins[j].center[k].x;
          newp.y = mydesign.Blocks[i][0].blockPins[j].center[k].y;
          if (Blocks[i].H_flip) newp.x = mydesign.Blocks[i][0].width - newp.x;
          if (Blocks[i].V_flip) newp.y = mydesign.Blocks[i][0].height - newp.y;
          newp.x += Blocks[i].x;
          newp.y += Blocks[i].y;
          fout << "\nset label \"" << mydesign.Blocks[i][0].blockPins[j].name << "\" at " << newp.x << " , " << newp.y << endl;
          fout << endl;
        }
      }
    }
  }

  // set labels for terminals
  // cout << "set labels for terminals..." << endl;
  if (plot_terminal) {
    for (const auto& ni : mydesign.Nets) {
      // for each pin
      for (const auto& ci : ni.connected) {
        if (ci.type == placerDB::Terminal) {
          int tno = ci.iter;
          fout << "\nset label \"" << mydesign.Terminals.at(tno).name << "\" at " << mydesign.Terminals.at(tno).center.x << " , "
              << mydesign.Terminals.at(tno).center.y << " center                " << endl;
          break;
        }
      }
    }
  }

  // plot blocks
  fout << "\nplot[:][:] \'-\' with lines linestyle 3";
  if(plot_pin)fout << ", \'-\' with lines linestyle 7";
  if(plot_terminal)fout << ", \'-\' with lines linestyle 1";
  if(plot_net)fout << ", \'-\' with lines linestyle 0";
  fout << endl << endl;
  for (unsigned int i = 0; i < mydesign.Blocks.size(); ++i) {
    vector<placerDB::point> newp = mydesign.Blocks[i][0].boundary.polygon;
    fout << "# block " << mydesign.Blocks[i][0].name << " select " << 0 << " bsize " << newp.size() << endl;
    for (unsigned int it = 0; it < newp.size(); it++) {
      fout << "\t" << newp[it].x + Blocks[i].x << "\t" << newp[it].y + Blocks[i].y << endl;
    }
    fout << "\t" << newp[0].x + Blocks[i].x << "\t" << newp[0].y + Blocks[i].y << endl;
    fout << endl;
  }
  fout << "\nEOF" << endl;

  // plot block pins
  if(plot_pin){
    for (unsigned int i = 0; i < mydesign.Blocks.size(); ++i) {
      for (unsigned int j = 0; j < mydesign.Blocks[i][0].blockPins.size(); j++) {
        for (unsigned int k = 0; k < mydesign.Blocks[i][0].blockPins[j].boundary.size(); k++) {
          for (unsigned int it = 0; it < mydesign.Blocks[i][0].blockPins[j].boundary[k].polygon.size(); it++) {
            placerDB::point newp;
            newp.x = mydesign.Blocks[i][0].blockPins[j].boundary[k].polygon[it].x;
            newp.y = mydesign.Blocks[i][0].blockPins[j].boundary[k].polygon[it].y;
            if (Blocks[i].H_flip) newp.x = mydesign.Blocks[i][0].width - newp.x;
            if (Blocks[i].V_flip) newp.y = mydesign.Blocks[i][0].height - newp.y;
            newp.x += Blocks[i].x;
            newp.y += Blocks[i].y;
            fout << "\t" << newp.x << "\t" << newp.y << endl;
          }
          placerDB::point newp;
          newp.x = mydesign.Blocks[i][0].blockPins[j].boundary[k].polygon[0].x;
          newp.y = mydesign.Blocks[i][0].blockPins[j].boundary[k].polygon[0].y;
          if (Blocks[i].H_flip) newp.x = mydesign.Blocks[i][0].width - newp.x;
          if (Blocks[i].V_flip) newp.y = mydesign.Blocks[i][0].height - newp.y;
          newp.x += Blocks[i].x;
          newp.y += Blocks[i].y;
          fout << "\t" << newp.x << "\t" << newp.y << endl;
          fout << endl;
        }
      }
    }
    fout << "\nEOF" << endl;
  }

  // plot terminals
  if (plot_terminal) {
    for (const auto& ni : mydesign.Nets) {
      // for each pin
      for (const auto& ci : ni.connected) {
        if (ci.type == placerDB::Terminal) {
          int tno = ci.iter;
          int bias = 20;
          fout << endl;
          fout << "\t" << mydesign.Terminals.at(tno).center.x - bias << "\t" << mydesign.Terminals.at(tno).center.y - bias << endl;
          fout << "\t" << mydesign.Terminals.at(tno).center.x - bias << "\t" << mydesign.Terminals.at(tno).center.y + bias << endl;
          fout << "\t" << mydesign.Terminals.at(tno).center.x + bias << "\t" << mydesign.Terminals.at(tno).center.y + bias << endl;
          fout << "\t" << mydesign.Terminals.at(tno).center.x + bias << "\t" << mydesign.Terminals.at(tno).center.y - bias << endl;
          fout << "\t" << mydesign.Terminals.at(tno).center.x - bias << "\t" << mydesign.Terminals.at(tno).center.y - bias << endl;
          break;
        }
      }
    }
    fout << "\nEOF" << endl;
  }

  // plot nets
  if(plot_net){
    for (vector<placerDB::net>::iterator ni = mydesign.Nets.begin(); ni != mydesign.Nets.end(); ++ni) {
      placerDB::point tp;
      vector<placerDB::point> pins;
      // for each pin
      for (const auto& ci : ni->connected) {
        if (ci.type == placerDB::Block) {
          if (mydesign.Blocks[ci.iter2][0].blockPins.size() > 0) {
            if (mydesign.Blocks[ci.iter2][0].blockPins[ci.iter].center.size() > 0) {
              tp.x = mydesign.Blocks[ci.iter2][0].blockPins[ci.iter].center[0].x;
              tp.y = mydesign.Blocks[ci.iter2][0].blockPins[ci.iter].center[0].y;
              if (Blocks[ci.iter2].H_flip) tp.x = mydesign.Blocks[ci.iter2][0].width - tp.x;
              if (Blocks[ci.iter2].V_flip) tp.y = mydesign.Blocks[ci.iter2][0].height - tp.y;
              tp.x += Blocks[ci.iter2].x;
              tp.y += Blocks[ci.iter2].y;
              pins.push_back(tp);
            }
          } else {
            tp.x = mydesign.Blocks[ci.iter2][0].width / 2;
            tp.y = mydesign.Blocks[ci.iter2][0].height / 2;
            if (Blocks[ci.iter2].H_flip) tp.x = mydesign.Blocks[ci.iter2][0].width - tp.x;
            if (Blocks[ci.iter2].V_flip) tp.y = mydesign.Blocks[ci.iter2][0].height - tp.y;
            tp.x += Blocks[ci.iter2].x;
            tp.y += Blocks[ci.iter2].y;
            pins.push_back(tp);
          }
        } else if (ci.type == placerDB::Terminal) {
          pins.push_back(mydesign.Terminals.at(ci.iter).center);
        }
      }
      fout << "\n#Net: " << ni->name << endl;
      if (pins.size() >= 2) {
        for (int i = 1; i < (int)pins.size(); i++) {
          fout << "\t" << pins.at(0).x << "\t" << pins.at(0).y << endl;
          fout << "\t" << pins.at(i).x << "\t" << pins.at(i).y << endl;
          fout << "\t" << pins.at(0).x << "\t" << pins.at(0).y << endl << endl;
        }
      }
    }
    fout << "\nEOF" << endl;
  }
  fout << endl << "pause -1 \'Press any key\'";
  fout.close();
}**/

void ILP_solver::PlotPlacement(design& mydesign, SeqPair& curr_sp, string outfile) {
  // cout << "Placer-Info: create gnuplot file" << endl;
  placerDB::point p, bp;
  ofstream fout;
  vector<placerDB::point> p_pin;
  fout.open(outfile.c_str());
  fout << "#Use this file as a script for gnuplot\n#(See http://www.gnuplot.info/ for details)" << endl;
  fout << "\nset title\" #Blocks= " << mydesign.Blocks.size() << ", #Terminals= " << mydesign.Terminals.size() << ", #Nets= " << mydesign.Nets.size()
       << ",Area=" << area << ", HPWL= " << HPWL_extend << " \"" << endl;
  fout << "\nset nokey" << endl;
  fout << "#   Uncomment these two lines starting with \"set\"" << endl;
  fout << "#   to save an EPS file for inclusion into a latex document" << endl;
  fout << "# set terminal postscript eps color solid 20" << endl;
  fout << "# set output \"result.eps\"" << endl << endl;
  fout << "#   Uncomment these two lines starting with \"set\"" << endl;
  fout << "#   to save a PS file for printing" << endl;
  fout << "# set terminal postscript portrait color solid 20" << endl;
  fout << "# set output \"result.ps\"" << endl << endl;

  int bias = 50;
  int range = std::max(UR.x, UR.y) + bias;
  fout << "\nset xrange [" << LL.x - bias << ":" << UR.x + bias << "]" << endl;
  fout << "\nset yrange [" << LL.y - bias << ":" << UR.y + bias << "]" << endl;
  // set labels for blocks
  for (int i = 0; i < mydesign.Blocks.size(); ++i) {
    placerDB::point tp;
    tp.x = Blocks[i].x + mydesign.Blocks[i][curr_sp.selected[i]].width / 2;
    tp.y = Blocks[i].y + mydesign.Blocks[i][curr_sp.selected[i]].height / 2;
    fout << "\nset label \"" << mydesign.Blocks[i][curr_sp.selected[i]].name << "\" at " << tp.x << " , " << tp.y << " center " << endl;
    for (unsigned int j = 0; j < mydesign.Blocks[i][curr_sp.selected[i]].blockPins.size(); j++) {
      for (unsigned int k = 0; k < mydesign.Blocks[i][curr_sp.selected[i]].blockPins[j].center.size(); k++) {
        placerDB::point newp;
        newp.x = mydesign.Blocks[i][curr_sp.selected[i]].blockPins[j].center[k].x;
        newp.y = mydesign.Blocks[i][curr_sp.selected[i]].blockPins[j].center[k].y;
        if (Blocks[i].H_flip) newp.x = mydesign.Blocks[i][curr_sp.selected[i]].width - newp.x;
        if (Blocks[i].V_flip) newp.y = mydesign.Blocks[i][curr_sp.selected[i]].height - newp.y;
        newp.x += Blocks[i].x;
        newp.y += Blocks[i].y;
        fout << "\nset label \"" << mydesign.Blocks[i][curr_sp.selected[i]].blockPins[j].name << "\" at " << newp.x << " , " << newp.y << endl;
        fout << endl;
      }
    }
  }

  // set labels for terminals
  // cout << "set labels for terminals..." << endl;
  for (const auto& ni : mydesign.Nets) {
    // for each pin
    for (const auto& ci : ni.connected) {
      if (ci.type == placerDB::Terminal) {
        int tno = ci.iter;
        fout << "\nset label \"" << mydesign.Terminals.at(tno).name << "\" at " << mydesign.Terminals.at(tno).center.x << " , "
             << mydesign.Terminals.at(tno).center.y << " center                " << endl;
        break;
      }
    }
  }

  // plot blocks
  fout << "\nplot[:][:] \'-\' with lines linestyle 3, \'-\' with lines linestyle 7, \'-\' with lines linestyle 1, \'-\' with lines linestyle 0" << endl << endl;
  for (unsigned int i = 0; i < mydesign.Blocks.size(); ++i) {
    vector<placerDB::point> newp = mydesign.Blocks[i][curr_sp.selected[i]].boundary.polygon;
    fout << "# block " << mydesign.Blocks[i][curr_sp.selected[i]].name << " select " << curr_sp.selected[i] << " bsize " << newp.size() << endl;
    for (unsigned int it = 0; it < newp.size(); it++) {
      fout << "\t" << newp[it].x + Blocks[i].x << "\t" << newp[it].y + Blocks[i].y << endl;
    }
    fout << "\t" << newp[0].x + Blocks[i].x << "\t" << newp[0].y + Blocks[i].y << endl;
    fout << endl;
  }
  fout << "\nEOF" << endl;

  // plot block pins
  for (unsigned int i = 0; i < mydesign.Blocks.size(); ++i) {
    for (unsigned int j = 0; j < mydesign.Blocks[i][curr_sp.selected[i]].blockPins.size(); j++) {
      for (unsigned int k = 0; k < mydesign.Blocks[i][curr_sp.selected[i]].blockPins[j].boundary.size(); k++) {
        for (unsigned int it = 0; it < mydesign.Blocks[i][curr_sp.selected[i]].blockPins[j].boundary[k].polygon.size(); it++) {
          placerDB::point newp;
          newp.x = mydesign.Blocks[i][curr_sp.selected[i]].blockPins[j].boundary[k].polygon[it].x;
          newp.y = mydesign.Blocks[i][curr_sp.selected[i]].blockPins[j].boundary[k].polygon[it].y;
          if (Blocks[i].H_flip) newp.x = mydesign.Blocks[i][curr_sp.selected[i]].width - newp.x;
          if (Blocks[i].V_flip) newp.y = mydesign.Blocks[i][curr_sp.selected[i]].height - newp.y;
          newp.x += Blocks[i].x;
          newp.y += Blocks[i].y;
          fout << "\t" << newp.x << "\t" << newp.y << endl;
        }
        placerDB::point newp;
        newp.x = mydesign.Blocks[i][curr_sp.selected[i]].blockPins[j].boundary[k].polygon[0].x;
        newp.y = mydesign.Blocks[i][curr_sp.selected[i]].blockPins[j].boundary[k].polygon[0].y;
        if (Blocks[i].H_flip) newp.x = mydesign.Blocks[i][curr_sp.selected[i]].width - newp.x;
        if (Blocks[i].V_flip) newp.y = mydesign.Blocks[i][curr_sp.selected[i]].height - newp.y;
        newp.x += Blocks[i].x;
        newp.y += Blocks[i].y;
        fout << "\t" << newp.x << "\t" << newp.y << endl;
        fout << endl;
      }
    }
  }
  fout << "\nEOF" << endl;

  // plot terminals
  for (const auto& ni : mydesign.Nets) {
    // for each pin
    for (const auto& ci : ni.connected) {
      if (ci.type == placerDB::Terminal) {
        int tno = ci.iter;
        int bias = 0;
        fout << endl;
        fout << "\t" << mydesign.Terminals.at(tno).center.x - bias << "\t" << mydesign.Terminals.at(tno).center.y - bias << endl;
        fout << "\t" << mydesign.Terminals.at(tno).center.x - bias << "\t" << mydesign.Terminals.at(tno).center.y + bias << endl;
        fout << "\t" << mydesign.Terminals.at(tno).center.x + bias << "\t" << mydesign.Terminals.at(tno).center.y + bias << endl;
        fout << "\t" << mydesign.Terminals.at(tno).center.x + bias << "\t" << mydesign.Terminals.at(tno).center.y - bias << endl;
        fout << "\t" << mydesign.Terminals.at(tno).center.x - bias << "\t" << mydesign.Terminals.at(tno).center.y - bias << endl;
        break;
      }
    }
  }
  fout << "\nEOF" << endl;

  // plot nets
  for (vector<placerDB::net>::iterator ni = mydesign.Nets.begin(); ni != mydesign.Nets.end(); ++ni) {
    placerDB::point tp;
    vector<placerDB::point> pins;
    // for each pin
    for (const auto& ci : ni->connected) {
      if (ci.type == placerDB::Block) {
        if (mydesign.Blocks[ci.iter2][curr_sp.selected[ci.iter2]].blockPins[ci.iter].center.size() > 0) {
          tp.x = mydesign.Blocks[ci.iter2][curr_sp.selected[ci.iter2]].blockPins[ci.iter].center[0].x;
          tp.y = mydesign.Blocks[ci.iter2][curr_sp.selected[ci.iter2]].blockPins[ci.iter].center[0].y;
          if (Blocks[ci.iter2].H_flip) tp.x = mydesign.Blocks[ci.iter2][curr_sp.selected[ci.iter2]].width - tp.x;
          if (Blocks[ci.iter2].V_flip) tp.y = mydesign.Blocks[ci.iter2][curr_sp.selected[ci.iter2]].height - tp.y;
          tp.x += Blocks[ci.iter2].x;
          tp.y += Blocks[ci.iter2].y;
          pins.push_back(tp);
        }
      } else if (ci.type == placerDB::Terminal) {
        pins.push_back(mydesign.Terminals.at(ci.iter).center);
      }
    }
    fout << "\n#Net: " << ni->name << endl;
    if (pins.size() >= 2) {
      for (int i = 1; i < (int)pins.size(); i++) {
        fout << "\t" << pins.at(0).x << "\t" << pins.at(0).y << endl;
        fout << "\t" << pins.at(i).x << "\t" << pins.at(i).y << endl;
        fout << "\t" << pins.at(0).x << "\t" << pins.at(0).y << endl << endl;
      }
    }
  }
  fout << "\nEOF" << endl;
  fout << endl << "pause -1 \'Press any key\'";
  fout.close();
}

std::vector<double> ILP_solver::Calculate_Center_Point_feature(std::vector<std::vector<placerDB::point>>& temp_contact) {
  std::vector<double> temp_x;
  std::vector<double> temp_y;
  std::vector<double> feature;
  double sum_x;
  double sum_y;
  for (unsigned int i = 0; i < temp_contact.size(); i++) {
    sum_x = 0;
    sum_y = 0;
    for (unsigned int j = 0; j < temp_contact[i].size(); j++) {
      sum_x = sum_x + (double)temp_contact[i][j].x;
      sum_y = sum_y + (double)temp_contact[i][j].y;
    }
    sum_x = sum_x / (double)temp_contact[i].size();
    sum_y = sum_y / (double)temp_contact[i].size();
    temp_x.push_back(sum_x);
    temp_y.push_back(sum_y);
  }

  sum_x = 0;
  sum_y = 0;
  for (unsigned int i = 0; i < temp_x.size(); i++) {
    sum_x = sum_x + temp_x[i];
    sum_y = sum_y + temp_y[i];
  }
  double center_x = sum_x / (double)temp_x.size();
  double center_y = sum_y / (double)temp_y.size();
  for (unsigned int i = 0; i < temp_x.size(); i++) {
    feature.push_back(abs(center_x - (double)temp_x[i]) + abs(center_y - (double)temp_y[i]));
  }
  return feature;
}

void ILP_solver::updateTerminalCenterAnalytical(design& mydesign) {
  auto logger = spdlog::default_logger()->clone("placer.ILP_solver.updateTerminalCenter");

  int Xmax = UR.x;
  int Ymax = UR.y;
  vector<placerDB::point> pos;
  placerDB::point p, bp;
  int alpha;
  vector<placerDB::point> pos_pin;
  std::set<int> solved_terminals;
  // for each terminal
  for (unsigned int i = 0; i < mydesign.Terminals.size(); i++) {
    if (solved_terminals.find(i) != solved_terminals.end()) continue;
    solved_terminals.insert(i);
    int netIdx = mydesign.Terminals.at(i).netIter;
    int sbIdx = mydesign.Terminals.at(i).SBidx;
    int cp = mydesign.Terminals.at(i).counterpart;
    if (netIdx < 0 || netIdx >= mydesign.Nets.size()) {
      logger->error("Placer-Warning: terminal {0} is dangling; set it on origin", i);
      mydesign.Terminals.at(i).center = {0, 0};
      continue;
    }
    if ((mydesign.Nets.at(netIdx).priority).compare("min") == 0) {
      alpha = 4;
    } else if ((mydesign.Nets.at(netIdx).priority).compare("mid") == 0) {
      alpha = 2;
    } else {
      alpha = 1;
    }
    alpha *= mydesign.Nets.at(netIdx).weight;  // add weight to reflect the modification for bigMacros
    if (sbIdx != -1) {                         // in symmetry group
      placerDB::Smark axis = mydesign.SBlocks[sbIdx].axis_dir;
      if (cp == (int)i) {  // self-symmetric
        if (axis == placerDB::V) {
          int axis_X = Blocks[mydesign.SBlocks[sbIdx].selfsym[0].first].x + mydesign.Blocks[mydesign.SBlocks[sbIdx].selfsym[0].first][0].width / 2;
          int distTerm = INT_MAX;
          placerDB::point tp(axis_X, 0);
          for (const auto& ci : mydesign.Nets[netIdx].connected) {
            if (ci.type == placerDB::Block) {
              bp = placerDB::point(Blocks[ci.iter2].x, Blocks[ci.iter2].y);
              for (unsigned int k = 0; k < mydesign.Blocks[ci.iter2][0].blockPins[ci.iter].center.size(); k++) {
                p = mydesign.Blocks[ci.iter2][0].blockPins[ci.iter].center[k];
                if (Blocks[ci.iter2].H_flip) p.x = mydesign.Blocks[ci.iter2][0].width - p.x;
                if (Blocks[ci.iter2].V_flip) p.y = mydesign.Blocks[ci.iter2][0].height - p.y;
                p += bp;
                if (p.y < distTerm) {
                  distTerm = p.y;
                  tp.y = 0;
                }
                if (Ymax - p.y < distTerm) {
                  distTerm = Ymax - p.y;
                  tp.y = Ymax;
                }
              }
            }
          }
          mydesign.Terminals.at(i).center = tp;
        } else if (axis == placerDB::H) {
          int axis_Y = Blocks[mydesign.SBlocks[sbIdx].selfsym[0].first].y + mydesign.Blocks[mydesign.SBlocks[sbIdx].selfsym[0].first][0].height / 2;
          int distTerm = INT_MAX;
          placerDB::point tp(0, axis_Y);
          for (const auto& ci : mydesign.Nets.at(netIdx).connected) {
            if (ci.type == placerDB::Block) {
              bp = placerDB::point(Blocks[ci.iter2].x, Blocks[ci.iter2].y);
              for (unsigned int k = 0; k < mydesign.Blocks[ci.iter2][0].blockPins[ci.iter].center.size(); k++) {
                p = mydesign.Blocks[ci.iter2][0].blockPins[ci.iter].center[k];
                if (Blocks[ci.iter2].H_flip) p.x = mydesign.Blocks[ci.iter2][0].width - p.x;
                if (Blocks[ci.iter2].V_flip) p.y = mydesign.Blocks[ci.iter2][0].height - p.y;
                p += bp;
                if (p.x < distTerm) {
                  distTerm = p.x;
                  tp.x = 0;
                }
                if (Xmax - p.x < distTerm) {
                  distTerm = Xmax - p.x;
                  tp.x = Xmax;
                }
              }
            }
          }
          mydesign.Terminals.at(i).center = tp;
        } else {
          logger->error("Placer-Error: incorrect axis direction");
        }
      } else {  // symmetry pair
        if (solved_terminals.find(cp) != solved_terminals.end()) continue;
        solved_terminals.insert(cp);
        int netIdx2 = mydesign.Terminals.at(cp).netIter;
        if (netIdx2 < 0 or netIdx2 >= mydesign.Nets.size()) {
          logger->error("Placer-Error: terminal {0} is not dangling, but its counterpart {1} is dangling; set them on origin", i, cp);
          mydesign.Terminals.at(i).center = {0, 0};
          mydesign.Terminals.at(cp).center = {0, 0};
          continue;
        }
        int alpha2;
        if ((mydesign.Nets.at(netIdx2).priority).compare("min") == 0) {
          alpha2 = 4;
        } else if ((mydesign.Nets.at(netIdx2).priority).compare("mid") == 0) {
          alpha2 = 2;
        } else {
          alpha2 = 1;
        }
        alpha2 *= mydesign.Nets.at(netIdx2).weight;  // add weight to reflect the modification for bigMacros
        if (axis == placerDB::V) {
          placerDB::point tpL1, tpR1;
          int distTermL = INT_MAX, distTermR = INT_MAX;
          for (const auto& ci : mydesign.Nets.at(netIdx).connected) {
            if (ci.type == placerDB::Block) {
              bp = placerDB::point(Blocks[ci.iter2].x, Blocks[ci.iter2].y);
              for (unsigned int k = 0; k < mydesign.Blocks[ci.iter2][0].blockPins[ci.iter].center.size(); k++) {
                p = mydesign.Blocks[ci.iter2][0].blockPins[ci.iter].center[k];
                if (Blocks[ci.iter2].H_flip) p.x = mydesign.Blocks[ci.iter2][0].width - p.x;
                if (Blocks[ci.iter2].V_flip) p.y = mydesign.Blocks[ci.iter2][0].height - p.y;
                p += bp;
                if (p.x < distTermL) {
                  distTermL = p.x;
                  tpL1.x = 0;
                  tpL1.y = p.y;
                }
                if (Xmax - p.x < distTermR) {
                  distTermR = Xmax - p.x;
                  tpR1.x = Xmax;
                  tpR1.y = p.y;
                }
              }
            }
          }
          placerDB::point tpL2, tpR2;
          int distTermL2 = INT_MAX, distTermR2 = INT_MAX;
          for (const auto& ci : mydesign.Nets.at(netIdx2).connected) {
            if (ci.type == placerDB::Block) {
              bp = placerDB::point(Blocks[ci.iter2].x, Blocks[ci.iter2].y);
              for (unsigned int k = 0; k < mydesign.Blocks[ci.iter2][0].blockPins[ci.iter].center.size(); k++) {
                p = mydesign.Blocks[ci.iter2][0].blockPins[ci.iter].center[k];
                if (Blocks[ci.iter2].H_flip) p.x = mydesign.Blocks[ci.iter2][0].width - p.x;
                if (Blocks[ci.iter2].V_flip) p.y = mydesign.Blocks[ci.iter2][0].height - p.y;
                p += bp;
                if (p.x < distTermL2) {
                  distTermL2 = p.x;
                  tpL2.x = 0;
                  tpL2.y = p.y;
                }
                if (Xmax - p.x < distTermR2) {
                  distTermR2 = Xmax - p.x;
                  tpR2.x = Xmax;
                  tpR2.y = p.y;
                }
              }
            }
          }
          if (distTermL * alpha + distTermR2 * alpha2 < distTermR * alpha + distTermL2 * alpha2) {
            mydesign.Terminals.at(i).center = tpL1;
            mydesign.Terminals.at(cp).center = tpR2;
          } else {
            mydesign.Terminals.at(i).center = tpR1;
            mydesign.Terminals.at(cp).center = tpL2;
          }
        } else if (axis == placerDB::H) {
          placerDB::point tpL1, tpU1;
          int distTermL = INT_MAX, distTermU = INT_MAX;
          for (const auto& ci : mydesign.Nets.at(netIdx).connected) {
            if (ci.type == placerDB::Block) {
              bp = placerDB::point(Blocks[ci.iter2].x, Blocks[ci.iter2].y);
              for (unsigned int k = 0; k < mydesign.Blocks[ci.iter2][0].blockPins[ci.iter].center.size(); k++) {
                p = mydesign.Blocks[ci.iter2][0].blockPins[ci.iter].center[k];
                if (Blocks[ci.iter2].H_flip) p.x = mydesign.Blocks[ci.iter2][0].width - p.x;
                if (Blocks[ci.iter2].V_flip) p.y = mydesign.Blocks[ci.iter2][0].height - p.y;
                p += bp;
                if (p.y < distTermL) {
                  distTermL = p.y;
                  tpL1.x = p.x;
                  tpL1.y = 0;
                }
                if (Ymax - p.y < distTermU) {
                  distTermU = Ymax - p.y;
                  tpU1.x = p.x;
                  tpU1.y = Ymax;
                }
              }
            }
          }
          placerDB::point tpL2, tpU2;
          int distTermL2 = INT_MAX, distTermU2 = INT_MAX;
          for (const auto& ci : mydesign.Nets.at(netIdx2).connected) {
            if (ci.type == placerDB::Block) {
              bp = placerDB::point(Blocks[ci.iter2].x, Blocks[ci.iter2].y);
              for (unsigned int k = 0; k < mydesign.Blocks[ci.iter2][0].blockPins[ci.iter].center.size(); k++) {
                p = mydesign.Blocks[ci.iter2][0].blockPins[ci.iter].center[k];
                if (Blocks[ci.iter2].H_flip) p.x = mydesign.Blocks[ci.iter2][0].width - p.x;
                if (Blocks[ci.iter2].V_flip) p.y = mydesign.Blocks[ci.iter2][0].height - p.y;
                p += bp;
                if (p.y < distTermL2) {
                  distTermL2 = p.y;
                  tpL2.x = p.x;
                  tpL2.y = 0;
                }
                if (Ymax - p.y < distTermU2) {
                  distTermU2 = Ymax - p.y;
                  tpU2.x = p.x;
                  tpU2.y = Ymax;
                }
              }
            }
          }
          if (distTermL * alpha + distTermU2 * alpha2 < distTermU * alpha + distTermL2 * alpha2) {
            mydesign.Terminals.at(i).center = tpL1;
            mydesign.Terminals.at(cp).center = tpU2;
          } else {
            mydesign.Terminals.at(i).center = tpU1;
            mydesign.Terminals.at(cp).center = tpL2;
          }
        } else {
          logger->error("Placer-Error: incorrect axis direction");
        }
      }
    } else {  // not in symmetry group
      int tar = -1;
      for (unsigned int j = 0; j < mydesign.Port_Location.size(); j++) {
        if (mydesign.Port_Location.at(j).tid == (int)i) {
          tar = j;
          break;
        }
      }
      if (tar != -1) {  // specifiy PortLocation constraint
        int x1 = Xmax / 3, x2 = Xmax * 2 / 3, x3 = Xmax;
        int y1 = Ymax / 3, y2 = Ymax * 2 / 3, y3 = Ymax;
        placerDB::point tp;
        pos.clear();
        for (const auto& ci : mydesign.Nets.at(netIdx).connected) {
          if (ci.type == placerDB::Block) {
            bp = placerDB::point(Blocks[ci.iter2].x, Blocks[ci.iter2].y);
            for (unsigned int k = 0; k < mydesign.Blocks[ci.iter2][0].blockPins[ci.iter].center.size(); k++) {
              p = mydesign.Blocks[ci.iter2][0].blockPins[ci.iter].center[k];
              if (Blocks[ci.iter2].H_flip) p.x = mydesign.Blocks[ci.iter2][0].width - p.x;
              if (Blocks[ci.iter2].V_flip) p.y = mydesign.Blocks[ci.iter2][0].height - p.y;
              p += bp;
              pos.push_back(p);
            }
          }
        }
        int shot = -1;
        int distTerm = INT_MAX;
        for (unsigned int k = 0; k < pos.size(); k++) {
          p = pos.at(k);
          // Bmark {TL, TC, TR, RT, RC, RB, BR, BC, BL, LB, LC, LT};
          switch (mydesign.Port_Location.at(tar).pos) {
            case placerDB::TL:
              if (p.x >= 0 and p.x <= x1) {
                if (Ymax - p.y < distTerm) {
                  distTerm = Ymax - p.y;
                  shot = k;
                  tp = {p.x, Ymax};
                }
              } else {
                if (std::abs(p.x - 0) + Ymax - p.y < distTerm) {
                  distTerm = std::abs(p.x - 0) + Ymax - p.y;
                  shot = k;
                  tp = {0, Ymax};
                }
                if (std::abs(p.x - x1) + Ymax - p.y < distTerm) {
                  distTerm = std::abs(p.x - x1) + Ymax - p.y;
                  shot = k;
                  tp = {x1, Ymax};
                }
              }
              break;
            case placerDB::TC:
              if (p.x >= x1 and p.x <= x2) {
                if (Ymax - p.y < distTerm) {
                  distTerm = Ymax - p.y;
                  shot = k;
                  tp = {p.x, Ymax};
                }
              } else {
                if (std::abs(p.x - x2) + Ymax - p.y < distTerm) {
                  distTerm = std::abs(p.x - x2) + Ymax - p.y;
                  shot = k;
                  tp = {x2, Ymax};
                }
                if (std::abs(p.x - x1) + Ymax - p.y < distTerm) {
                  distTerm = std::abs(p.x - x1) + Ymax - p.y;
                  shot = k;
                  tp = {x1, Ymax};
                }
              }
              break;
            case placerDB::TR:
              if (p.x >= x2 and p.x <= x3) {
                if (Ymax - p.y < distTerm) {
                  distTerm = Ymax - p.y;
                  shot = k;
                  tp = {p.x, Ymax};
                }
              } else {
                if (std::abs(p.x - x2) + Ymax - p.y < distTerm) {
                  distTerm = std::abs(p.x - x2) + Ymax - p.y;
                  shot = k;
                  tp = {x2, Ymax};
                }
                if (std::abs(p.x - x3) + Ymax - p.y < distTerm) {
                  distTerm = std::abs(p.x - x3) + Ymax - p.y;
                  shot = k;
                  tp = {x3, Ymax};
                }
              }
              break;
            case placerDB::RT:
              if (p.y >= y2 and p.y <= y3) {
                if (Xmax - p.x < distTerm) {
                  distTerm = Xmax - p.x;
                  shot = k;
                  tp = {Xmax, p.y};
                }
              } else {
                if (std::abs(p.y - y2) + Xmax - p.x < distTerm) {
                  distTerm = std::abs(p.y - y2) + Xmax - p.x;
                  shot = k;
                  tp = {Xmax, y2};
                }
                if (std::abs(p.y - y3) + Xmax - p.x < distTerm) {
                  distTerm = std::abs(p.y - y3) + Xmax - p.x;
                  shot = k;
                  tp = {Xmax, y3};
                }
              }
              break;
            case placerDB::RC:
              if (p.y >= y1 and p.y <= y2) {
                if (Xmax - p.x < distTerm) {
                  distTerm = Xmax - p.x;
                  shot = k;
                  tp = {Xmax, p.y};
                }
              } else {
                if (std::abs(p.y - y2) + Xmax - p.x < distTerm) {
                  distTerm = std::abs(p.y - y2) + Xmax - p.x;
                  shot = k;
                  tp = {Xmax, y2};
                }
                if (std::abs(p.y - y1) + Xmax - p.x < distTerm) {
                  distTerm = std::abs(p.y - y1) + Xmax - p.x;
                  shot = k;
                  tp = {Xmax, y1};
                }
              }
              break;
            case placerDB::RB:
              if (p.y >= 0 and p.y <= y1) {
                if (Xmax - p.x < distTerm) {
                  distTerm = Xmax - p.x;
                  shot = k;
                  tp = {Xmax, p.y};
                }
              } else {
                if (std::abs(p.y - 0) + Xmax - p.x < distTerm) {
                  distTerm = std::abs(p.y - 0) + Xmax - p.x;
                  shot = k;
                  tp = {Xmax, 0};
                }
                if (std::abs(p.y - y1) + Xmax - p.x < distTerm) {
                  distTerm = std::abs(p.y - y1) + Xmax - p.x;
                  shot = k;
                  tp = {Xmax, y1};
                }
              }
              break;
            case placerDB::BL:
              if (p.x >= 0 and p.x <= x1) {
                if (p.y < distTerm) {
                  distTerm = p.y;
                  shot = k;
                  tp = {p.x, 0};
                }
              } else {
                if (std::abs(p.x - 0) + p.y < distTerm) {
                  distTerm = std::abs(p.x - 0) + p.y;
                  shot = k;
                  tp = {0, 0};
                }
                if (std::abs(p.x - x1) + p.y < distTerm) {
                  distTerm = std::abs(p.x - x1) + p.y;
                  shot = k;
                  tp = {x1, 0};
                }
              }
              break;
            case placerDB::BC:
              if (p.x >= x1 and p.x <= x2) {
                if (p.y < distTerm) {
                  distTerm = p.y;
                  shot = k;
                  tp = {p.x, 0};
                }
              } else {
                if (std::abs(p.x - x2) + p.y < distTerm) {
                  distTerm = std::abs(p.x - x2) + p.y;
                  shot = k;
                  tp = {x2, 0};
                }
                if (std::abs(p.x - x1) + p.y < distTerm) {
                  distTerm = std::abs(p.x - x1) + p.y;
                  shot = k;
                  tp = {x1, 0};
                }
              }
              break;
            case placerDB::BR:
              if (p.x >= x2 and p.x <= x3) {
                if (p.y < distTerm) {
                  distTerm = p.y;
                  shot = k;
                  tp = {p.x, 0};
                }
              } else {
                if (std::abs(p.x - x2) + p.y < distTerm) {
                  distTerm = std::abs(p.x - x2) + p.y;
                  shot = k;
                  tp = {x2, 0};
                }
                if (std::abs(p.x - x3) + p.y < distTerm) {
                  distTerm = std::abs(p.x - x3) + p.y;
                  shot = k;
                  tp = {x3, 0};
                }
              }
              break;
            case placerDB::LT:
              if (p.y >= y2 and p.y <= y3) {
                if (p.x < distTerm) {
                  distTerm = p.x;
                  shot = k;
                  tp = {0, p.y};
                }
              } else {
                if (std::abs(p.y - y2) + p.x < distTerm) {
                  distTerm = std::abs(p.y - y2) + p.x;
                  shot = k;
                  tp = {0, y2};
                }
                if (std::abs(p.y - y3) + p.x < distTerm) {
                  distTerm = std::abs(p.y - y3) + p.x;
                  shot = k;
                  tp = {0, y3};
                }
              }
              break;
            case placerDB::LC:
              if (p.y >= y1 and p.y <= y2) {
                if (p.x < distTerm) {
                  distTerm = p.x;
                  shot = k;
                  tp = {0, p.y};
                }
              } else {
                if (std::abs(p.y - y2) + p.x < distTerm) {
                  distTerm = std::abs(p.y - y2) + p.x;
                  shot = k;
                  tp = {0, y2};
                }
                if (std::abs(p.y - y1) + p.x < distTerm) {
                  distTerm = std::abs(p.y - y1) + p.x;
                  shot = k;
                  tp = {0, y1};
                }
              }
              break;
            case placerDB::LB:
              if (p.y >= 0 and p.y <= y1) {
                if (p.x < distTerm) {
                  distTerm = p.x;
                  shot = k;
                  tp = {0, p.y};
                }
              } else {
                if (std::abs(p.y - 0) + p.x < distTerm) {
                  distTerm = std::abs(p.y - 0) + p.x;
                  shot = k;
                  tp = {0, 0};
                }
                if (std::abs(p.y - y1) + p.x < distTerm) {
                  distTerm = std::abs(p.y - y1) + p.x;
                  shot = k;
                  tp = {0, y1};
                }
              }
              break;
            default:
              logger->warn("Placer-Warning: incorrect port position");
          }
        }
        if (shot != -1) {
          mydesign.Terminals.at(i).center = tp;
        }
      } else {  // no constraint
        placerDB::point tp;
        int distTerm = INT_MAX;
        for (const auto& ci : mydesign.Nets.at(netIdx).connected) {
          if (ci.type == placerDB::Block) {
            if (mydesign.Blocks[ci.iter2][0].blockPins.size() == 0) continue;
            bp = placerDB::point(Blocks[ci.iter2].x, Blocks[ci.iter2].y);
            for (unsigned int k = 0; k < mydesign.Blocks[ci.iter2][0].blockPins[ci.iter].center.size(); k++) {
              p = mydesign.Blocks[ci.iter2][0].blockPins[ci.iter].center[k];
              if (Blocks[ci.iter2].H_flip) p.x = mydesign.Blocks[ci.iter2][0].width - p.x;
              if (Blocks[ci.iter2].V_flip) p.y = mydesign.Blocks[ci.iter2][0].height - p.y;
              p += bp;
              if (p.x < distTerm) {
                distTerm = p.x;
                tp = {0, p.y};
              }
              if (Xmax - p.x < distTerm) {
                distTerm = Xmax - p.x;
                tp = {Xmax, p.y};
              }
              if (p.y < distTerm) {
                distTerm = p.y;
                tp = {p.x, 0};
              }
              if (Ymax - p.y < distTerm) {
                distTerm = Ymax - p.y;
                tp = {p.x, Ymax};
              }
            }
          }
        }
        mydesign.Terminals.at(i).center = tp;
      }
    }
  }
}

void ILP_solver::updateTerminalCenter(design& mydesign, SeqPair& curr_sp) {
  auto logger = spdlog::default_logger()->clone("placer.ILP_solver.updateTerminalCenter");

  int Xmax = UR.x;
  int Ymax = UR.y;
  vector<placerDB::point> pos;
  placerDB::point p, bp;
  int alpha;
  vector<placerDB::point> pos_pin;
  std::set<int> solved_terminals;
  // for each terminal
  for (int i = 0; i < mydesign.Terminals.size(); i++) {
    if (solved_terminals.find(i) != solved_terminals.end()) continue;
    solved_terminals.insert(i);
    int netIdx = mydesign.Terminals.at(i).netIter;
    int sbIdx = mydesign.Terminals.at(i).SBidx;
    int cp = mydesign.Terminals.at(i).counterpart;
    if (netIdx < 0 || netIdx >= int(mydesign.Nets.size())) {
      logger->error("Placer-Warning: terminal {0} is dangling; set it on origin", i);
      mydesign.Terminals.at(i).center = {0, 0};
      continue;
    }
    if ((mydesign.Nets.at(netIdx).priority).compare("min") == 0) {
      alpha = 4;
    } else if ((mydesign.Nets.at(netIdx).priority).compare("mid") == 0) {
      alpha = 2;
    } else {
      alpha = 1;
    }
    alpha *= mydesign.Nets.at(netIdx).weight;  // add weight to reflect the modification for bigMacros
    if (sbIdx != -1 && !curr_sp.Enumerate()) {                         // in symmetry group
      placerDB::Smark axis = curr_sp.GetSymmBlockAxis(sbIdx);
      if (cp == (int)i) {  // self-symmetric
        if (axis == placerDB::V) {
          int axis_X = Blocks[mydesign.SBlocks[sbIdx].selfsym[0].first].x +
                       mydesign.Blocks[mydesign.SBlocks[sbIdx].selfsym[0].first][curr_sp.selected[mydesign.SBlocks[sbIdx].selfsym[0].first]].width / 2;
          int distTerm = INT_MAX;
          placerDB::point tp(axis_X, 0);
          for (const auto& ci : mydesign.Nets[netIdx].connected) {
            if (ci.type == placerDB::Block) {
              bp = placerDB::point(Blocks[ci.iter2].x, Blocks[ci.iter2].y);
              for (unsigned int k = 0; k < mydesign.Blocks[ci.iter2][curr_sp.selected[ci.iter2]].blockPins[ci.iter].center.size(); k++) {
                p = mydesign.Blocks[ci.iter2][curr_sp.selected[ci.iter2]].blockPins[ci.iter].center[k];
                if (Blocks[ci.iter2].H_flip) p.x = mydesign.Blocks[ci.iter2][curr_sp.selected[ci.iter2]].width - p.x;
                if (Blocks[ci.iter2].V_flip) p.y = mydesign.Blocks[ci.iter2][curr_sp.selected[ci.iter2]].height - p.y;
                p += bp;
                if (p.y < distTerm) {
                  distTerm = p.y;
                  tp.y = 0;
                }
                if (Ymax - p.y < distTerm) {
                  distTerm = Ymax - p.y;
                  tp.y = Ymax;
                }
              }
            }
          }
          mydesign.Terminals.at(i).center = tp;
        } else if (axis == placerDB::H) {
          int axis_Y = Blocks[mydesign.SBlocks[sbIdx].selfsym[0].first].y +
                       mydesign.Blocks[mydesign.SBlocks[sbIdx].selfsym[0].first][curr_sp.selected[mydesign.SBlocks[sbIdx].selfsym[0].first]].height / 2;
          int distTerm = INT_MAX;
          placerDB::point tp(0, axis_Y);
          for (const auto& ci : mydesign.Nets.at(netIdx).connected) {
            if (ci.type == placerDB::Block) {
              bp = placerDB::point(Blocks[ci.iter2].x, Blocks[ci.iter2].y);
              for (unsigned int k = 0; k < mydesign.Blocks[ci.iter2][curr_sp.selected[ci.iter2]].blockPins[ci.iter].center.size(); k++) {
                p = mydesign.Blocks[ci.iter2][curr_sp.selected[ci.iter2]].blockPins[ci.iter].center[k];
                if (Blocks[ci.iter2].H_flip) p.x = mydesign.Blocks[ci.iter2][curr_sp.selected[ci.iter2]].width - p.x;
                if (Blocks[ci.iter2].V_flip) p.y = mydesign.Blocks[ci.iter2][curr_sp.selected[ci.iter2]].height - p.y;
                p += bp;
                if (p.x < distTerm) {
                  distTerm = p.x;
                  tp.x = 0;
                }
                if (Xmax - p.x < distTerm) {
                  distTerm = Xmax - p.x;
                  tp.x = Xmax;
                }
              }
            }
          }
          mydesign.Terminals.at(i).center = tp;
        } else {
          logger->error("Placer-Error: incorrect axis direction");
        }
      } else {  // symmetry pair
        if (solved_terminals.find(cp) != solved_terminals.end()) continue;
        solved_terminals.insert(cp);
        int netIdx2 = mydesign.Terminals.at(cp).netIter;
        if (netIdx2 < 0 || netIdx2 >= int(mydesign.Nets.size())) {
          logger->error("Placer-Error: terminal {0} is not dangling, but its counterpart {1} is dangling; set them on origin", i, cp);
          mydesign.Terminals.at(i).center = {0, 0};
          mydesign.Terminals.at(cp).center = {0, 0};
          continue;
        }
        int alpha2;
        if ((mydesign.Nets.at(netIdx2).priority).compare("min") == 0) {
          alpha2 = 4;
        } else if ((mydesign.Nets.at(netIdx2).priority).compare("mid") == 0) {
          alpha2 = 2;
        } else {
          alpha2 = 1;
        }
        alpha2 *= mydesign.Nets.at(netIdx2).weight;  // add weight to reflect the modification for bigMacros
        if (axis == placerDB::V) {
          placerDB::point tpL1, tpR1;
          int distTermL = INT_MAX, distTermR = INT_MAX;
          for (const auto& ci : mydesign.Nets.at(netIdx).connected) {
            if (ci.type == placerDB::Block) {
              bp = placerDB::point(Blocks[ci.iter2].x, Blocks[ci.iter2].y);
              for (unsigned int k = 0; k < mydesign.Blocks[ci.iter2][curr_sp.selected[ci.iter2]].blockPins[ci.iter].center.size(); k++) {
                p = mydesign.Blocks[ci.iter2][curr_sp.selected[ci.iter2]].blockPins[ci.iter].center[k];
                if (Blocks[ci.iter2].H_flip) p.x = mydesign.Blocks[ci.iter2][curr_sp.selected[ci.iter2]].width - p.x;
                if (Blocks[ci.iter2].V_flip) p.y = mydesign.Blocks[ci.iter2][curr_sp.selected[ci.iter2]].height - p.y;
                p += bp;
                if (p.x < distTermL) {
                  distTermL = p.x;
                  tpL1.x = 0;
                  tpL1.y = p.y;
                }
                if (Xmax - p.x < distTermR) {
                  distTermR = Xmax - p.x;
                  tpR1.x = Xmax;
                  tpR1.y = p.y;
                }
              }
            }
          }
          placerDB::point tpL2, tpR2;
          int distTermL2 = INT_MAX, distTermR2 = INT_MAX;
          for (const auto& ci : mydesign.Nets.at(netIdx2).connected) {
            if (ci.type == placerDB::Block) {
              bp = placerDB::point(Blocks[ci.iter2].x, Blocks[ci.iter2].y);
              for (unsigned int k = 0; k < mydesign.Blocks[ci.iter2][curr_sp.selected[ci.iter2]].blockPins[ci.iter].center.size(); k++) {
                p = mydesign.Blocks[ci.iter2][curr_sp.selected[ci.iter2]].blockPins[ci.iter].center[k];
                if (Blocks[ci.iter2].H_flip) p.x = mydesign.Blocks[ci.iter2][curr_sp.selected[ci.iter2]].width - p.x;
                if (Blocks[ci.iter2].V_flip) p.y = mydesign.Blocks[ci.iter2][curr_sp.selected[ci.iter2]].height - p.y;
                p += bp;
                if (p.x < distTermL2) {
                  distTermL2 = p.x;
                  tpL2.x = 0;
                  tpL2.y = p.y;
                }
                if (Xmax - p.x < distTermR2) {
                  distTermR2 = Xmax - p.x;
                  tpR2.x = Xmax;
                  tpR2.y = p.y;
                }
              }
            }
          }
          if (distTermL * alpha + distTermR2 * alpha2 < distTermR * alpha + distTermL2 * alpha2) {
            mydesign.Terminals.at(i).center = tpL1;
            mydesign.Terminals.at(cp).center = tpR2;
          } else {
            mydesign.Terminals.at(i).center = tpR1;
            mydesign.Terminals.at(cp).center = tpL2;
          }
        } else if (axis == placerDB::H) {
          placerDB::point tpL1, tpU1;
          int distTermL = INT_MAX, distTermU = INT_MAX;
          for (const auto& ci : mydesign.Nets.at(netIdx).connected) {
            if (ci.type == placerDB::Block) {
              bp = placerDB::point(Blocks[ci.iter2].x, Blocks[ci.iter2].y);
              for (unsigned int k = 0; k < mydesign.Blocks[ci.iter2][curr_sp.selected[ci.iter2]].blockPins[ci.iter].center.size(); k++) {
                p = mydesign.Blocks[ci.iter2][curr_sp.selected[ci.iter2]].blockPins[ci.iter].center[k];
                if (Blocks[ci.iter2].H_flip) p.x = mydesign.Blocks[ci.iter2][curr_sp.selected[ci.iter2]].width - p.x;
                if (Blocks[ci.iter2].V_flip) p.y = mydesign.Blocks[ci.iter2][curr_sp.selected[ci.iter2]].height - p.y;
                p += bp;
                if (p.y < distTermL) {
                  distTermL = p.y;
                  tpL1.x = p.x;
                  tpL1.y = 0;
                }
                if (Ymax - p.y < distTermU) {
                  distTermU = Ymax - p.y;
                  tpU1.x = p.x;
                  tpU1.y = Ymax;
                }
              }
            }
          }
          placerDB::point tpL2, tpU2;
          int distTermL2 = INT_MAX, distTermU2 = INT_MAX;
          for (const auto& ci : mydesign.Nets.at(netIdx2).connected) {
            if (ci.type == placerDB::Block) {
              bp = placerDB::point(Blocks[ci.iter2].x, Blocks[ci.iter2].y);
              for (unsigned int k = 0; k < mydesign.Blocks[ci.iter2][curr_sp.selected[ci.iter2]].blockPins[ci.iter].center.size(); k++) {
                p = mydesign.Blocks[ci.iter2][curr_sp.selected[ci.iter2]].blockPins[ci.iter].center[k];
                if (Blocks[ci.iter2].H_flip) p.x = mydesign.Blocks[ci.iter2][curr_sp.selected[ci.iter2]].width - p.x;
                if (Blocks[ci.iter2].V_flip) p.y = mydesign.Blocks[ci.iter2][curr_sp.selected[ci.iter2]].height - p.y;
                p += bp;
                if (p.y < distTermL2) {
                  distTermL2 = p.y;
                  tpL2.x = p.x;
                  tpL2.y = 0;
                }
                if (Ymax - p.y < distTermU2) {
                  distTermU2 = Ymax - p.y;
                  tpU2.x = p.x;
                  tpU2.y = Ymax;
                }
              }
            }
          }
          if (distTermL * alpha + distTermU2 * alpha2 < distTermU * alpha + distTermL2 * alpha2) {
            mydesign.Terminals.at(i).center = tpL1;
            mydesign.Terminals.at(cp).center = tpU2;
          } else {
            mydesign.Terminals.at(i).center = tpU1;
            mydesign.Terminals.at(cp).center = tpL2;
          }
        } else {
          logger->error("Placer-Error: incorrect axis direction");
        }
      }
    } else {  // not in symmetry group
      int tar = -1;
      for (int j = 0; j < mydesign.Port_Location.size(); j++) {
        if (mydesign.Port_Location.at(j).tid == (int)i) {
          tar = j;
          break;
        }
      }
      if (tar != -1) {  // specifiy PortLocation constraint
        int x1 = Xmax / 3, x2 = Xmax * 2 / 3, x3 = Xmax;
        int y1 = Ymax / 3, y2 = Ymax * 2 / 3, y3 = Ymax;
        placerDB::point tp;
        pos.clear();
        for (const auto& ci : mydesign.Nets.at(netIdx).connected) {
          if (ci.type == placerDB::Block) {
            bp = placerDB::point(Blocks[ci.iter2].x, Blocks[ci.iter2].y);
            for (unsigned int k = 0; k < mydesign.Blocks[ci.iter2][curr_sp.selected[ci.iter2]].blockPins[ci.iter].center.size(); k++) {
              p = mydesign.Blocks[ci.iter2][curr_sp.selected[ci.iter2]].blockPins[ci.iter].center[k];
              if (Blocks[ci.iter2].H_flip) p.x = mydesign.Blocks[ci.iter2][curr_sp.selected[ci.iter2]].width - p.x;
              if (Blocks[ci.iter2].V_flip) p.y = mydesign.Blocks[ci.iter2][curr_sp.selected[ci.iter2]].height - p.y;
              p += bp;
              pos.push_back(p);
            }
          }
        }
        int shot = -1;
        int distTerm = INT_MAX;
        for (int k = 0; k < pos.size(); k++) {
          p = pos.at(k);
          // Bmark {TL, TC, TR, RT, RC, RB, BR, BC, BL, LB, LC, LT};
          switch (mydesign.Port_Location.at(tar).pos) {
            case placerDB::TL:
              if (p.x >= 0 && p.x <= x1) {
                if (Ymax - p.y < distTerm) {
                  distTerm = Ymax - p.y;
                  shot = k;
                  tp = {p.x, Ymax};
                }
              } else {
                if (std::abs(p.x - 0) + Ymax - p.y < distTerm) {
                  distTerm = std::abs(p.x - 0) + Ymax - p.y;
                  shot = k;
                  tp = {0, Ymax};
                }
                if (std::abs(p.x - x1) + Ymax - p.y < distTerm) {
                  distTerm = std::abs(p.x - x1) + Ymax - p.y;
                  shot = k;
                  tp = {x1, Ymax};
                }
              }
              break;
            case placerDB::TC:
              if (p.x >= x1 && p.x <= x2) {
                if (Ymax - p.y < distTerm) {
                  distTerm = Ymax - p.y;
                  shot = k;
                  tp = {p.x, Ymax};
                }
              } else {
                if (std::abs(p.x - x2) + Ymax - p.y < distTerm) {
                  distTerm = std::abs(p.x - x2) + Ymax - p.y;
                  shot = k;
                  tp = {x2, Ymax};
                }
                if (std::abs(p.x - x1) + Ymax - p.y < distTerm) {
                  distTerm = std::abs(p.x - x1) + Ymax - p.y;
                  shot = k;
                  tp = {x1, Ymax};
                }
              }
              break;
            case placerDB::TR:
              if (p.x >= x2 && p.x <= x3) {
                if (Ymax - p.y < distTerm) {
                  distTerm = Ymax - p.y;
                  shot = k;
                  tp = {p.x, Ymax};
                }
              } else {
                if (std::abs(p.x - x2) + Ymax - p.y < distTerm) {
                  distTerm = std::abs(p.x - x2) + Ymax - p.y;
                  shot = k;
                  tp = {x2, Ymax};
                }
                if (std::abs(p.x - x3) + Ymax - p.y < distTerm) {
                  distTerm = std::abs(p.x - x3) + Ymax - p.y;
                  shot = k;
                  tp = {x3, Ymax};
                }
              }
              break;
            case placerDB::RT:
              if (p.y >= y2 && p.y <= y3) {
                if (Xmax - p.x < distTerm) {
                  distTerm = Xmax - p.x;
                  shot = k;
                  tp = {Xmax, p.y};
                }
              } else {
                if (std::abs(p.y - y2) + Xmax - p.x < distTerm) {
                  distTerm = std::abs(p.y - y2) + Xmax - p.x;
                  shot = k;
                  tp = {Xmax, y2};
                }
                if (std::abs(p.y - y3) + Xmax - p.x < distTerm) {
                  distTerm = std::abs(p.y - y3) + Xmax - p.x;
                  shot = k;
                  tp = {Xmax, y3};
                }
              }
              break;
            case placerDB::RC:
              if (p.y >= y1 && p.y <= y2) {
                if (Xmax - p.x < distTerm) {
                  distTerm = Xmax - p.x;
                  shot = k;
                  tp = {Xmax, p.y};
                }
              } else {
                if (std::abs(p.y - y2) + Xmax - p.x < distTerm) {
                  distTerm = std::abs(p.y - y2) + Xmax - p.x;
                  shot = k;
                  tp = {Xmax, y2};
                }
                if (std::abs(p.y - y1) + Xmax - p.x < distTerm) {
                  distTerm = std::abs(p.y - y1) + Xmax - p.x;
                  shot = k;
                  tp = {Xmax, y1};
                }
              }
              break;
            case placerDB::RB:
              if (p.y >= 0 && p.y <= y1) {
                if (Xmax - p.x < distTerm) {
                  distTerm = Xmax - p.x;
                  shot = k;
                  tp = {Xmax, p.y};
                }
              } else {
                if (std::abs(p.y - 0) + Xmax - p.x < distTerm) {
                  distTerm = std::abs(p.y - 0) + Xmax - p.x;
                  shot = k;
                  tp = {Xmax, 0};
                }
                if (std::abs(p.y - y1) + Xmax - p.x < distTerm) {
                  distTerm = std::abs(p.y - y1) + Xmax - p.x;
                  shot = k;
                  tp = {Xmax, y1};
                }
              }
              break;
            case placerDB::BL:
              if (p.x >= 0 && p.x <= x1) {
                if (p.y < distTerm) {
                  distTerm = p.y;
                  shot = k;
                  tp = {p.x, 0};
                }
              } else {
                if (std::abs(p.x - 0) + p.y < distTerm) {
                  distTerm = std::abs(p.x - 0) + p.y;
                  shot = k;
                  tp = {0, 0};
                }
                if (std::abs(p.x - x1) + p.y < distTerm) {
                  distTerm = std::abs(p.x - x1) + p.y;
                  shot = k;
                  tp = {x1, 0};
                }
              }
              break;
            case placerDB::BC:
              if (p.x >= x1 && p.x <= x2) {
                if (p.y < distTerm) {
                  distTerm = p.y;
                  shot = k;
                  tp = {p.x, 0};
                }
              } else {
                if (std::abs(p.x - x2) + p.y < distTerm) {
                  distTerm = std::abs(p.x - x2) + p.y;
                  shot = k;
                  tp = {x2, 0};
                }
                if (std::abs(p.x - x1) + p.y < distTerm) {
                  distTerm = std::abs(p.x - x1) + p.y;
                  shot = k;
                  tp = {x1, 0};
                }
              }
              break;
            case placerDB::BR:
              if (p.x >= x2 && p.x <= x3) {
                if (p.y < distTerm) {
                  distTerm = p.y;
                  shot = k;
                  tp = {p.x, 0};
                }
              } else {
                if (std::abs(p.x - x2) + p.y < distTerm) {
                  distTerm = std::abs(p.x - x2) + p.y;
                  shot = k;
                  tp = {x2, 0};
                }
                if (std::abs(p.x - x3) + p.y < distTerm) {
                  distTerm = std::abs(p.x - x3) + p.y;
                  shot = k;
                  tp = {x3, 0};
                }
              }
              break;
            case placerDB::LT:
              if (p.y >= y2 && p.y <= y3) {
                if (p.x < distTerm) {
                  distTerm = p.x;
                  shot = k;
                  tp = {0, p.y};
                }
              } else {
                if (std::abs(p.y - y2) + p.x < distTerm) {
                  distTerm = std::abs(p.y - y2) + p.x;
                  shot = k;
                  tp = {0, y2};
                }
                if (std::abs(p.y - y3) + p.x < distTerm) {
                  distTerm = std::abs(p.y - y3) + p.x;
                  shot = k;
                  tp = {0, y3};
                }
              }
              break;
            case placerDB::LC:
              if (p.y >= y1 && p.y <= y2) {
                if (p.x < distTerm) {
                  distTerm = p.x;
                  shot = k;
                  tp = {0, p.y};
                }
              } else {
                if (std::abs(p.y - y2) + p.x < distTerm) {
                  distTerm = std::abs(p.y - y2) + p.x;
                  shot = k;
                  tp = {0, y2};
                }
                if (std::abs(p.y - y1) + p.x < distTerm) {
                  distTerm = std::abs(p.y - y1) + p.x;
                  shot = k;
                  tp = {0, y1};
                }
              }
              break;
            case placerDB::LB:
              if (p.y >= 0 && p.y <= y1) {
                if (p.x < distTerm) {
                  distTerm = p.x;
                  shot = k;
                  tp = {0, p.y};
                }
              } else {
                if (std::abs(p.y - 0) + p.x < distTerm) {
                  distTerm = std::abs(p.y - 0) + p.x;
                  shot = k;
                  tp = {0, 0};
                }
                if (std::abs(p.y - y1) + p.x < distTerm) {
                  distTerm = std::abs(p.y - y1) + p.x;
                  shot = k;
                  tp = {0, y1};
                }
              }
              break;
            default:
              logger->warn("Placer-Warning: incorrect port position");
          }
        }
        if (shot != -1) {
          mydesign.Terminals.at(i).center = tp;
        }
      } else {  // no constraint
        placerDB::point tp;
        int distTerm = INT_MAX;
        for (const auto& ci : mydesign.Nets.at(netIdx).connected) {
          if (ci.type == placerDB::Block) {
            bp = placerDB::point(Blocks[ci.iter2].x, Blocks[ci.iter2].y);
            for (unsigned int k = 0; k < mydesign.Blocks[ci.iter2][curr_sp.selected[ci.iter2]].blockPins[ci.iter].center.size(); k++) {
              p = mydesign.Blocks[ci.iter2][curr_sp.selected[ci.iter2]].blockPins[ci.iter].center[k];
              if (Blocks[ci.iter2].H_flip) p.x = mydesign.Blocks[ci.iter2][curr_sp.selected[ci.iter2]].width - p.x;
              if (Blocks[ci.iter2].V_flip) p.y = mydesign.Blocks[ci.iter2][curr_sp.selected[ci.iter2]].height - p.y;
              p += bp;
              if (p.x < distTerm) {
                distTerm = p.x;
                tp = {0, p.y};
              }
              if (Xmax - p.x < distTerm) {
                distTerm = Xmax - p.x;
                tp = {Xmax, p.y};
              }
              if (p.y < distTerm) {
                distTerm = p.y;
                tp = {p.x, 0};
              }
              if (Ymax - p.y < distTerm) {
                distTerm = Ymax - p.y;
                tp = {p.x, Ymax};
              }
            }
          }
        }
        mydesign.Terminals.at(i).center = tp;
      }
    }
  }
}

void ILP_solver::UpdateHierNode(design& mydesign, SeqPair& curr_sp, PnRDB::hierNode& node, PnRDB::Drc_info& drcInfo) {
  node.width = UR.x + mydesign.halo_horizontal;
  node.height = UR.y + mydesign.halo_vertical;
  node.HPWL = HPWL;
  node.HPWL_extend = HPWL_extend;
  node.HPWL_extend_wo_terminal = node.HPWL_extend - HPWL_extend_terminal;  // HPWL without terminal nets' HPWL
  node.area_norm = area_norm;
  node.HPWL_norm = HPWL_norm;
  node.constraint_penalty = constraint_penalty;
  node.cost = cost;

  for (unsigned int i = 0; i < mydesign.Blocks.size(); ++i) {
    node.Blocks.at(i).selectedInstance = curr_sp.GetBlockSelected(i);
    node.HPWL_extend += node.Blocks[i].instance[node.Blocks.at(i).selectedInstance].HPWL_extend_wo_terminal;
    node.HPWL_extend_wo_terminal += node.Blocks[i].instance[node.Blocks.at(i).selectedInstance].HPWL_extend_wo_terminal;
    placerDB::Omark ort;
    if (Blocks[i].H_flip) {
      if (Blocks[i].V_flip)
        ort = placerDB::S;
      else
        ort = placerDB::FN;
    } else {
      if (Blocks[i].V_flip)
        ort = placerDB::FS;
      else
        ort = placerDB::N;
    }
    UpdateBlockinHierNode(mydesign, ort, node, i, curr_sp.GetBlockSelected(i), drcInfo);
  }
  UpdateTerminalinHierNode(mydesign, node, drcInfo);
  if (!curr_sp.Enumerate()) {
    for (unsigned int i = 0; i < mydesign.SNets.size(); ++i) {
      int SBidx = mydesign.SNets.at(i).SBidx;
      placerDB::Smark axis_dir = curr_sp.GetSymmBlockAxis(SBidx);
      UpdateSymmetryNetInfo(mydesign, node, i, SBidx, axis_dir, curr_sp);
    }
  }
}

void ILP_solver::UpdateHierNodeAnalytical(design& mydesign, PnRDB::hierNode& node, PnRDB::Drc_info& drcInfo) {
  node.width = UR.x;
  node.height = UR.y;
  node.HPWL = HPWL;
  node.HPWL_extend = HPWL_extend;
  node.HPWL_extend_wo_terminal = node.HPWL_extend - HPWL_extend_terminal;  // HPWL without terminal nets' HPWL
  node.area_norm = area_norm;
  node.HPWL_norm = HPWL_norm;
  node.constraint_penalty = constraint_penalty;
  node.cost = cost;

  for (unsigned int i = 0; i < mydesign.Blocks.size(); ++i) {
    node.Blocks.at(i).selectedInstance = 0;
    node.HPWL_extend += node.Blocks[i].instance[node.Blocks.at(i).selectedInstance].HPWL_extend_wo_terminal;
    node.HPWL_extend_wo_terminal += node.Blocks[i].instance[node.Blocks.at(i).selectedInstance].HPWL_extend_wo_terminal;
    placerDB::Omark ort;
    if (Blocks[i].H_flip) {
      if (Blocks[i].V_flip)
        ort = placerDB::S;
      else
        ort = placerDB::FN;
    } else {
      if (Blocks[i].V_flip)
        ort = placerDB::FS;
      else
        ort = placerDB::N;
    }
    UpdateBlockinHierNode(mydesign, ort, node, i, 0, drcInfo);
  }
  UpdateTerminalinHierNode(mydesign, node, drcInfo);
  for (unsigned int i = 0; i < mydesign.SNets.size(); ++i) {
    int SBidx = mydesign.SNets.at(i).SBidx;
    placerDB::Smark axis_dir = mydesign.SBlocks[i].axis_dir;
    UpdateSymmetryNetInfoAnalytical(mydesign, node, i, SBidx, axis_dir);
  }
}

void ILP_solver::UpdateBlockinHierNode(design& mydesign, placerDB::Omark ort, PnRDB::hierNode& node, int i, int sel, PnRDB::Drc_info& drcInfo) {
  vector<vector<placerDB::point>> boundary;
  vector<placerDB::point> center;
  vector<placerDB::point> bbox;
  placerDB::point bpoint;

  int x = Blocks[i].x;
  int y = Blocks[i].y;

  // SMB Hack
  auto roundup = [](int& v, int pitch) { v = pitch * ((v + pitch - 1) / pitch); };
  int v_metal_index = -1;
  int h_metal_index = -1;
  for (unsigned int i = 0; i < drcInfo.Metal_info.size(); ++i) {
    if (drcInfo.Metal_info[i].direct == 0) {
      v_metal_index = i;
      break;
    }
  }
  for (unsigned int i = 0; i < drcInfo.Metal_info.size(); ++i) {
    if (drcInfo.Metal_info[i].direct == 1) {
      h_metal_index = i;
      break;
    }
  }

  //int x_pitch = drcInfo.Metal_info[v_metal_index].grid_unit_x;
  //int y_pitch = drcInfo.Metal_info[h_metal_index].grid_unit_y;
  //roundup(x, x_pitch);
  //roundup(y, y_pitch);

  placerDB::point LL = {x, y};
  bbox = mydesign.GetPlacedBlockAbsBoundary(i, ort, LL, sel);
  bpoint = mydesign.GetBlockAbsCenter(i, ort, LL, sel);
  auto& nd = node.Blocks.at(i).instance.at(sel);

  nd.orient = PnRDB::Omark(ort);
  nd.placedBox = ConvertBoundaryData(bbox);
  nd.placedCenter = ConvertPointData(bpoint);
  for (int j = 0; j < mydesign.GetBlockPinNum(i, sel); j++) {
    boundary = mydesign.GetPlacedBlockPinAbsBoundary(i, j, ort, LL, sel);
    center = mydesign.GetPlacedBlockPinAbsPosition(i, j, ort, LL, sel);
    for (unsigned int k = 0; k < nd.blockPins.at(j).pinContacts.size(); k++) {
      nd.blockPins.at(j).pinContacts.at(k).placedBox = ConvertBoundaryData(boundary.at(k));
      nd.blockPins.at(j).pinContacts.at(k).placedCenter = ConvertPointData(center.at(k));
    }
    // update pin vias
    for (unsigned int k = 0; k < node.Blocks.at(i).instance.at(sel).blockPins.at(j).pinVias.size(); k++) {
      auto& pv = nd.blockPins.at(j).pinVias.at(k);
      pv.placedpos = mydesign.GetPlacedBlockInterMetalAbsPoint(i, ort, pv.originpos, LL, sel);
      pv.UpperMetalRect.placedBox = mydesign.GetPlacedBlockInterMetalAbsBox(i, ort, pv.UpperMetalRect.originBox, LL, sel);
      pv.LowerMetalRect.placedBox = mydesign.GetPlacedBlockInterMetalAbsBox(i, ort, pv.LowerMetalRect.originBox, LL, sel);
      pv.ViaRect.placedBox = mydesign.GetPlacedBlockInterMetalAbsBox(i, ort, pv.ViaRect.originBox, LL, sel);
      pv.UpperMetalRect.placedCenter = mydesign.GetPlacedBlockInterMetalAbsPoint(i, ort, pv.UpperMetalRect.originCenter, LL, sel);
      pv.LowerMetalRect.placedCenter = mydesign.GetPlacedBlockInterMetalAbsPoint(i, ort, pv.LowerMetalRect.originCenter, LL, sel);
      pv.ViaRect.placedCenter = mydesign.GetPlacedBlockInterMetalAbsPoint(i, ort, pv.ViaRect.originCenter, LL, sel);
    }
  }
  // update internal metals
  for (unsigned int j = 0; j < node.Blocks.at(i).instance.at(sel).interMetals.size(); j++) {
    auto& im = nd.interMetals.at(j);
    im.placedBox = mydesign.GetPlacedBlockInterMetalAbsBox(i, ort, im.originBox, LL, sel);
    im.placedCenter = mydesign.GetPlacedBlockInterMetalAbsPoint(i, ort, im.originCenter, LL, sel);
  }
  // update internal vias
  for (unsigned int j = 0; j < node.Blocks.at(i).instance.at(sel).interVias.size(); j++) {
    auto& iv = nd.interVias.at(j);
    iv.placedpos = mydesign.GetPlacedBlockInterMetalAbsPoint(i, ort, iv.originpos, LL, sel);
    iv.UpperMetalRect.placedBox = mydesign.GetPlacedBlockInterMetalAbsBox(i, ort, iv.UpperMetalRect.originBox, LL, sel);
    iv.LowerMetalRect.placedBox = mydesign.GetPlacedBlockInterMetalAbsBox(i, ort, iv.LowerMetalRect.originBox, LL, sel);
    iv.ViaRect.placedBox = mydesign.GetPlacedBlockInterMetalAbsBox(i, ort, iv.ViaRect.originBox, LL, sel);
    iv.UpperMetalRect.placedCenter = mydesign.GetPlacedBlockInterMetalAbsPoint(i, ort, iv.UpperMetalRect.originCenter, LL, sel);
    iv.LowerMetalRect.placedCenter = mydesign.GetPlacedBlockInterMetalAbsPoint(i, ort, iv.LowerMetalRect.originCenter, LL, sel);
    iv.ViaRect.placedCenter = mydesign.GetPlacedBlockInterMetalAbsPoint(i, ort, iv.ViaRect.originCenter, LL, sel);
  }
}

void ILP_solver::UpdateTerminalinHierNode(design& mydesign, PnRDB::hierNode& node, PnRDB::Drc_info& drcInfo) {
  map<int, int> terminal_to_net;
  for (unsigned int i = 0; i < node.Nets.size(); i++) {
    for (const auto& c : node.Nets[i].connected) {
      if (c.type == PnRDB::Terminal) {
        terminal_to_net[c.iter] = i;
        break;
      }
    }
  }
  for (int i = 0; i < (int)mydesign.GetSizeofTerminals(); i++) {
    if (node.Terminals[i].netIter == -1) continue;
    auto& tC = node.Terminals.at(i).termContacts;
    tC.clear();
    for (const auto& c : node.Nets[terminal_to_net[i]].connected) {
      if (c.type == PnRDB::Terminal) continue;
      for (const auto& con : node.Blocks[c.iter2].instance[node.Blocks[c.iter2].selectedInstance].blockPins[c.iter].pinContacts) {
        tC.push_back(con);
        tC.back().originBox = tC.back().placedBox;
        tC.back().originCenter = tC.back().placedCenter;
      }
    }
  }
  /**
  for (int i = 0; i < (int)mydesign.GetSizeofTerminals(); i++) {
    auto& tC = node.Terminals.at(i).termContacts;
    tC.clear();
    tC.resize(1);
    auto c = ConvertPointData(mydesign.GetTerminalCenter(i));
    tC.back().placedCenter = c;
    // tC.back() has other fields that remain at their default values: originBox, placedBox, originCenter
    tC.back().originCenter = c;
    tC.back().originBox.LL = c;
    tC.back().originBox.UR = c;
    tC.back().placedBox.LL = c;
    tC.back().placedBox.UR = c;
  }**/
  for (int i = 0; i < (int)mydesign.GetSizeofTerminals(); i++) {
    const auto& t = node.Terminals.at(i);
    PnRDB::pin temp_pin;
    temp_pin.name = t.name;
    temp_pin.type = t.type;
    temp_pin.netIter = t.netIter;
    temp_pin.pinContacts = t.termContacts;
    for (int j = 0; j < temp_pin.pinContacts.size(); j++) temp_pin.pinContacts[j].metal = drcInfo.Metal_info[0].name;
    temp_pin.name = node.Terminals.at(i).name;
    temp_pin.type = node.Terminals.at(i).type;
    node.blockPins.push_back(temp_pin);
  }
}

void ILP_solver::UpdateSymmetryNetInfoAnalytical(design& mydesign, PnRDB::hierNode& node, int i, int SBidx, placerDB::Smark axis_dir) {
  auto logger = spdlog::default_logger()->clone("placer.ILP_solver.UpdateSymmetryNetInfo");

  int axis_coor = 0;
  if (axis_dir == placerDB::V) {
    if (mydesign.SBlocks[SBidx].selfsym.size() > 0) {
      // self sym x axis coordinate
      axis_coor = Blocks[mydesign.SBlocks[SBidx].selfsym[0].first].x + mydesign.Blocks[mydesign.SBlocks[SBidx].selfsym[0].first][0].width / 2;
    } else {
      // sym pair x axis coordinate
      axis_coor = Blocks[mydesign.SBlocks[SBidx].sympair[0].first].x / 2 + mydesign.Blocks[mydesign.SBlocks[SBidx].sympair[0].first][0].width / 4 +
                  Blocks[mydesign.SBlocks[SBidx].sympair[0].second].x / 2 + mydesign.Blocks[mydesign.SBlocks[SBidx].sympair[0].second][0].width / 4;
    }
  } else if (axis_dir == placerDB::H) {
    if (mydesign.SBlocks[SBidx].selfsym.size() > 0) {
      axis_coor = Blocks[mydesign.SBlocks[SBidx].selfsym[0].first].y + mydesign.Blocks[mydesign.SBlocks[SBidx].selfsym[0].first][0].height / 2;
    } else {
      axis_coor = Blocks[mydesign.SBlocks[SBidx].sympair[0].first].y / 2 + mydesign.Blocks[mydesign.SBlocks[SBidx].sympair[0].first][0].height / 4 +
                  Blocks[mydesign.SBlocks[SBidx].sympair[0].second].y / 2 + mydesign.Blocks[mydesign.SBlocks[SBidx].sympair[0].second][0].height / 4;
    }
  } else {
    logger->error("Placer-Error: incorrect symmetry axis direction");
  }
  string net1 = mydesign.SNets.at(i).net1.name;
  string net2 = mydesign.SNets.at(i).net2.name;
  for (std::vector<PnRDB::net>::iterator it = node.Nets.begin(); it != node.Nets.end(); ++it) {
    if (it->name.compare(net1) == 0 || it->name.compare(net2) == 0) {
      it->axis_dir = PnRDB::Smark(int(axis_dir));
      it->axis_coor = axis_coor;
    }
  }
}

void ILP_solver::UpdateSymmetryNetInfo(design& mydesign, PnRDB::hierNode& node, int i, int SBidx, placerDB::Smark axis_dir, SeqPair& curr_sp) {
  auto logger = spdlog::default_logger()->clone("placer.ILP_solver.UpdateSymmetryNetInfo");

  int axis_coor = 0;
  if (axis_dir == placerDB::V) {
    if (mydesign.SBlocks[SBidx].selfsym.size() > 0) {
      // self sym x axis coordinate
      axis_coor = Blocks[mydesign.SBlocks[SBidx].selfsym[0].first].x +
                  mydesign.Blocks[mydesign.SBlocks[SBidx].selfsym[0].first][curr_sp.selected[mydesign.SBlocks[SBidx].selfsym[0].first]].width / 2;
    } else {
      // sym pair x axis coordinate
      if (mydesign.SBlocks[SBidx].sympair[0].first < Blocks.size() && mydesign.SBlocks[SBidx].sympair[0].second < Blocks.size()){
        axis_coor = Blocks[mydesign.SBlocks[SBidx].sympair[0].first].x / 2 +
                    mydesign.Blocks[mydesign.SBlocks[SBidx].sympair[0].first][curr_sp.selected[mydesign.SBlocks[SBidx].sympair[0].first]].width / 4 +
                    Blocks[mydesign.SBlocks[SBidx].sympair[0].second].x / 2 +
                    mydesign.Blocks[mydesign.SBlocks[SBidx].sympair[0].second][curr_sp.selected[mydesign.SBlocks[SBidx].sympair[0].second]].width / 4;
      }
    }
  } else if (axis_dir == placerDB::H) {
    if (mydesign.SBlocks[SBidx].selfsym.size() > 0) {
      axis_coor = Blocks[mydesign.SBlocks[SBidx].selfsym[0].first].y +
                  mydesign.Blocks[mydesign.SBlocks[SBidx].selfsym[0].first][curr_sp.selected[mydesign.SBlocks[SBidx].selfsym[0].first]].height / 2;
    } else {
      if (mydesign.SBlocks[SBidx].sympair[0].first < Blocks.size() && mydesign.SBlocks[SBidx].sympair[0].second < Blocks.size()){
        axis_coor = Blocks[mydesign.SBlocks[SBidx].sympair[0].first].y / 2 +
                  mydesign.Blocks[mydesign.SBlocks[SBidx].sympair[0].first][curr_sp.selected[mydesign.SBlocks[SBidx].sympair[0].first]].height / 4 +
                  Blocks[mydesign.SBlocks[SBidx].sympair[0].second].y / 2 +
                  mydesign.Blocks[mydesign.SBlocks[SBidx].sympair[0].second][curr_sp.selected[mydesign.SBlocks[SBidx].sympair[0].second]].height / 4;
      }
    }
  } else {
    logger->error("Placer-Error: incorrect symmetry axis direction");
  }
  string net1 = mydesign.SNets.at(i).net1.name;
  string net2 = mydesign.SNets.at(i).net2.name;
  for (std::vector<PnRDB::net>::iterator it = node.Nets.begin(); it != node.Nets.end(); ++it) {
    if (it->name.compare(net1) == 0 || it->name.compare(net2) == 0) {
      it->axis_dir = PnRDB::Smark(int(axis_dir));
      it->axis_coor = axis_coor;
    }
  }
}

PnRDB::bbox ILP_solver::ConvertBoundaryData(vector<placerDB::point> Bdata) {
  PnRDB::bbox newBdata;
  PnRDB::point tmpp;
  int x = Bdata.at(0).x, X = Bdata.at(0).x, y = Bdata.at(0).y, Y = Bdata.at(0).y;
  for (vector<placerDB::point>::iterator it = Bdata.begin(); it != Bdata.end(); ++it) {
    tmpp.x = it->x;
    tmpp.y = it->y;
    if ((it->x) < x) {
      x = it->x;
    }
    if ((it->x) > X) {
      X = it->x;
    }
    if ((it->y) < y) {
      y = it->y;
    }
    if ((it->y) > Y) {
      Y = it->y;
    }
  }
  newBdata.LL = {x, y};
  newBdata.UR = {X, Y};
  return newBdata;
}

PnRDB::point ILP_solver::ConvertPointData(placerDB::point Pdata) {
  PnRDB::point newPdata;
  newPdata.x = Pdata.x;
  newPdata.y = Pdata.y;
  return newPdata;
}
